import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { FileText, Users, CreditCard, Bus, GraduationCap, Calendar } from 'lucide-react'
import Link from "next/link"

export default function ReportsPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Reports</h1>
      </div>
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-medium">Student Admissions</CardTitle>
            <Users className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <CardDescription className="mb-4">
              Generate reports on student admissions, demographics, and enrollment trends.
            </CardDescription>
            <div className="space-y-2">
              <Button className="w-full" variant="outline" asChild>
                <Link href="/reports/students">
                  <FileText className="mr-2 h-4 w-4" />
                  Admission Report
                </Link>
              </Button>
              <Button className="w-full" variant="outline" asChild>
                <Link href="/reports/students">
                  <FileText className="mr-2 h-4 w-4" />
                  Enrollment Trends
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-medium">Fee Reports</CardTitle>
            <CreditCard className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <CardDescription className="mb-4">
              Generate reports on fee collection, pending payments, and financial summaries.
            </CardDescription>
            <div className="space-y-2">
              <Button className="w-full" variant="outline" asChild>
                <Link href="/reports/fees">
                  <FileText className="mr-2 h-4 w-4" />
                  Fee Collection Report
                </Link>
              </Button>
              <Button className="w-full" variant="outline" asChild>
                <Link href="/reports/fees?status=Pending">
                  <FileText className="mr-2 h-4 w-4" />
                  Pending Payments
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-medium">Attendance Reports</CardTitle>
            <Calendar className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <CardDescription className="mb-4">
              Generate reports on student and teacher attendance, absences, and trends.
            </CardDescription>
            <div className="space-y-2">
              <Button className="w-full" variant="outline" asChild>
                <Link href="/reports/attendance">
                  <FileText className="mr-2 h-4 w-4" />
                  Student Attendance
                </Link>
              </Button>
              <Button className="w-full" variant="outline" asChild>
                <Link href="/reports/attendance">
                  <FileText className="mr-2 h-4 w-4" />
                  Attendance Percentage
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-medium">Transportation Reports</CardTitle>
            <Bus className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <CardDescription className="mb-4">
              Generate reports on transport routes, vehicle usage, and student allocation.
            </CardDescription>
            <div className="space-y-2">
              <Button className="w-full" variant="outline" asChild>
                <Link href="/reports/transportation">
                  <FileText className="mr-2 h-4 w-4" />
                  Route Utilization
                </Link>
              </Button>
              <Button className="w-full" variant="outline" asChild>
                <Link href="/reports/fees?feeType=Transport">
                  <FileText className="mr-2 h-4 w-4" />
                  Transport Fee Collection
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-medium">Academic Reports</CardTitle>
            <GraduationCap className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <CardDescription className="mb-4">
              Generate reports on student grades, assessments, and academic performance.
            </CardDescription>
            <div className="space-y-2">
              <Button className="w-full" variant="outline" asChild>
                <Link href="/reports/grades">
                  <FileText className="mr-2 h-4 w-4" />
                  Grade Report
                </Link>
              </Button>
              <Button className="w-full" variant="outline" asChild>
                <Link href="/reports/grades">
                  <FileText className="mr-2 h-4 w-4" />
                  Class Performance
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
