import Link from "next/link"
import { PlusCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { TeacherTable } from "@/components/teacher-table"

export default function TeachersPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Teachers</h1>
        <Button asChild>
          <Link href="/teachers/new">
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Teacher
          </Link>
        </Button>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Teacher Management</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <Input placeholder="Search teachers..." className="max-w-sm" />
              <Button variant="outline">Search</Button>
            </div>
            <TeacherTable />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
