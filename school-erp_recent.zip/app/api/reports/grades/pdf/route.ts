import { type NextRequest, NextResponse } from "next/server"
import { jsPDF } from "jspdf"
import "jspdf-autotable"
import { getGradeReportData } from "@/app/actions/grade-actions"
import {
  calculateWeightedGrade,
  calculateLetterGrade,
  calculateClassStatistics,
} from "@/lib/validators/grade-calculator"
import { getSession } from "@/app/actions/auth-actions"

// Extend the jsPDF type to include autoTable
declare module "jspdf" {
  interface jsPDF {
    autoTable: (options: any) => jsPDF
  }
}

export async function GET(request: NextRequest) {
  try {
    // Check authentication
    const session = await getSession()
    if (!session) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 })
    }

    // Get query parameters
    const searchParams = request.nextUrl.searchParams
    const grade = searchParams.get("grade") || undefined
    const subjectId = searchParams.get("subjectId")
      ? Number.parseInt(searchParams.get("subjectId") as string)
      : undefined
    const termId = searchParams.get("termId") ? Number.parseInt(searchParams.get("termId") as string) : undefined

    // Get report data
    const result = await getGradeReportData({ grade, subjectId, termId })

    if (!result.success) {
      return NextResponse.json({ error: result.message }, { status: 500 })
    }

    const reportData = result.data.reportData

    // Process report data
    const studentMap = new Map()

    reportData.forEach((record: any) => {
      const studentId = record.student_id
      if (!studentMap.has(studentId)) {
        studentMap.set(studentId, {
          id: studentId,
          name: record.student_name,
          grade: record.student_grade,
          subjects: new Map(),
        })
      }

      const student = studentMap.get(studentId)
      const subjectId = record.subject_id

      if (!student.subjects.has(subjectId)) {
        student.subjects.set(subjectId, {
          id: subjectId,
          name: record.subject_name,
          assessments: [],
          weightedGrade: 0,
          letterGrade: "",
        })
      }

      const subject = student.subjects.get(subjectId)
      subject.assessments.push({
        id: record.assessment_id,
        name: record.assessment_name,
        weight: Number.parseFloat(record.assessment_weight),
        score: Number.parseFloat(record.score),
        remarks: record.remarks,
      })
    })

    // Calculate weighted grades for each student and subject
    const studentGrades: any[] = []
    const allGrades: number[] = []

    studentMap.forEach((student: any) => {
      student.subjects.forEach((subject: any) => {
        // Calculate weighted grade
        const weightedGrade = calculateWeightedGrade(
          subject.assessments.map((a: any) => ({
            weight: a.weight,
            score: a.score,
          })),
        )

        subject.weightedGrade = weightedGrade
        subject.letterGrade = calculateLetterGrade(weightedGrade)
        allGrades.push(weightedGrade)
      })

      // Convert subjects map to array
      const subjectsArray = Array.from(student.subjects.values())

      // Calculate overall average across all subjects
      const overallAverage =
        subjectsArray.reduce((sum: number, subject: any) => sum + subject.weightedGrade, 0) / subjectsArray.length

      studentGrades.push({
        ...student,
        subjects: subjectsArray,
        overallAverage: Math.round(overallAverage * 100) / 100,
        overallLetterGrade: calculateLetterGrade(overallAverage),
      })
    })

    // Calculate class statistics
    const classStatistics = calculateClassStatistics(allGrades)

    // Create a new PDF document
    const doc = new jsPDF()

    // Add school logo/header
    doc.setFontSize(22)
    doc.setTextColor(0, 32, 96) // School blue color
    doc.text("School 360", 105, 20, { align: "center" })

    doc.setFontSize(14)
    doc.setTextColor(0, 0, 0)
    doc.text("Academic Excellence", 105, 28, { align: "center" })

    doc.setFontSize(12)
    doc.text("123 Education Street, City, Country", 105, 36, { align: "center" })
    doc.text("Phone: +1 234 567 8900 | Email: info@school360.com", 105, 42, { align: "center" })

    // Add a horizontal line
    doc.setDrawColor(0, 32, 96)
    doc.setLineWidth(0.5)
    doc.line(20, 45, 190, 45)

    // Add report title with better formatting
    doc.setFontSize(18)
    doc.setTextColor(0, 32, 96)
    doc.text("GRADE REPORT", 105, 55, { align: "center" })

    // Add report filters with better formatting
    doc.setFontSize(10)
    doc.setTextColor(0, 0, 0)
    doc.text(`Generated on: ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}`, 20, 65)

    let filterY = 70
    if (grade) {
      doc.text(`Grade: ${grade}`, 20, filterY)
      filterY += 5
    }

    if (subjectId) {
      const subjectName = reportData.find((r: any) => r.subject_id === subjectId)?.subject_name || "Unknown"
      doc.text(`Subject: ${subjectName}`, 20, filterY)
      filterY += 5
    }

    if (termId) {
      const termName = reportData.find((r: any) => r.term_id === termId)?.term_name || "Unknown"
      doc.text(`Term: ${termName}`, 20, filterY)
      filterY += 5
    }

    // Add class statistics with better formatting
    doc.setFontSize(14)
    doc.setTextColor(0, 32, 96)
    doc.text("Class Statistics", 20, filterY + 10)

    doc.setFontSize(10)
    doc.setTextColor(0, 0, 0)
    doc.text(`Class Average: ${classStatistics.average}%`, 20, filterY + 20)
    doc.text(`Highest Grade: ${classStatistics.highest}%`, 20, filterY + 25)
    doc.text(`Lowest Grade: ${classStatistics.lowest}%`, 20, filterY + 30)
    doc.text(`Median Grade: ${classStatistics.median}%`, 20, filterY + 35)
    doc.text(`Passing Rate: ${classStatistics.passingRate}%`, 20, filterY + 40)

    // Add student grades table with better formatting
    doc.setFontSize(14)
    doc.setTextColor(0, 32, 96)
    doc.text("Student Grades", 20, filterY + 55)

    const tableHeaders = [["Student Name", "Grade", "Subject", "Weighted Grade", "Letter Grade"]]
    const tableData = studentGrades.flatMap((student) =>
      student.subjects.map((subject) => [
        student.name,
        student.grade,
        subject.name,
        subject.weightedGrade,
        subject.letterGrade,
      ]),
    )

    // Improve table styling
    doc.autoTable({
      startY: filterY + 60,
      head: tableHeaders,
      body: tableData,
      theme: "grid",
      headStyles: {
        fillColor: [0, 32, 96],
        textColor: [255, 255, 255],
        fontStyle: "bold",
      },
      alternateRowStyles: {
        fillColor: [240, 240, 250],
      },
      margin: { top: 10, right: 20, bottom: 20, left: 20 },
      styles: {
        fontSize: 9,
        cellPadding: 3,
      },
    })

    // Add footer with page numbers
    const pageCount = doc.internal.getNumberOfPages()
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i)

      // Add horizontal line
      doc.setDrawColor(0, 32, 96)
      doc.setLineWidth(0.3)
      doc.line(20, 280, 190, 280)

      // Add footer text
      doc.setFontSize(8)
      doc.setTextColor(0, 0, 0)
      doc.text("This is a computer-generated report and does not require a signature.", 105, 285, { align: "center" })

      // Add page numbers
      doc.text(`Page ${i} of ${pageCount}`, 190, 285, { align: "right" })
    }

    // Convert the PDF to a buffer
    const pdfBuffer = Buffer.from(doc.output("arraybuffer"))

    // Return the PDF as a response
    return new NextResponse(pdfBuffer, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="grade-report-${new Date().toISOString().split("T")[0]}.pdf"`,
      },
    })
  } catch (error) {
    console.error("Error generating grade report PDF:", error)
    return NextResponse.json({ error: "Failed to generate grade report PDF" }, { status: 500 })
  }
}
