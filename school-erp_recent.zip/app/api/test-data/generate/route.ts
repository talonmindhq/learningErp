import { type NextRequest, NextResponse } from "next/server"
import {
  generateTestAssessments,
  insertTestAssessments,
  generateTestGrades,
  insertTestGrades,
} from "@/lib/test-data/grade-generator"
import { requireAuth } from "@/app/actions/auth-actions"

export async function POST(request: NextRequest) {
  try {
    // Check if user has admin permissions
    const session = await requireAuth()

    if (session.role !== "Admin") {
      return NextResponse.json({ error: "Only administrators can generate test data" }, { status: 403 })
    }

    const data = await request.json()
    const { assessmentCount = 5, generateGrades = true } = data

    // Generate and insert test assessments
    const assessments = await generateTestAssessments(assessmentCount)

    if (!assessments.length) {
      return NextResponse.json({ error: "Failed to generate test assessments" }, { status: 500 })
    }

    const assessmentIds = await insertTestAssessments(assessments)

    if (!assessmentIds.length) {
      return NextResponse.json({ error: "Failed to insert test assessments" }, { status: 500 })
    }

    let gradesGenerated = false

    // Generate and insert test grades if requested
    if (generateGrades) {
      for (const assessmentId of assessmentIds) {
        const grades = await generateTestGrades(assessmentId)

        if (grades.length) {
          const success = await insertTestGrades(grades)
          if (success) {
            gradesGenerated = true
          }
        }
      }
    }

    return NextResponse.json({
      success: true,
      message: `Successfully generated ${assessmentIds.length} test assessments${gradesGenerated ? " with grades" : ""}`,
      assessmentIds,
    })
  } catch (error) {
    console.error("Error generating test data:", error)
    return NextResponse.json({ error: "Failed to generate test data" }, { status: 500 })
  }
}
