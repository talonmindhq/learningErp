import { DashboardMetrics } from "@/components/dashboard-metrics"
import { RecentStudents } from "@/components/recent-students"
import { FeesSummary } from "@/components/fees-summary"
import { AttendanceSummary } from "@/components/attendance-summary"
import { HelpdeskTickets } from "@/components/helpdesk-tickets"
import { StudentDashboard } from "@/components/student-dashboard"
import { TeacherDashboard } from "@/components/teacher-dashboard"
import { getSession } from "@/app/actions/auth-actions"
import { redirect } from "next/navigation"

export default async function Home() {
  const session = await getSession()

  if (!session) {
    redirect("/auth/login")
  }

  if (session.role === "Student") {
    return <StudentDashboard userId={session.id} />
  }

  if (session.role === "Teacher") {
    return <TeacherDashboard userId={session.id} />
  }

  // Admin dashboard
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Admin Dashboard</h1>
      <DashboardMetrics />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <RecentStudents />
        <FeesSummary />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <AttendanceSummary />
        <HelpdeskTickets />
      </div>
    </div>
  )
}
