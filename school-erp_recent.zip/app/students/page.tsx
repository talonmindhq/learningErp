import Link from "next/link"
import { PlusCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { StudentTable } from "@/components/student-table"
import { PermissionGate } from "@/components/permission-gate"

export default function StudentsPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Students</h1>
        <PermissionGate permission="manage_students">
          <Button asChild>
            <Link href="/students/new">
              <PlusCircle className="mr-2 h-4 w-4" />
              Add Student
            </Link>
          </Button>
        </PermissionGate>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Student Management</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <Input placeholder="Search students..." className="max-w-sm" />
              <Button variant="outline">Search</Button>
            </div>
            <StudentTable />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
