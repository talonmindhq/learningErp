"use server"

import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import { SignJWT, jwtVerify } from "jose"
import { sql } from "@vercel/postgres"

// Secret key for JWT signing
const JWT_SECRET = new TextEncoder().encode(process.env.JWT_SECRET || "default_secret_key_change_in_production")

// Define role-based permissions
const rolePermissions = {
  Admin: [
    "manage_students",
    "manage_teachers",
    "manage_fees",
    "manage_transportation",
    "manage_attendance",
    "manage_reports",
    "manage_helpdesk",
  ],
  Teacher: ["view_students", "manage_attendance", "view_own_profile", "create_helpdesk_tickets"],
  Student: ["view_own_profile", "view_own_fees", "view_own_attendance", "create_helpdesk_tickets"],
}

export async function login(formData: FormData) {
  const email = formData.get("email") as string
  const password = formData.get("password") as string
  const role = formData.get("role") as string

  try {
    // In a real app, we would hash the password and compare with the stored hash
    // For this prototype, we're just checking if the user exists with the given email and role
    const users = await sql.query("SELECT * FROM users WHERE email = $1 AND role = $2", [email, role])

    if (users.length === 0) {
      return { success: false, message: "Invalid email or password" }
    }

    const user = users[0]

    // In a real app, we would verify the password hash here
    // For this prototype, we're just checking if the user exists

    // Get the permissions for the user's role
    const permissions = rolePermissions[role as keyof typeof rolePermissions] || []

    // Create a JWT token
    const token = await new SignJWT({
      id: user.id,
      email: user.email,
      role: user.role,
      permissions,
    })
      .setProtectedHeader({ alg: "HS256" })
      .setIssuedAt()
      .setExpirationTime("24h")
      .sign(JWT_SECRET)

    // Update last login time
    await sql.query("UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = $1", [user.id])

    // Set the token in a cookie
    cookies().set({
      name: "auth_token",
      value: token,
      httpOnly: true,
      path: "/",
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 24, // 1 day
    })

    return {
      success: true,
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        permissions,
      },
    }
  } catch (error) {
    console.error("Login error:", error)
    return { success: false, message: "An error occurred during login" }
  }
}

export async function logout() {
  cookies().delete("auth_token")
  redirect("/auth/login")
}

export async function getSession() {
  const token = cookies().get("auth_token")?.value

  if (!token) {
    return null
  }

  try {
    const verified = await jwtVerify(token, JWT_SECRET)
    return verified.payload as {
      id: number
      email: string
      role: string
      permissions: string[]
    }
  } catch (error) {
    console.error("Session verification error:", error)
    return null
  }
}

export async function requireAuth(permission?: string) {
  const session = await getSession()

  if (!session) {
    redirect("/auth/login")
  }

  if (permission && !session.permissions.includes(permission)) {
    // If a specific permission is required and the user doesn't have it
    redirect("/unauthorized")
  }

  return session
}

export async function hasPermission(permission: string) {
  const session = await getSession()
  return session?.permissions.includes(permission) || false
}
