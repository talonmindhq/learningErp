import { createAssessment, recordGrades, updateAssessment } from "../grade-actions"
import { executeQuery } from "@/lib/db"
import { revalidatePath } from "next/cache"

// Mock the database functions
jest.mock("@/lib/db", () => ({
  executeQuery: jest.fn(),
}))

// Mock the auth actions
jest.mock("@/app/actions/auth-actions", () => ({
  requireAuth: jest.fn().mockResolvedValue({ role: "Admin" }),
}))

// Mock next/cache
jest.mock("next/cache", () => ({
  revalidatePath: jest.fn(),
}))

describe("Grade Actions Error Handling", () => {
  beforeEach(() => {
    // Reset mocks before each test
    jest.clearAllMocks()
  })

  describe("createAssessment", () => {
    it("should reject assessment with invalid weight", async () => {
      // Create a form with weight > 100%
      const formData = new FormData()
      formData.append("name", "Test Assessment")
      formData.append("assessmentTypeId", "1")
      formData.append("subjectId", "1")
      formData.append("maxScore", "100")
      formData.append("weight", "120") // Invalid weight
      formData.append("academicTermId", "1")
      formData.append("grade", "10th")
      formData.append("date", "2023-05-15")

      const result = await createAssessment(formData)
      expect(result.success).toBe(false)
      expect(result.message).toContain("Weight must be between 0 and 100")
    })

    it("should reject assessment with missing required fields", async () => {
      // Create a form with missing fields
      const formData = new FormData()
      formData.append("name", "Test Assessment")
      // Missing assessmentTypeId
      formData.append("subjectId", "1")
      formData.append("maxScore", "100")
      formData.append("weight", "40")
      formData.append("academicTermId", "1")
      formData.append("grade", "10th")
      formData.append("date", "2023-05-15")

      const result = await createAssessment(formData)
      expect(result.success).toBe(false)
      expect(result.message).toContain("Required fields are missing")
    })

    it("should reject assessment if total weight exceeds 100%", async () => {
      // Mock existing assessments with 70% weight already
      ;(executeQuery as jest.Mock).mockResolvedValueOnce([{ weight: 30 }, { weight: 40 }])

      // Create a form with 40% weight (which would make total 110%)
      const formData = new FormData()
      formData.append("name", "Test Assessment")
      formData.append("assessmentTypeId", "1")
      formData.append("subjectId", "1")
      formData.append("maxScore", "100")
      formData.append("weight", "40")
      formData.append("academicTermId", "1")
      formData.append("grade", "10th")
      formData.append("date", "2023-05-15")

      const result = await createAssessment(formData)
      expect(result.success).toBe(false)
      expect(result.message).toContain("Total assessment weight would exceed 100%")
    })

    it("should reject assessment with duplicate name", async () => {
      // Mock empty existing assessments for weight check
      ;(executeQuery as jest.Mock).mockResolvedValueOnce([])

      // Mock existing assessment with same name
      ;(executeQuery as jest.Mock).mockResolvedValueOnce([{ id: 1, name: "Test Assessment" }])

      // Create a form with duplicate name
      const formData = new FormData()
      formData.append("name", "Test Assessment")
      formData.append("assessmentTypeId", "1")
      formData.append("subjectId", "1")
      formData.append("maxScore", "100")
      formData.append("weight", "40")
      formData.append("academicTermId", "1")
      formData.append("grade", "10th")
      formData.append("date", "2023-05-15")

      const result = await createAssessment(formData)
      expect(result.success).toBe(false)
      expect(result.message).toContain("An assessment with this name already exists")
    })

    it("should create assessment successfully with valid data", async () => {
      // Mock empty existing assessments for weight check
      ;(executeQuery as jest.Mock).mockResolvedValueOnce([])

      // Mock empty existing assessments for name check
      ;(executeQuery as jest.Mock).mockResolvedValueOnce([])

      // Mock successful insert
      ;(executeQuery as jest.Mock).mockResolvedValueOnce([{ id: 1 }])

      // Create a form with valid data
      const formData = new FormData()
      formData.append("name", "Valid Assessment")
      formData.append("description", "Test description")
      formData.append("assessmentTypeId", "1")
      formData.append("subjectId", "1")
      formData.append("maxScore", "100")
      formData.append("weight", "40")
      formData.append("academicTermId", "1")
      formData.append("grade", "10th")
      formData.append("date", "2023-05-15")

      const result = await createAssessment(formData)
      expect(result.success).toBe(true)
      expect(result.data).toEqual({ id: 1 })
      expect(revalidatePath).toHaveBeenCalledWith("/grades")
    })
  })

  describe("recordGrades", () => {
    it("should reject grades exceeding max score", async () => {
      // Mock the assessment
      ;(executeQuery as jest.Mock).mockResolvedValueOnce([
        {
          id: 1,
          max_score: 100,
        },
      ])

      // Create a form with invalid grade
      const formData = new FormData()
      formData.append("score_1", "120") // Invalid score

      const result = await recordGrades(1, formData)
      expect(result.success).toBe(false)
      expect(result.message).toContain("Invalid score")
    })

    it("should reject negative grades", async () => {
      // Mock the assessment
      ;(executeQuery as jest.Mock).mockResolvedValueOnce([
        {
          id: 1,
          max_score: 100,
        },
      ])

      // Create a form with negative grade
      const formData = new FormData()
      formData.append("score_1", "-10") // Invalid score

      const result = await recordGrades(1, formData)
      expect(result.success).toBe(false)
      expect(result.message).toContain("Invalid score")
    })

    it("should handle transaction rollback on error", async () => {
      // Mock the assessment
      ;(executeQuery as jest.Mock).mockResolvedValueOnce([
        {
          id: 1,
          max_score: 100,
        },
      ])

      // Mock BEGIN transaction
      ;(executeQuery as jest.Mock).mockResolvedValueOnce([])

      // Mock error during grade update
      ;(executeQuery as jest.Mock).mockRejectedValueOnce(new Error("Database error"))

      // Mock ROLLBACK
      ;(executeQuery as jest.Mock).mockResolvedValueOnce([])

      // Create a form with valid grades
      const formData = new FormData()
      formData.append("score_1", "85")

      const result = await recordGrades(1, formData)
      expect(result.success).toBe(false)

      // Verify ROLLBACK was called
      expect(executeQuery).toHaveBeenCalledWith("ROLLBACK")
    })

    it("should record grades successfully with valid data", async () => {
      // Mock the assessment
      ;(executeQuery as jest.Mock).mockResolvedValueOnce([
        {
          id: 1,
          max_score: 100,
        },
      ])

      // Mock BEGIN transaction
      ;(executeQuery as jest.Mock).mockResolvedValueOnce([])

      // Mock existing grade check (no existing grade)
      ;(executeQuery as jest.Mock).mockResolvedValueOnce([])

      // Mock insert grade
      ;(executeQuery as jest.Mock).mockResolvedValueOnce([])

      // Mock COMMIT
      ;(executeQuery as jest.Mock).mockResolvedValueOnce([])

      // Create a form with valid grades
      const formData = new FormData()
      formData.append("score_1", "85")
      formData.append("remarks_1", "Good work")

      const result = await recordGrades(1, formData)
      expect(result.success).toBe(true)

      // Verify COMMIT was called
      expect(executeQuery).toHaveBeenCalledWith("COMMIT")
      expect(revalidatePath).toHaveBeenCalledWith("/grades")
    })
  })

  describe("updateAssessment", () => {
    it("should reject update if assessment not found", async () => {
      // Mock empty result for assessment lookup
      ;(executeQuery as jest.Mock).mockResolvedValueOnce([])

      const formData = new FormData()
      formData.append("name", "Updated Assessment")
      formData.append("assessmentTypeId", "1")
      formData.append("subjectId", "1")
      formData.append("maxScore", "100")
      formData.append("weight", "40")
      formData.append("academicTermId", "1")
      formData.append("grade", "10th")
      formData.append("date", "2023-05-15")

      const result = await updateAssessment(999, formData)
      expect(result.success).toBe(false)
      expect(result.message).toContain("Assessment not found")
    })

    it("should update assessment successfully with valid data", async () => {
      // Mock existing assessment
      ;(executeQuery as jest.Mock).mockResolvedValueOnce([
        {
          id: 1,
          name: "Original Assessment",
          weight: 30,
        },
      ])

      // Mock no duplicate name check
      ;(executeQuery as jest.Mock).mockResolvedValueOnce([])

      // Mock other assessments for weight check
      ;(executeQuery as jest.Mock).mockResolvedValueOnce([
        { weight: 30 }, // Total of other assessments: 30%
      ])

      // Mock update query
      ;(executeQuery as jest.Mock).mockResolvedValueOnce([])

      const formData = new FormData()
      formData.append("name", "Updated Assessment")
      formData.append("description", "Updated description")
      formData.append("assessmentTypeId", "1")
      formData.append("subjectId", "1")
      formData.append("maxScore", "100")
      formData.append("weight", "70") // This plus 30% from other assessments = 100%
      formData.append("academicTermId", "1")
      formData.append("grade", "10th")
      formData.append("date", "2023-05-15")
      formData.append("status", "Active")

      const result = await updateAssessment(1, formData)
      expect(result.success).toBe(true)
      expect(revalidatePath).toHaveBeenCalledWith("/grades")
      expect(revalidatePath).toHaveBeenCalledWith("/grades/1")
    })
  })
})
