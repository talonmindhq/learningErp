"use server"
import { sql } from "@/lib/db"

export async function getAttendance(date?: string) {
  try {
    let query = `
      SELECT a.*, s.first_name, s.last_name, c.name as class_name
      FROM attendance a
      JOIN students s ON a.student_id = s.id
      JOIN classes c ON s.class_id = c.id
    `

    const params = []

    if (date) {
      query += " WHERE a.date = $1"
      params.push(date)
    }

    query += " ORDER BY a.date DESC, s.last_name, s.first_name"

    // Update this query to use sql.query
    const attendance = await sql.query(query, params)
    return { success: true, attendance }
  } catch (error) {
    console.error("Error fetching attendance:", error)
    return { success: false, message: "Failed to fetch attendance" }
  }
}

export async function getAttendanceByClass(classId: number, date: string) {
  try {
    // Update this query to use sql.query
    const attendance = await sql.query(
      `
      SELECT a.*, s.first_name, s.last_name
      FROM attendance a
      JOIN students s ON a.student_id = s.id
      WHERE s.class_id = $1 AND a.date = $2
      ORDER BY s.last_name, s.first_name
    `,
      [classId, date],
    )

    return { success: true, attendance }
  } catch (error) {
    console.error(`Error fetching attendance for class ${classId}:`, error)
    return { success: false, message: "Failed to fetch attendance" }
  }
}

export async function getStudentsByClass(classId: number) {
  try {
    // Update this query to use sql.query
    const students = await sql.query(
      `
      SELECT id, first_name, last_name
      FROM students
      WHERE class_id = $1
      ORDER BY last_name, first_name
    `,
      [classId],
    )

    return { success: true, students }
  } catch (error) {
    console.error(`Error fetching students for class ${classId}:`, error)
    return { success: false, message: "Failed to fetch students" }
  }
}

export async function markAttendance(formData: FormData) {
  const date = formData.get("date") as string
  const classId = Number.parseInt(formData.get("classId") as string)

  try {
    // Get all students in the class
    const studentsResult = await getStudentsByClass(classId)

    if (!studentsResult.success) {
      return studentsResult
    }

    const students = studentsResult.students

    // Begin transaction
    await sql.query("BEGIN")

    // Delete existing attendance records for this class and date
    await sql.query(
      `
      DELETE FROM attendance
      WHERE student_id IN (
        SELECT id FROM students WHERE class_id = $1
      ) AND date = $2
    `,
      [classId, date],
    )

    // Insert new attendance records
    for (const student of students) {
      const status = formData.get(`status-${student.id}`) as string
      const remarks = (formData.get(`remarks-${student.id}`) as string) || null

      await sql.query("INSERT INTO attendance (student_id, date, status, remarks) VALUES ($1, $2, $3, $4)", [
        student.id,
        date,
        status,
        remarks,
      ])
    }

    // Commit transaction
    await sql.query("COMMIT")

    return { success: true, message: "Attendance marked successfully" }
  } catch (error) {
    // Rollback transaction on error
    await sql.query("ROLLBACK")
    console.error("Error marking attendance:", error)
    return { success: false, message: "Failed to mark attendance" }
  }
}

export async function getAttendanceReport(studentId: number, startDate: string, endDate: string) {
  try {
    // Update this query to use sql.query
    const attendance = await sql.query(
      `
      SELECT a.*, s.first_name, s.last_name
      FROM attendance a
      JOIN students s ON a.student_id = s.id
      WHERE a.student_id = $1 AND a.date BETWEEN $2 AND $3
      ORDER BY a.date
    `,
      [studentId, startDate, endDate],
    )

    return { success: true, attendance }
  } catch (error) {
    console.error(`Error fetching attendance report for student ${studentId}:`, error)
    return { success: false, message: "Failed to fetch attendance report" }
  }
}
