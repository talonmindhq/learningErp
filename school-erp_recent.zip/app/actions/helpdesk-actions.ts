"use server"

import { executeQuery } from "@/lib/db"
import { revalidatePath } from "next/cache"

export async function getHelpdeskTickets() {
  try {
    const tickets = await executeQuery(`
      SELECT * FROM helpdesk
      ORDER BY created_at DESC
    `)
    return { success: true, data: tickets }
  } catch (error) {
    console.error("Error fetching helpdesk tickets:", error)
    return { success: false, message: "Failed to fetch helpdesk tickets" }
  }
}

export async function getHelpdeskTicketById(id: number) {
  try {
    const tickets = await executeQuery("SELECT * FROM helpdesk WHERE id = $1", [id])

    if (tickets.length === 0) {
      return { success: false, message: "Ticket not found" }
    }

    return { success: true, data: tickets[0] }
  } catch (error) {
    console.error(`Error fetching helpdesk ticket with ID ${id}:`, error)
    return { success: false, message: "Failed to fetch ticket details" }
  }
}

export async function createHelpdeskTicket(formData: FormData) {
  try {
    const subject = formData.get("subject") as string
    const description = formData.get("description") as string
    const userId = Number.parseInt(formData.get("userId") as string)
    const userRole = formData.get("userRole") as string

    // Validate required fields
    if (!subject || !description || !userId || !userRole) {
      return { success: false, message: "Required fields are missing" }
    }

    // Insert new helpdesk ticket
    const result = await executeQuery(
      `INSERT INTO helpdesk 
       (subject, description, user_id, user_role) 
       VALUES ($1, $2, $3, $4) 
       RETURNING id`,
      [subject, description, userId, userRole],
    )

    revalidatePath("/helpdesk")
    return { success: true, data: result[0] }
  } catch (error) {
    console.error("Error creating helpdesk ticket:", error)
    return { success: false, message: "Failed to create helpdesk ticket" }
  }
}

export async function updateHelpdeskTicketStatus(id: number, status: string) {
  try {
    // Check if ticket exists
    const tickets = await executeQuery("SELECT id FROM helpdesk WHERE id = $1", [id])

    if (tickets.length === 0) {
      return { success: false, message: "Ticket not found" }
    }

    // Update ticket status
    await executeQuery(
      `UPDATE helpdesk 
       SET status = $1, updated_at = CURRENT_TIMESTAMP
       WHERE id = $2`,
      [status, id],
    )

    revalidatePath("/helpdesk")
    revalidatePath(`/helpdesk/${id}`)
    return { success: true }
  } catch (error) {
    console.error(`Error updating helpdesk ticket status for ID ${id}:`, error)
    return { success: false, message: "Failed to update ticket status" }
  }
}

export async function getUserTickets(userId: number, userRole: string) {
  try {
    const tickets = await executeQuery(
      `
      SELECT * FROM helpdesk
      WHERE user_id = $1 AND user_role = $2
      ORDER BY created_at DESC
    `,
      [userId, userRole],
    )

    return { success: true, data: tickets }
  } catch (error) {
    console.error(`Error fetching tickets for user ID ${userId}:`, error)
    return { success: false, message: "Failed to fetch user tickets" }
  }
}
