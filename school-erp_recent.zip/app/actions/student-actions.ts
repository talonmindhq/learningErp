"use server"
import { sql } from "@/lib/db"

export async function getStudents() {
  try {
    // Update this query to use sql.query
    const students = await sql.query("SELECT * FROM students ORDER BY last_name, first_name")
    return { success: true, students }
  } catch (error) {
    console.error("Error fetching students:", error)
    return { success: false, message: "Failed to fetch students" }
  }
}

export async function getStudentById(id: number) {
  try {
    // Update this query to use sql.query
    const students = await sql.query("SELECT * FROM students WHERE id = $1", [id])
    if (students.length === 0) {
      return { success: false, message: "Student not found" }
    }
    return { success: true, student: students[0] }
  } catch (error) {
    console.error(`Error fetching student ${id}:`, error)
    return { success: false, message: "Failed to fetch student" }
  }
}

export async function addStudent(formData: FormData) {
  const firstName = formData.get("firstName") as string
  const lastName = formData.get("lastName") as string
  const email = formData.get("email") as string
  const dateOfBirth = formData.get("dateOfBirth") as string
  const gender = formData.get("gender") as string
  const address = formData.get("address") as string
  const phone = formData.get("phone") as string
  const classId = Number.parseInt(formData.get("classId") as string)

  try {
    // Update this query to use sql.query
    await sql.query(
      "INSERT INTO students (first_name, last_name, email, date_of_birth, gender, address, phone, class_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)",
      [firstName, lastName, email, dateOfBirth, gender, address, phone, classId],
    )
    return { success: true, message: "Student added successfully" }
  } catch (error) {
    console.error("Error adding student:", error)
    return { success: false, message: "Failed to add student" }
  }
}

export async function updateStudent(id: number, formData: FormData) {
  const firstName = formData.get("firstName") as string
  const lastName = formData.get("lastName") as string
  const email = formData.get("email") as string
  const dateOfBirth = formData.get("dateOfBirth") as string
  const gender = formData.get("gender") as string
  const address = formData.get("address") as string
  const phone = formData.get("phone") as string
  const classId = Number.parseInt(formData.get("classId") as string)

  try {
    // Update this query to use sql.query
    await sql.query(
      "UPDATE students SET first_name = $1, last_name = $2, email = $3, date_of_birth = $4, gender = $5, address = $6, phone = $7, class_id = $8 WHERE id = $9",
      [firstName, lastName, email, dateOfBirth, gender, address, phone, classId, id],
    )
    return { success: true, message: "Student updated successfully" }
  } catch (error) {
    console.error(`Error updating student ${id}:`, error)
    return { success: false, message: "Failed to update student" }
  }
}

export async function deleteStudent(id: number) {
  try {
    // Update this query to use sql.query
    await sql.query("DELETE FROM students WHERE id = $1", [id])
    return { success: true, message: "Student deleted successfully" }
  } catch (error) {
    console.error(`Error deleting student ${id}:`, error)
    return { success: false, message: "Failed to delete student" }
  }
}
