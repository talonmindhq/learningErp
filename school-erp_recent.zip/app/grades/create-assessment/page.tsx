"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"
import { createAssessment, getAssessmentTypes, getSubjects, getAcademicTerms } from "@/app/actions/grade-actions"

const formSchema = z.object({
  name: z.string().min(2, {
    message: "Name must be at least 2 characters.",
  }),
  description: z.string().optional(),
  assessmentTypeId: z.string({
    required_error: "Please select an assessment type.",
  }),
  subjectId: z.string({
    required_error: "Please select a subject.",
  }),
  maxScore: z.string().refine(
    (val) => {
      const num = Number.parseInt(val)
      return !isNaN(num) && num > 0
    },
    {
      message: "Max score must be a positive number.",
    },
  ),
  weight: z.string().refine(
    (val) => {
      const num = Number.parseFloat(val)
      return !isNaN(num) && num > 0 && num <= 100
    },
    {
      message: "Weight must be a number between 0 and 100.",
    },
  ),
  academicTermId: z.string({
    required_error: "Please select an academic term.",
  }),
  grade: z.string({
    required_error: "Please select a grade.",
  }),
  date: z.string({
    required_error: "Please select a date.",
  }),
})

export default function CreateAssessmentPage() {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [assessmentTypes, setAssessmentTypes] = useState<any[]>([])
  const [subjects, setSubjects] = useState<any[]>([])
  const [academicTerms, setAcademicTerms] = useState<any[]>([])
  const [grades] = useState(["9th", "10th", "11th", "12th"])
  const [weightWarning, setWeightWarning] = useState<string | null>(null)

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      description: "",
      assessmentTypeId: "",
      subjectId: "",
      maxScore: "100",
      weight: "",
      academicTermId: "",
      grade: "",
      date: new Date().toISOString().split("T")[0],
    },
  })

  useEffect(() => {
    async function fetchData() {
      try {
        const [typesResult, subjectsResult, termsResult] = await Promise.all([
          getAssessmentTypes(),
          getSubjects(),
          getAcademicTerms(),
        ])

        if (typesResult.success) {
          setAssessmentTypes(typesResult.data)
        }

        if (subjectsResult.success) {
          setSubjects(subjectsResult.data)
        }

        if (termsResult.success) {
          setAcademicTerms(termsResult.data)
        }
      } catch (error) {
        console.error("Error fetching form data:", error)
        toast({
          title: "Error",
          description: "Failed to load form data. Please try again.",
          variant: "destructive",
        })
      }
    }

    fetchData()
  }, [])

  // Validate weight when subject, term, and grade are selected
  useEffect(() => {
    const subscription = form.watch((value, { name }) => {
      if (
        (name === "subjectId" || name === "academicTermId" || name === "grade" || name === "weight") &&
        value.subjectId &&
        value.academicTermId &&
        value.grade &&
        value.weight
      ) {
        validateWeight(
          Number.parseInt(value.subjectId),
          Number.parseInt(value.academicTermId),
          value.grade as string,
          Number.parseFloat(value.weight as string),
        )
      }
    })

    return () => subscription.unsubscribe()
  }, [form.watch])

  async function validateWeight(subjectId: number, termId: number, grade: string, weight: number) {
    try {
      // This would be a server action to get existing assessments and validate weight
      // For now, we'll just show a warning if weight is over 30%
      if (weight > 30) {
        setWeightWarning(
          "Warning: Assessment weight is over 30%. Please ensure the total weight for all assessments doesn't exceed 100%.",
        )
      } else {
        setWeightWarning(null)
      }
    } catch (error) {
      console.error("Error validating weight:", error)
    }
  }

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsSubmitting(true)

    try {
      const formData = new FormData()
      formData.append("name", values.name)
      formData.append("description", values.description || "")
      formData.append("assessmentTypeId", values.assessmentTypeId)
      formData.append("subjectId", values.subjectId)
      formData.append("maxScore", values.maxScore)
      formData.append("weight", values.weight)
      formData.append("academicTermId", values.academicTermId)
      formData.append("grade", values.grade)
      formData.append("date", values.date)

      const result = await createAssessment(formData)

      if (result.success) {
        toast({
          title: "Assessment Created",
          description: "The assessment has been successfully created.",
        })
        router.push("/grades")
      } else {
        toast({
          title: "Error",
          description: result.message || "Failed to create assessment. Please try again.",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error creating assessment:", error)
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Create Assessment</h1>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Assessment Information</CardTitle>
          <CardDescription>Enter the details of the new assessment.</CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Assessment Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Midterm Exam" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="assessmentTypeId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Assessment Type</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select an assessment type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {assessmentTypes.map((type) => (
                            <SelectItem key={type.id} value={type.id.toString()}>
                              {type.name} ({type.weight}%)
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormDescription>The type of assessment determines its default weight.</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="subjectId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Subject</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a subject" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {subjects.map((subject) => (
                            <SelectItem key={subject.id} value={subject.id.toString()}>
                              {subject.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="grade"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Grade</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a grade" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {grades.map((grade) => (
                            <SelectItem key={grade} value={grade}>
                              {grade} Grade
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="academicTermId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Academic Term</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select an academic term" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {academicTerms.map((term) => (
                            <SelectItem key={term.id} value={term.id.toString()}>
                              {term.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="date"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="maxScore"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Maximum Score</FormLabel>
                      <FormControl>
                        <Input type="number" min="1" {...field} />
                      </FormControl>
                      <FormDescription>The maximum possible score for this assessment.</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="weight"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Weight (%)</FormLabel>
                      <FormControl>
                        <Input type="number" min="1" max="100" step="0.1" {...field} />
                      </FormControl>
                      <FormDescription>
                        The percentage weight of this assessment in the final grade.
                        {weightWarning && <p className="mt-1 text-yellow-600">{weightWarning}</p>}
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Enter a description of the assessment"
                        className="resize-none"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex justify-end space-x-4">
                <Button variant="outline" asChild>
                  <Link href="/grades">Cancel</Link>
                </Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? "Creating..." : "Create Assessment"}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  )
}
