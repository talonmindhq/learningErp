import {
  calculateWeightedGrade,
  calculateLetterGrade,
  calculateClassStatistics,
  validateAssessmentWeights,
  validateGradeInput,
} from "../grade-calculator"

describe("Grade Calculator Tests", () => {
  // Weighted Grade Calculation Tests
  describe("calculateWeightedGrade", () => {
    it("should calculate weighted grade correctly", () => {
      const assessments = [
        { score: 80, weight: 40 },
        { score: 90, weight: 60 },
      ]
      // Expected: (80 * 0.4) + (90 * 0.6) = 32 + 54 = 86
      const finalGrade = calculateWeightedGrade(assessments)
      expect(finalGrade).toBe(86)
    })

    it("should handle empty assessments", () => {
      expect(calculateWeightedGrade([])).toBe(0)
    })

    it("should handle single assessment", () => {
      expect(calculateWeightedGrade([{ score: 85, weight: 100 }])).toBe(85)
    })

    it("should handle weights that don't sum to 100%", () => {
      // Mock console.warn to verify warning is logged
      const originalWarn = console.warn
      console.warn = jest.fn()

      const assessments = [
        { score: 80, weight: 30 },
        { score: 90, weight: 50 },
      ]
      // Should still calculate but log a warning
      const result = calculateWeightedGrade(assessments)

      // Verify warning was logged
      expect(console.warn).toHaveBeenCalledWith(expect.stringContaining("Assessment weights sum to 80%, not 100%"))

      // Restore original console.warn
      console.warn = originalWarn

      // Expected result: (80 * 0.3) + (90 * 0.5) = 24 + 45 = 69
      expect(result).toBe(69)
    })

    it("should handle fractional results correctly", () => {
      const assessments = [
        { score: 85.5, weight: 25 },
        { score: 92.3, weight: 75 },
      ]
      // Expected: (85.5 * 0.25) + (92.3 * 0.75) = 21.375 + 69.225 = 90.6
      // Should round to 2 decimal places = 90.60
      const finalGrade = calculateWeightedGrade(assessments)
      expect(finalGrade).toBeCloseTo(90.6, 2)
    })
  })

  // Letter Grade Tests
  describe("calculateLetterGrade", () => {
    it("should assign correct letter grades", () => {
      expect(calculateLetterGrade(95)).toBe("A")
      expect(calculateLetterGrade(85)).toBe("B")
      expect(calculateLetterGrade(75)).toBe("C")
      expect(calculateLetterGrade(65)).toBe("D")
      expect(calculateLetterGrade(55)).toBe("F")
    })

    it("should handle boundary cases correctly", () => {
      // Boundary cases
      expect(calculateLetterGrade(90)).toBe("A")
      expect(calculateLetterGrade(89.99)).toBe("B")
      expect(calculateLetterGrade(80)).toBe("B")
      expect(calculateLetterGrade(79.99)).toBe("C")
      expect(calculateLetterGrade(70)).toBe("C")
      expect(calculateLetterGrade(69.99)).toBe("D")
      expect(calculateLetterGrade(60)).toBe("D")
      expect(calculateLetterGrade(59.99)).toBe("F")
    })

    it("should handle extreme values", () => {
      expect(calculateLetterGrade(100)).toBe("A")
      expect(calculateLetterGrade(0)).toBe("F")
      // Values outside normal range should still work
      expect(calculateLetterGrade(110)).toBe("A")
      expect(calculateLetterGrade(-10)).toBe("F")
    })
  })

  // Class Statistics Tests
  describe("calculateClassStatistics", () => {
    it("should calculate class statistics correctly", () => {
      const grades = [95, 87, 72, 65, 90, 88, 45, 78]
      const stats = calculateClassStatistics(grades)

      expect(stats.average).toBeCloseTo(77.5, 1)
      expect(stats.highest).toBe(95)
      expect(stats.lowest).toBe(45)
      expect(stats.median).toBe(82.5) // (78 + 87) / 2
      expect(stats.passingRate).toBe(88) // 7 out of 8 grades are >= 60
    })

    it("should handle empty grades array", () => {
      const stats = calculateClassStatistics([])
      expect(stats).toEqual({
        average: 0,
        highest: 0,
        lowest: 0,
        median: 0,
        passingRate: 0,
      })
    })

    it("should handle single grade", () => {
      const stats = calculateClassStatistics([85])
      expect(stats.average).toBe(85)
      expect(stats.highest).toBe(85)
      expect(stats.lowest).toBe(85)
      expect(stats.median).toBe(85)
      expect(stats.passingRate).toBe(100)
    })

    it("should calculate median correctly for odd number of grades", () => {
      const grades = [95, 87, 72, 65, 90]
      const stats = calculateClassStatistics(grades)
      // Sorted: [65, 72, 87, 90, 95]
      expect(stats.median).toBe(87) // Middle value
    })
  })

  // Assessment Weight Validation Tests
  describe("validateAssessmentWeights", () => {
    it("should validate correct weights", () => {
      const validAssessments = [{ weight: 40 }, { weight: 60 }]
      const result = validateAssessmentWeights(validAssessments)
      expect(result.valid).toBe(true)
      expect(result.totalWeight).toBe(100)
    })

    it("should reject incorrect weights", () => {
      const invalidAssessments = [{ weight: 40 }, { weight: 40 }]
      const result = validateAssessmentWeights(invalidAssessments)
      expect(result.valid).toBe(false)
      expect(result.message).toContain("Assessment weights sum to 80%, not 100%")
      expect(result.totalWeight).toBe(80)
    })

    it("should allow small rounding errors", () => {
      const assessments = [{ weight: 33.33 }, { weight: 33.33 }, { weight: 33.33 }]
      // Total is 99.99, but should be considered valid due to rounding
      const result = validateAssessmentWeights(assessments)
      expect(result.valid).toBe(true)
    })

    it("should handle empty assessments", () => {
      const result = validateAssessmentWeights([])
      expect(result.valid).toBe(false)
      expect(result.totalWeight).toBe(0)
    })
  })

  // Grade Input Validation Tests
  describe("validateGradeInput", () => {
    it("should validate grades within range", () => {
      expect(validateGradeInput(85).valid).toBe(true)
      expect(validateGradeInput(0).valid).toBe(true)
      expect(validateGradeInput(100).valid).toBe(true)
    })

    it("should reject grades outside range", () => {
      const negativeResult = validateGradeInput(-5)
      expect(negativeResult.valid).toBe(false)
      expect(negativeResult.message).toContain("Grade cannot be negative")

      const tooHighResult = validateGradeInput(105)
      expect(tooHighResult.valid).toBe(false)
      expect(tooHighResult.message).toContain("Grade cannot exceed maximum score")
    })

    it("should respect custom max score", () => {
      expect(validateGradeInput(150, 200).valid).toBe(true)

      const tooHighResult = validateGradeInput(250, 200)
      expect(tooHighResult.valid).toBe(false)
      expect(tooHighResult.message).toContain("Grade cannot exceed maximum score of 200")
    })
  })
})
