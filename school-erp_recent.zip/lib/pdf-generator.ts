import { jsPDF } from "jspdf"
import "jspdf-autotable"
import { executeQuery } from "./db"

// Extend the jsPDF type to include autoTable
declare module "jspdf" {
  interface jsPDF {
    autoTable: (options: any) => jsPDF
  }
}

export async function generateFeeInvoice(feeId: number): Promise<Buffer> {
  try {
    // Fetch fee details
    const fees = await executeQuery(
      `
      SELECT f.*, 
             s.first_name || ' ' || s.last_name as student_name,
             s.grade,
             s.email,
             s.phone
      FROM fees f
      JOIN students s ON f.student_id = s.id
      WHERE f.id = $1
    `,
      [feeId],
    )

    if (fees.length === 0) {
      throw new Error("Fee not found")
    }

    const fee = fees[0]

    // Create a new PDF document
    const doc = new jsPDF()

    // Add school logo/header
    doc.setFontSize(20)
    doc.setTextColor(0, 0, 128)
    doc.text("School 360", 105, 20, { align: "center" })

    doc.setFontSize(12)
    doc.setTextColor(0, 0, 0)
    doc.text("123 Education Street, City, Country", 105, 30, { align: "center" })
    doc.text("Phone: +1 234 567 8900 | Email: info@school360.com", 105, 35, { align: "center" })

    // Add invoice title
    doc.setFontSize(16)
    doc.setTextColor(0, 0, 128)
    doc.text("FEE INVOICE", 105, 50, { align: "center" })

    // Add invoice details
    doc.setFontSize(10)
    doc.setTextColor(0, 0, 0)

    // Left side details
    doc.text("Invoice To:", 20, 65)
    doc.text(`Student Name: ${fee.student_name}`, 20, 70)
    doc.text(`Grade: ${fee.grade}`, 20, 75)
    doc.text(`Email: ${fee.email}`, 20, 80)
    doc.text(`Phone: ${fee.phone}`, 20, 85)

    // Right side details
    doc.text(`Invoice Number: INV-${fee.id.toString().padStart(5, "0")}`, 140, 65)
    doc.text(`Invoice Date: ${new Date().toLocaleDateString()}`, 140, 70)
    doc.text(`Due Date: ${new Date(fee.due_date).toLocaleDateString()}`, 140, 75)
    doc.text(`Status: ${fee.status}`, 140, 80)

    // Add fee details table
    doc.autoTable({
      startY: 95,
      head: [["Fee Type", "Description", "Amount"]],
      body: [[fee.fee_type, `${fee.fee_type} for ${fee.student_name}`, `$${fee.amount.toFixed(2)}`]],
      foot: [["", "Total", `$${fee.amount.toFixed(2)}`]],
      theme: "grid",
      headStyles: { fillColor: [0, 0, 128], textColor: [255, 255, 255] },
      footStyles: { fillColor: [240, 240, 240], textColor: [0, 0, 0], fontStyle: "bold" },
    })

    // Add payment instructions
    const finalY = (doc as any).lastAutoTable.finalY + 10

    doc.setFontSize(11)
    doc.text("Payment Instructions:", 20, finalY)
    doc.setFontSize(10)
    doc.text("1. Please make payment before the due date.", 20, finalY + 5)
    doc.text("2. Payment can be made by bank transfer or at the school finance office.", 20, finalY + 10)
    doc.text("3. Please include the invoice number as reference when making payment.", 20, finalY + 15)

    // Add footer
    doc.setFontSize(8)
    doc.text("This is a computer-generated invoice and does not require a signature.", 105, 280, { align: "center" })

    // Convert the PDF to a buffer
    const pdfBuffer = Buffer.from(doc.output("arraybuffer"))

    return pdfBuffer
  } catch (error) {
    console.error("Error generating fee invoice:", error)
    throw error
  }
}

export async function generateStudentReport(studentId: number): Promise<Buffer> {
  try {
    // Fetch student details
    const students = await executeQuery(
      `
      SELECT s.*, 
             tr.name as transport_route_name
      FROM students s
      LEFT JOIN transport_routes tr ON s.transport_route_id = tr.id
      WHERE s.id = $1
    `,
      [studentId],
    )

    if (students.length === 0) {
      throw new Error("Student not found")
    }

    const student = students[0]

    // Fetch fee details
    const fees = await executeQuery(
      `
      SELECT * FROM fees
      WHERE student_id = $1
      ORDER BY due_date DESC
    `,
      [studentId],
    )

    // Fetch attendance details
    const attendance = await executeQuery(
      `
      SELECT * FROM attendance
      WHERE student_id = $1
      ORDER BY date DESC
      LIMIT 10
    `,
      [studentId],
    )

    // Create a new PDF document
    const doc = new jsPDF()

    // Add school logo/header
    doc.setFontSize(20)
    doc.setTextColor(0, 0, 128)
    doc.text("School 360", 105, 20, { align: "center" })

    doc.setFontSize(12)
    doc.setTextColor(0, 0, 0)
    doc.text("123 Education Street, City, Country", 105, 30, { align: "center" })
    doc.text("Phone: +1 234 567 8900 | Email: info@school360.com", 105, 35, { align: "center" })

    // Add report title
    doc.setFontSize(16)
    doc.setTextColor(0, 0, 128)
    doc.text("STUDENT REPORT", 105, 50, { align: "center" })

    // Add student details
    doc.setFontSize(12)
    doc.setTextColor(0, 0, 0)
    doc.text("Student Details:", 20, 65)

    doc.setFontSize(10)
    doc.text(`Name: ${student.first_name} ${student.last_name}`, 20, 70)
    doc.text(`Grade: ${student.grade}`, 20, 75)
    doc.text(`Email: ${student.email}`, 20, 80)
    doc.text(`Phone: ${student.phone}`, 20, 85)
    doc.text(`Address: ${student.address}`, 20, 90)
    doc.text(`Admission Date: ${new Date(student.admission_date).toLocaleDateString()}`, 20, 95)
    doc.text(`Transport Route: ${student.transport_route_name || "None"}`, 20, 100)
    doc.text(`Status: ${student.status}`, 20, 105)

    // Add fee details table
    doc.setFontSize(12)
    doc.text("Fee Details:", 20, 120)

    const feeData = fees.map((fee) => [
      new Date(fee.due_date).toLocaleDateString(),
      fee.fee_type,
      `$${fee.amount.toFixed(2)}`,
      fee.status,
      fee.payment_date ? new Date(fee.payment_date).toLocaleDateString() : "-",
    ])

    doc.autoTable({
      startY: 125,
      head: [["Due Date", "Fee Type", "Amount", "Status", "Payment Date"]],
      body: feeData.length > 0 ? feeData : [["No fee records found", "", "", "", ""]],
      theme: "grid",
      headStyles: { fillColor: [0, 0, 128], textColor: [255, 255, 255] },
    })

    // Add attendance details table
    const finalY = (doc as any).lastAutoTable.finalY + 10

    doc.setFontSize(12)
    doc.text("Recent Attendance:", 20, finalY)

    const attendanceData = attendance.map((record) => [
      new Date(record.date).toLocaleDateString(),
      record.status,
      new Date(record.recorded_at).toLocaleString(),
    ])

    doc.autoTable({
      startY: finalY + 5,
      head: [["Date", "Status", "Recorded At"]],
      body: attendanceData.length > 0 ? attendanceData : [["No attendance records found", "", ""]],
      theme: "grid",
      headStyles: { fillColor: [0, 0, 128], textColor: [255, 255, 255] },
    })

    // Add footer
    doc.setFontSize(8)
    doc.text("This is a computer-generated report and does not require a signature.", 105, 280, { align: "center" })

    // Convert the PDF to a buffer
    const pdfBuffer = Buffer.from(doc.output("arraybuffer"))

    return pdfBuffer
  } catch (error) {
    console.error("Error generating student report:", error)
    throw error
  }
}
