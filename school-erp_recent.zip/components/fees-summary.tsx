import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export function FeesSummary() {
  const fees = [
    {
      id: 1,
      student: "Olivia Martin",
      type: "Tuition Fee",
      amount: 1200,
      dueDate: "2023-05-15",
      status: "Paid",
    },
    {
      id: 2,
      student: "Jackson Lee",
      type: "Transport Fee",
      amount: 300,
      dueDate: "2023-05-15",
      status: "Pending",
    },
    {
      id: 3,
      student: "Isabella Nguyen",
      type: "Library Fee",
      amount: 150,
      dueDate: "2023-05-20",
      status: "Paid",
    },
    {
      id: 4,
      student: "William Kim",
      type: "Tuition Fee",
      amount: 1200,
      dueDate: "2023-05-15",
      status: "Overdue",
    },
    {
      id: 5,
      student: "Sofia Davis",
      type: "Lab Fee",
      amount: 250,
      dueDate: "2023-05-25",
      status: "Pending",
    },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Fees</CardTitle>
        <CardDescription>Recent fee transactions in the system.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {fees.map((fee) => (
            <div key={fee.id} className="flex items-center justify-between space-x-4">
              <div>
                <p className="text-sm font-medium leading-none">{fee.student}</p>
                <p className="text-sm text-muted-foreground">{fee.type}</p>
              </div>
              <div className="flex items-center space-x-2">
                <p className="text-sm font-medium">${fee.amount}</p>
                <Badge
                  variant={fee.status === "Paid" ? "default" : fee.status === "Pending" ? "outline" : "destructive"}
                >
                  {fee.status}
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
