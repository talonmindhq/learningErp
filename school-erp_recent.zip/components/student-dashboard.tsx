import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { executeQuery } from "@/lib/db"

interface StudentDashboardProps {
  userId: number
}

async function getStudentData(userId: number) {
  try {
    // Get student profile
    const students = await executeQuery(
      `
      SELECT s.*, tr.name as transport_route_name 
      FROM students s
      LEFT JOIN transport_routes tr ON s.transport_route_id = tr.id
      WHERE s.id = $1
    `,
      [userId],
    )

    if (students.length === 0) {
      return null
    }

    // Get student fees
    const fees = await executeQuery(
      `
      SELECT * FROM fees
      WHERE student_id = $1
      ORDER BY due_date DESC
      LIMIT 5
    `,
      [userId],
    )

    // Get student attendance
    const attendance = await executeQuery(
      `
      SELECT * FROM attendance
      WHERE student_id = $1
      ORDER BY date DESC
      LIMIT 5
    `,
      [userId],
    )

    // Get student helpdesk tickets
    const tickets = await executeQuery(
      `
      SELECT * FROM helpdesk
      WHERE user_id = $1 AND user_role = 'Student'
      ORDER BY created_at DESC
      LIMIT 5
    `,
      [userId],
    )

    return {
      profile: students[0],
      fees,
      attendance,
      tickets,
    }
  } catch (error) {
    console.error("Error fetching student data:", error)
    return null
  }
}

export async function StudentDashboard({ userId }: StudentDashboardProps) {
  const data = await getStudentData(userId)

  if (!data) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Student Dashboard</h1>
        <p>Error loading dashboard data. Please contact an administrator.</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Student Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>My Profile</CardTitle>
            <CardDescription>Your personal information</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Name</p>
                <p className="font-medium">{`${data.profile.first_name} ${data.profile.last_name}`}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Grade</p>
                <p>{data.profile.grade}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Transport Route</p>
                <p>{data.profile.transport_route_name || "None"}</p>
              </div>
              <div className="pt-2">
                <Button asChild variant="outline" size="sm">
                  <Link href="/profile">View Full Profile</Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Fees</CardTitle>
            <CardDescription>Your recent fee records</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {data.fees.length === 0 ? (
                <p>No fee records found.</p>
              ) : (
                data.fees.map((fee: any) => (
                  <div key={fee.id} className="flex items-center justify-between space-x-4">
                    <div>
                      <p className="text-sm font-medium leading-none">{fee.fee_type}</p>
                      <p className="text-sm text-muted-foreground">
                        Due: {new Date(fee.due_date).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <p className="text-sm font-medium">${fee.amount.toFixed(2)}</p>
                      <Badge
                        variant={
                          fee.status === "Paid" ? "default" : fee.status === "Pending" ? "outline" : "destructive"
                        }
                      >
                        {fee.status}
                      </Badge>
                    </div>
                  </div>
                ))
              )}
              <div className="pt-2">
                <Button asChild variant="outline" size="sm">
                  <Link href="/fees">View All Fees</Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Recent Attendance</CardTitle>
            <CardDescription>Your recent attendance records</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {data.attendance.length === 0 ? (
                <p>No attendance records found.</p>
              ) : (
                data.attendance.map((record: any) => (
                  <div key={record.id} className="flex items-center justify-between space-x-4">
                    <div>
                      <p className="text-sm font-medium leading-none">{new Date(record.date).toLocaleDateString()}</p>
                    </div>
                    <div>
                      <Badge
                        variant={
                          record.status === "Present" ? "default" : record.status === "Late" ? "outline" : "destructive"
                        }
                      >
                        {record.status}
                      </Badge>
                    </div>
                  </div>
                ))
              )}
              <div className="pt-2">
                <Button asChild variant="outline" size="sm">
                  <Link href="/attendance">View All Attendance</Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>My Helpdesk Tickets</CardTitle>
            <CardDescription>Your recent support tickets</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {data.tickets.length === 0 ? (
                <p>No helpdesk tickets found.</p>
              ) : (
                data.tickets.map((ticket: any) => (
                  <div key={ticket.id} className="flex items-center justify-between space-x-4">
                    <div>
                      <p className="text-sm font-medium leading-none">{ticket.subject}</p>
                      <p className="text-sm text-muted-foreground">
                        Created: {new Date(ticket.created_at).toLocaleDateString()}
                      </p>
                    </div>
                    <div>
                      <Badge
                        variant={
                          ticket.status === "Open"
                            ? "default"
                            : ticket.status === "In Progress"
                              ? "outline"
                              : "secondary"
                        }
                      >
                        {ticket.status}
                      </Badge>
                    </div>
                  </div>
                ))
              )}
              <div className="pt-2">
                <Button asChild variant="outline" size="sm">
                  <Link href="/helpdesk">View All Tickets</Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
