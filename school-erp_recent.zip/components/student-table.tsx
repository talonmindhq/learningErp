"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Edit, Eye, MoreHorizontal, Trash } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { getStudents, deleteStudent } from "@/app/actions/student-actions"
import { toast } from "@/components/ui/use-toast"
import { PermissionGate } from "@/components/permission-gate"

export function StudentTable() {
  const [students, setStudents] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [userRole, setUserRole] = useState<string | null>(null)

  useEffect(() => {
    async function fetchStudents() {
      try {
        const result = await getStudents()
        if (result.success) {
          setStudents(result.data)
        } else {
          toast({
            title: "Error",
            description: result.message || "Failed to fetch students",
            variant: "destructive",
          })
        }
      } catch (error) {
        console.error("Error fetching students:", error)
        toast({
          title: "Error",
          description: "An error occurred while fetching students",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    async function fetchUserRole() {
      try {
        const response = await fetch("/api/auth/role")
        const data = await response.json()
        setUserRole(data.role)
      } catch (error) {
        console.error("Error fetching user role:", error)
      }
    }

    fetchStudents()
    fetchUserRole()
  }, [])

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure you want to delete this student?")) {
      try {
        const result = await deleteStudent(id)
        if (result.success) {
          toast({
            title: "Success",
            description: "Student deleted successfully",
          })
          // Update the students list
          setStudents(students.filter((student: any) => student.id !== id))
        } else {
          toast({
            title: "Error",
            description: result.message || "Failed to delete student",
            variant: "destructive",
          })
        }
      } catch (error) {
        console.error("Error deleting student:", error)
        toast({
          title: "Error",
          description: "An error occurred while deleting the student",
          variant: "destructive",
        })
      }
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center p-4">
        <p>Loading students...</p>
      </div>
    )
  }

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Name</TableHead>
          <TableHead>Email</TableHead>
          <TableHead>Grade</TableHead>
          <TableHead>Admission Date</TableHead>
          <TableHead>Status</TableHead>
          <TableHead className="text-right">Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {students.length === 0 ? (
          <TableRow>
            <TableCell colSpan={6} className="text-center">
              No students found
            </TableCell>
          </TableRow>
        ) : (
          students.map((student: any) => (
            <TableRow key={student.id}>
              <TableCell className="font-medium">{`${student.first_name} ${student.last_name}`}</TableCell>
              <TableCell>{student.email}</TableCell>
              <TableCell>{student.grade}</TableCell>
              <TableCell>{new Date(student.admission_date).toLocaleDateString()}</TableCell>
              <TableCell>
                <Badge variant={student.status === "Active" ? "default" : "secondary"}>{student.status}</Badge>
              </TableCell>
              <TableCell className="text-right">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <MoreHorizontal className="h-4 w-4" />
                      <span className="sr-only">Actions</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuLabel>Actions</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <Link href={`/students/${student.id}`}>
                        <Eye className="mr-2 h-4 w-4" />
                        View
                      </Link>
                    </DropdownMenuItem>
                    <PermissionGate permission="manage_students">
                      <DropdownMenuItem asChild>
                        <Link href={`/students/${student.id}/edit`}>
                          <Edit className="mr-2 h-4 w-4" />
                          Edit
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => handleDelete(student.id)} className="text-destructive">
                        <Trash className="mr-2 h-4 w-4" />
                        Delete
                      </DropdownMenuItem>
                    </PermissionGate>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))
        )}
      </TableBody>
    </Table>
  )
}
