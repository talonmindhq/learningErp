import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { executeQuery } from "@/lib/db"

interface TeacherDashboardProps {
  userId: number
}

async function getTeacherData(userId: number) {
  try {
    // Get teacher profile
    const teachers = await executeQuery("SELECT * FROM teachers WHERE id = $1", [userId])

    if (teachers.length === 0) {
      return null
    }

    // Get students (in a real app, we would filter by teacher's classes)
    const students = await executeQuery(
      `
      SELECT * FROM students
      WHERE status = 'Active'
      ORDER BY grade, first_name, last_name
      LIMIT 5
    `,
    )

    // Get recent attendance records (in a real app, we would filter by teacher's classes)
    const attendance = await executeQuery(
      `
      SELECT a.*, s.first_name || ' ' || s.last_name as student_name, s.grade
      FROM attendance a
      JOIN students s ON a.student_id = s.id
      WHERE a.recorded_by = $1
      ORDER BY a.date DESC, s.grade, s.first_name, s.last_name
      LIMIT 5
    `,
      [userId],
    )

    // Get teacher helpdesk tickets
    const tickets = await executeQuery(
      `
      SELECT * FROM helpdesk
      WHERE user_id = $1 AND user_role = 'Teacher'
      ORDER BY created_at DESC
      LIMIT 5
    `,
      [userId],
    )

    return {
      profile: teachers[0],
      students,
      attendance,
      tickets,
    }
  } catch (error) {
    console.error("Error fetching teacher data:", error)
    return null
  }
}

export async function TeacherDashboard({ userId }: TeacherDashboardProps) {
  const data = await getTeacherData(userId)

  if (!data) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Teacher Dashboard</h1>
        <p>Error loading dashboard data. Please contact an administrator.</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Teacher Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>My Profile</CardTitle>
            <CardDescription>Your personal information</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Name</p>
                <p className="font-medium">{`${data.profile.first_name} ${data.profile.last_name}`}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Subject</p>
                <p>{data.profile.subject}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Status</p>
                <p>{data.profile.status}</p>
              </div>
              <div className="pt-2">
                <Button asChild variant="outline" size="sm">
                  <Link href="/profile">View Full Profile</Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Students</CardTitle>
            <CardDescription>Students in your classes</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {data.students.length === 0 ? (
                <p>No students found.</p>
              ) : (
                data.students.map((student: any) => (
                  <div key={student.id} className="flex items-center justify-between space-x-4">
                    <div>
                      <p className="text-sm font-medium leading-none">{`${student.first_name} ${student.last_name}`}</p>
                      <p className="text-sm text-muted-foreground">{student.email}</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant={student.status === "Active" ? "default" : "secondary"}>{student.grade}</Badge>
                      <Button asChild variant="ghost" size="sm">
                        <Link href={`/students/${student.id}`}>View</Link>
                      </Button>
                    </div>
                  </div>
                ))
              )}
              <div className="pt-2">
                <Button asChild variant="outline" size="sm">
                  <Link href="/students">View All Students</Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Recent Attendance Records</CardTitle>
            <CardDescription>Attendance records you've marked</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {data.attendance.length === 0 ? (
                <p>No attendance records found.</p>
              ) : (
                data.attendance.map((record: any) => (
                  <div key={record.id} className="flex items-center justify-between space-x-4">
                    <div>
                      <p className="text-sm font-medium leading-none">{record.student_name}</p>
                      <p className="text-sm text-muted-foreground">
                        {record.grade} - {new Date(record.date).toLocaleDateString()}
                      </p>
                    </div>
                    <div>
                      <Badge
                        variant={
                          record.status === "Present" ? "default" : record.status === "Late" ? "outline" : "destructive"
                        }
                      >
                        {record.status}
                      </Badge>
                    </div>
                  </div>
                ))
              )}
              <div className="pt-2">
                <Button asChild variant="outline" size="sm">
                  <Link href="/attendance">Mark Attendance</Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>My Helpdesk Tickets</CardTitle>
            <CardDescription>Your recent support tickets</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {data.tickets.length === 0 ? (
                <p>No helpdesk tickets found.</p>
              ) : (
                data.tickets.map((ticket: any) => (
                  <div key={ticket.id} className="flex items-center justify-between space-x-4">
                    <div>
                      <p className="text-sm font-medium leading-none">{ticket.subject}</p>
                      <p className="text-sm text-muted-foreground">
                        Created: {new Date(ticket.created_at).toLocaleDateString()}
                      </p>
                    </div>
                    <div>
                      <Badge
                        variant={
                          ticket.status === "Open"
                            ? "default"
                            : ticket.status === "In Progress"
                              ? "outline"
                              : "secondary"
                        }
                      >
                        {ticket.status}
                      </Badge>
                    </div>
                  </div>
                ))
              )}
              <div className="pt-2">
                <Button asChild variant="outline" size="sm">
                  <Link href="/helpdesk">View All Tickets</Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
