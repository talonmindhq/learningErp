import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface MobileGradeCardProps {
  student: {
    name: string
    grade: string
    overallAverage?: number
    overallLetterGrade?: string
    subjects?: Array<{
      id: number
      name: string
      weightedGrade: number
      letterGrade: string
    }>
  }
  showSubjectDetails: boolean
}

export function MobileGradeCard({ student, showSubjectDetails }: MobileGradeCardProps) {
  return (
    <Card className="mb-4 md:hidden">
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-2">
          <div>
            <h3 className="font-medium">{student.name}</h3>
            <p className="text-sm text-muted-foreground">{student.grade} Grade</p>
          </div>
          {showSubjectDetails ? (
            <Badge>{student.subjects?.[0]?.letterGrade || "N/A"}</Badge>
          ) : (
            <Badge>{student.overallLetterGrade || "N/A"}</Badge>
          )}
        </div>

        {showSubjectDetails ? (
          <div className="mt-2">
            <p className="text-sm">
              <span className="text-muted-foreground">Score:</span> {student.subjects?.[0]?.weightedGrade.toFixed(2)}%
            </p>
          </div>
        ) : (
          <>
            <p className="text-sm">
              <span className="text-muted-foreground">Overall Average:</span> {student.overallAverage?.toFixed(2)}%
            </p>

            {student.subjects && student.subjects.length > 0 && (
              <div className="mt-2">
                <p className="text-sm text-muted-foreground mb-1">Subjects:</p>
                <div className="flex flex-wrap gap-1">
                  {student.subjects.map((subject) => (
                    <div
                      key={subject.id}
                      className="rounded-md bg-muted px-1.5 py-0.5 text-xs"
                      title={`${subject.name}: ${subject.weightedGrade.toFixed(2)}% (${subject.letterGrade})`}
                    >
                      {subject.name}: {subject.letterGrade}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  )
}
