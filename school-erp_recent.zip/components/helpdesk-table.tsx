"use client"

import { useState } from "react"
import Link from "next/link"
import { Edit, Eye, MoreHorizontal, Trash } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export function HelpdeskTable() {
  const [tickets] = useState([
    {
      id: 1,
      subject: "Login Issue",
      user: "Olivia Martin",
      role: "Student",
      status: "Open",
      created: "2023-05-01",
    },
    {
      id: 2,
      subject: "Fee Payment Problem",
      user: "Jackson Lee",
      role: "Parent",
      status: "In Progress",
      created: "2023-05-02",
    },
    {
      id: 3,
      subject: "Attendance Correction",
      user: "Isabella Nguyen",
      role: "Student",
      status: "Closed",
      created: "2023-05-03",
    },
    {
      id: 4,
      subject: "Transport Route Change",
      user: "William Kim",
      role: "Student",
      status: "Open",
      created: "2023-05-04",
    },
    {
      id: 5,
      subject: "Grade Report Issue",
      user: "Sofia Davis",
      role: "Teacher",
      status: "In Progress",
      created: "2023-05-05",
    },
    {
      id: 6,
      subject: "Password Reset",
      user: "Ethan Johnson",
      role: "Student",
      status: "Closed",
      created: "2023-05-06",
    },
    {
      id: 7,
      subject: "Library Book Return",
      user: "Ava Wilson",
      role: "Student",
      status: "Open",
      created: "2023-05-07",
    },
    {
      id: 8,
      subject: "Exam Schedule Conflict",
      user: "Noah Brown",
      role: "Teacher",
      status: "In Progress",
      created: "2023-05-08",
    },
    {
      id: 9,
      subject: "School ID Card Lost",
      user: "Emma Taylor",
      role: "Student",
      status: "Open",
      created: "2023-05-09",
    },
    {
      id: 10,
      subject: "Classroom Equipment Issue",
      user: "Liam Anderson",
      role: "Teacher",
      status: "Closed",
      created: "2023-05-10",
    },
  ])

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Subject</TableHead>
          <TableHead>User</TableHead>
          <TableHead>Role</TableHead>
          <TableHead>Status</TableHead>
          <TableHead>Created</TableHead>
          <TableHead className="text-right">Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {tickets.map((ticket) => (
          <TableRow key={ticket.id}>
            <TableCell className="font-medium">{ticket.subject}</TableCell>
            <TableCell>{ticket.user}</TableCell>
            <TableCell>{ticket.role}</TableCell>
            <TableCell>
              <Badge
                variant={
                  ticket.status === "Open" ? "default" : ticket.status === "In Progress" ? "outline" : "secondary"
                }
              >
                {ticket.status}
              </Badge>
            </TableCell>
            <TableCell>{ticket.created}</TableCell>
            <TableCell className="text-right">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <MoreHorizontal className="h-4 w-4" />
                    <span className="sr-only">Actions</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>Actions</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href={`/helpdesk/${ticket.id}`}>
                      <Eye className="mr-2 h-4 w-4" />
                      View
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href={`/helpdesk/${ticket.id}/edit`}>
                      <Edit className="mr-2 h-4 w-4" />
                      Edit
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="text-destructive">
                    <Trash className="mr-2 h-4 w-4" />
                    Delete
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )
}
