import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { jwtVerify } from "jose"

// Secret key for JWT verification
const JWT_SECRET = new TextEncoder().encode(process.env.JWT_SECRET || "default_secret_key_change_in_production")

// Paths that don't require authentication
const publicPaths = ["/auth/login", "/auth/forgot-password"]

// Role-based path restrictions
const roleBasedPaths = {
  Admin: ["/", "/students", "/teachers", "/fees", "/transportation", "/attendance", "/reports", "/helpdesk"],
  Teacher: ["/", "/students", "/attendance", "/helpdesk"],
  Student: ["/", "/profile", "/fees", "/attendance", "/helpdesk"],
}

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl

  // Check if the path is public
  if (publicPaths.some((path) => pathname.startsWith(path))) {
    return NextResponse.next()
  }

  // Check for auth token
  const token = request.cookies.get("auth_token")?.value

  if (!token) {
    // Redirect to login if no token is found
    return NextResponse.redirect(new URL("/auth/login", request.url))
  }

  try {
    // Verify the token
    const { payload } = await jwtVerify(token, JWT_SECRET)
    const userRole = payload.role as string

    // Check if the user has access to the requested path
    const allowedPaths = roleBasedPaths[userRole as keyof typeof roleBasedPaths] || []

    // Check if the current path starts with any of the allowed paths
    const hasAccess = allowedPaths.some((path) => pathname.startsWith(path))

    if (!hasAccess) {
      // Redirect to unauthorized page if the user doesn't have access
      return NextResponse.redirect(new URL("/unauthorized", request.url))
    }

    return NextResponse.next()
  } catch (error) {
    // Token is invalid, redirect to login
    return NextResponse.redirect(new URL("/auth/login", request.url))
  }
}

// Configure the middleware to run on specific paths
export const config = {
  matcher: [
    /*
     * Match all request paths except:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public files (public assets)
     */
    "/((?!_next/static|_next/image|favicon.ico|public).*)",
  ],
}
