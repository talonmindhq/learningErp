// Import Jest DOM extensions for DOM testing
import "@testing-library/jest-dom"

// Mock the global fetch
global.fetch = jest.fn()

// Mock next/navigation
jest.mock("next/navigation", () => ({
  useRouter: () => ({
    push: jest.fn(),
    refresh: jest.fn(),
    back: jest.fn(),
    forward: jest.fn(),
  }),
  usePathname: () => "/current-path",
  useSearchParams: () => new URLSearchParams(),
}))

// Mock environment variables
process.env = {
  ...process.env,
  DATABASE_URL: "mock-db-url",
  JWT_SECRET: "test-jwt-secret",
}
