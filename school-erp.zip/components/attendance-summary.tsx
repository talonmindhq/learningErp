import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export function AttendanceSummary() {
  const attendance = [
    {
      id: 1,
      student: "Olivia Martin",
      grade: "10th",
      date: "2023-05-01",
      status: "Present",
    },
    {
      id: 2,
      student: "Jackson Lee",
      grade: "9th",
      date: "2023-05-01",
      status: "Absent",
    },
    {
      id: 3,
      student: "Isabella Nguyen",
      grade: "11th",
      date: "2023-05-01",
      status: "Present",
    },
    {
      id: 4,
      student: "William Kim",
      grade: "12th",
      date: "2023-05-01",
      status: "Late",
    },
    {
      id: 5,
      student: "Sofia Davis",
      grade: "10th",
      date: "2023-05-01",
      status: "Present",
    },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle>Today's Attendance</CardTitle>
        <CardDescription>Attendance records for today.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {attendance.map((record) => (
            <div key={record.id} className="flex items-center justify-between space-x-4">
              <div>
                <p className="text-sm font-medium leading-none">{record.student}</p>
                <p className="text-sm text-muted-foreground">{record.grade}</p>
              </div>
              <div>
                <Badge
                  variant={
                    record.status === "Present" ? "default" : record.status === "Late" ? "outline" : "destructive"
                  }
                >
                  {record.status}
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
