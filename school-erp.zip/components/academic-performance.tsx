"use client"

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

export function AcademicPerformance() {
  const data = [
    {
      subject: "Mathematics",
      "Class Average": 78,
      "School Average": 72,
    },
    {
      subject: "Science",
      "Class Average": 82,
      "School Average": 76,
    },
    {
      subject: "English",
      "Class Average": 85,
      "School Average": 80,
    },
    {
      subject: "Social Studies",
      "Class Average": 79,
      "School Average": 74,
    },
    {
      subject: "Languages",
      "Class Average": 88,
      "School Average": 82,
    },
  ]

  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={data}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="subject" />
          <YAxis domain={[0, 100]} />
          <Tooltip />
          <Legend />
          <Bar dataKey="Class Average" fill="#00509d" />
          <Bar dataKey="School Average" fill="#00a299" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}
