"use client"

import { useState } from "react"
import Link from "next/link"
import { Download, Edit, Eye, MoreHorizontal, Trash } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export function FeesTable() {
  const [fees] = useState([
    {
      id: 1,
      student: "Olivia Martin",
      feeType: "Tuition Fee",
      amount: 1200,
      dueDate: "2023-05-15",
      status: "Paid",
    },
    {
      id: 2,
      student: "Jackson Lee",
      feeType: "Transport Fee",
      amount: 300,
      dueDate: "2023-05-15",
      status: "Pending",
    },
    {
      id: 3,
      student: "Isabella Nguyen",
      feeType: "Library Fee",
      amount: 150,
      dueDate: "2023-05-20",
      status: "Paid",
    },
    {
      id: 4,
      student: "William Kim",
      feeType: "Tuition Fee",
      amount: 1200,
      dueDate: "2023-05-15",
      status: "Overdue",
    },
    {
      id: 5,
      student: "Sofia Davis",
      feeType: "Lab Fee",
      amount: 250,
      dueDate: "2023-05-25",
      status: "Pending",
    },
    {
      id: 6,
      student: "Ethan Johnson",
      feeType: "Tuition Fee",
      amount: 1200,
      dueDate: "2023-05-15",
      status: "Paid",
    },
    {
      id: 7,
      student: "Ava Wilson",
      feeType: "Transport Fee",
      amount: 300,
      dueDate: "2023-05-15",
      status: "Pending",
    },
    {
      id: 8,
      student: "Noah Brown",
      feeType: "Library Fee",
      amount: 150,
      dueDate: "2023-05-20",
      status: "Paid",
    },
    {
      id: 9,
      student: "Emma Taylor",
      feeType: "Tuition Fee",
      amount: 1200,
      dueDate: "2023-05-15",
      status: "Overdue",
    },
    {
      id: 10,
      student: "Liam Anderson",
      feeType: "Lab Fee",
      amount: 250,
      dueDate: "2023-05-25",
      status: "Pending",
    },
  ])

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Student</TableHead>
          <TableHead>Fee Type</TableHead>
          <TableHead>Amount</TableHead>
          <TableHead>Due Date</TableHead>
          <TableHead>Status</TableHead>
          <TableHead className="text-right">Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {fees.map((fee) => (
          <TableRow key={fee.id}>
            <TableCell className="font-medium">{fee.student}</TableCell>
            <TableCell>{fee.feeType}</TableCell>
            <TableCell>${fee.amount}</TableCell>
            <TableCell>{fee.dueDate}</TableCell>
            <TableCell>
              <Badge variant={fee.status === "Paid" ? "default" : fee.status === "Pending" ? "outline" : "destructive"}>
                {fee.status}
              </Badge>
            </TableCell>
            <TableCell className="text-right">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <MoreHorizontal className="h-4 w-4" />
                    <span className="sr-only">Actions</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>Actions</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href={`/fees/${fee.id}`}>
                      <Eye className="mr-2 h-4 w-4" />
                      View
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href={`/fees/${fee.id}/edit`}>
                      <Edit className="mr-2 h-4 w-4" />
                      Edit
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Download className="mr-2 h-4 w-4" />
                    Download Invoice
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="text-destructive">
                    <Trash className="mr-2 h-4 w-4" />
                    Delete
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )
}
