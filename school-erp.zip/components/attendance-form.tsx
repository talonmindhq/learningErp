"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"

interface AttendanceFormProps {
  grade: string
  date?: Date
}

export function AttendanceForm({ grade, date }: AttendanceFormProps) {
  const [students] = useState([
    { id: 1, name: "Olivia Martin", status: "present" },
    { id: 2, name: "Jackson Lee", status: "absent" },
    { id: 3, name: "Isabella Nguyen", status: "present" },
    { id: 4, name: "William Kim", status: "late" },
    { id: 5, name: "Sofia Davis", status: "present" },
    { id: 6, name: "Ethan Johnson", status: "present" },
    { id: 7, name: "Ava Wilson", status: "absent" },
    { id: 8, name: "Noah Brown", status: "present" },
    { id: 9, name: "Emma Taylor", status: "late" },
    { id: 10, name: "Liam Anderson", status: "present" },
  ])

  const [attendance, setAttendance] = useState<Record<number, string>>(
    students.reduce(
      (acc, student) => {
        acc[student.id] = student.status
        return acc
      },
      {} as Record<number, string>,
    ),
  )

  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleAttendanceChange = (studentId: number, status: string) => {
    setAttendance((prev) => ({
      ...prev,
      [studentId]: status,
    }))
  }

  const handleSubmit = () => {
    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      console.log({
        grade,
        date: date?.toISOString(),
        attendance,
      })

      toast({
        title: "Attendance Saved",
        description: `Attendance for ${grade} on ${date?.toLocaleDateString()} has been saved.`,
      })

      setIsSubmitting(false)
    }, 1000)
  }

  return (
    <div className="space-y-4">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Student Name</TableHead>
            <TableHead>Status</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {students.map((student) => (
            <TableRow key={student.id}>
              <TableCell className="font-medium">{student.name}</TableCell>
              <TableCell>
                <RadioGroup
                  value={attendance[student.id]}
                  onValueChange={(value) => handleAttendanceChange(student.id, value)}
                  className="flex space-x-4"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="present" id={`present-${student.id}`} />
                    <label htmlFor={`present-${student.id}`} className="text-sm font-medium">
                      Present
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="absent" id={`absent-${student.id}`} />
                    <label htmlFor={`absent-${student.id}`} className="text-sm font-medium">
                      Absent
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="late" id={`late-${student.id}`} />
                    <label htmlFor={`late-${student.id}`} className="text-sm font-medium">
                      Late
                    </label>
                  </div>
                </RadioGroup>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <div className="flex justify-end">
        <Button onClick={handleSubmit} disabled={isSubmitting}>
          {isSubmitting ? "Saving..." : "Save Attendance"}
        </Button>
      </div>
    </div>
  )
}
