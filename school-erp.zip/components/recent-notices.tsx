"use client"

import { Bell, FileText, Info } from "lucide-react"
import { Button } from "@/components/ui/button"

export function RecentNotices() {
  const notices = [
    {
      id: 1,
      title: "Fee Payment Reminder",
      date: "May 20, 2023",
      type: "important",
      excerpt: "Last date for fee payment is May 31, 2023. Late fee will be applicable after the due date.",
    },
    {
      id: 2,
      title: "Summer Vacation Notice",
      date: "May 18, 2023",
      type: "general",
      excerpt: "School will remain closed for summer vacation from June 1 to June 30, 2023.",
    },
    {
      id: 3,
      title: "Annual Sports Day",
      date: "May 15, 2023",
      type: "event",
      excerpt: "Annual Sports Day will be held on May 25, 2023. All students must participate.",
    },
  ]

  return (
    <div className="space-y-4">
      {notices.map((notice) => (
        <div key={notice.id} className="border-b pb-3 last:border-0">
          <div className="flex items-start gap-3">
            <div
              className={`rounded-full p-1.5 ${
                notice.type === "important"
                  ? "bg-accent1-100 text-accent1-500"
                  : notice.type === "event"
                    ? "bg-accent2-100 text-accent2-500"
                    : "bg-theme-100 text-theme-500"
              }`}
            >
              {notice.type === "important" ? (
                <Info className="h-3.5 w-3.5" />
              ) : notice.type === "event" ? (
                <Bell className="h-3.5 w-3.5" />
              ) : (
                <FileText className="h-3.5 w-3.5" />
              )}
            </div>
            <div className="space-y-1">
              <h4 className="text-sm font-medium">{notice.title}</h4>
              <p className="text-xs text-muted-foreground line-clamp-2">{notice.excerpt}</p>
              <div className="flex items-center">
                <span className="text-xs text-muted-foreground">{notice.date}</span>
              </div>
            </div>
          </div>
        </div>
      ))}
      <Button variant="ghost" className="w-full text-xs h-8 text-theme-500 hover:bg-theme-50">
        View All Notices
      </Button>
    </div>
  )
}
