import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export function RecentStudents() {
  const students = [
    {
      id: 1,
      name: "Olivia Martin",
      email: "olivia.martin@email.com",
      grade: "10th",
      status: "Active",
      image: "/abstract-geometric-shapes.png",
    },
    {
      id: 2,
      name: "Jackson Lee",
      email: "jackson.lee@email.com",
      grade: "9th",
      status: "Active",
      image: "/number-two-graphic.png",
    },
    {
      id: 3,
      name: "Isabella Nguyen",
      email: "isabella.nguyen@email.com",
      grade: "11th",
      status: "Active",
      image: "/abstract-geometric-shapes.png",
    },
    {
      id: 4,
      name: "William Kim",
      email: "william.kim@email.com",
      grade: "12th",
      status: "Inactive",
      image: "/abstract-geometric-shapes.png",
    },
    {
      id: 5,
      name: "Sofia Davis",
      email: "sofia.davis@email.com",
      grade: "10th",
      status: "Active",
      image: "/abstract-geometric-composition-5.png",
    },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Students</CardTitle>
        <CardDescription>Recently enrolled students in the system.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {students.map((student) => (
            <div key={student.id} className="flex items-center justify-between space-x-4">
              <div className="flex items-center space-x-4">
                <Avatar>
                  <AvatarImage src={student.image || "/placeholder.svg"} alt={student.name} />
                  <AvatarFallback>
                    {student.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm font-medium leading-none">{student.name}</p>
                  <p className="text-sm text-muted-foreground">{student.email}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Badge variant={student.status === "Active" ? "default" : "secondary"}>{student.grade}</Badge>
                <Button variant="ghost" size="sm">
                  View
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
