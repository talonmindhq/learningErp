"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import {
  GraduationCap,
  Users,
  BookOpen,
  Calendar,
  CreditCard,
  Settings,
  Bell,
  Menu,
  LogOut,
  UserCircle,
  MessageSquare,
  FileText,
  BarChart3,
  BookMarked,
  Briefcase,
  LayoutDashboard,
  ClipboardList,
  Award,
  PieChart,
  UserPlus,
  School,
  Landmark,
  Calculator,
  FileBarChart,
  ChevronRight,
  Home,
} from "lucide-react"
import {
  Package,
  Box,
  FolderTree,
  Truck,
  ShoppingCart,
  Bus,
  Car,
  Map,
  MapPin,
  Repeat,
  DollarSign,
  Lightbulb,
  Sparkles,
  Hammer,
  ClipboardCheck,
  Book,
} from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

interface NavItemProps {
  href: string
  icon: React.ReactNode
  title: string
  isActive?: boolean
  badge?: number | string
}

function NavItem({ href, icon, title, isActive, badge }: NavItemProps) {
  return (
    <Link
      href={href}
      className={cn(
        "flex items-center justify-between gap-3 rounded-md px-3 py-2 text-sm transition-all relative overflow-hidden group",
        isActive ? "bg-violet-600 text-white" : "text-gray-100 hover:bg-violet-700/50",
      )}
    >
      <div className="flex items-center gap-3 z-10">
        {icon}
        {title}
      </div>
      {badge && (
        <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-white/20 px-1.5 text-xs font-medium text-white z-10">
          {badge}
        </span>
      )}
    </Link>
  )
}

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false)
  const [user, setUser] = useState<{ username: string; role: string } | null>(null)
  const [openSections, setOpenSections] = useState<string[]>(["dashboard", "student-manager"])

  useEffect(() => {
    // Get user from localStorage
    const storedUser = localStorage.getItem("user")
    if (storedUser) {
      setUser(JSON.parse(storedUser))
    }
  }, [])

  const toggleSection = (section: string) => {
    setOpenSections((prev) => (prev.includes(section) ? prev.filter((s) => s !== section) : [...prev, section]))
  }

  const menuItems = [
    {
      title: "Dashboard",
      value: "dashboard",
      icon: <Home className="h-4 w-4" />,
      items: [{ title: "Overview", href: "/dashboard", icon: <LayoutDashboard className="h-4 w-4" />, isActive: true }],
    },
    {
      title: "Enquiry & Admission",
      value: "enquiry-admission",
      icon: <UserPlus className="h-4 w-4" />,
      items: [
        { title: "Enquiries", href: "/dashboard/enquiries", icon: <MessageSquare className="h-4 w-4" /> },
        { title: "Applications", href: "/dashboard/applications", icon: <FileText className="h-4 w-4" /> },
        { title: "Interviews", href: "/dashboard/interviews", icon: <Users className="h-4 w-4" /> },
      ],
    },
    {
      title: "Admission",
      value: "admission",
      icon: <School className="h-4 w-4" />,
      items: [
        { title: "New Admission", href: "/dashboard/new-admission", icon: <UserPlus className="h-4 w-4" /> },
        { title: "Admission List", href: "/dashboard/admission-list", icon: <ClipboardList className="h-4 w-4" /> },
      ],
    },
    {
      title: "Student Manager",
      value: "student-manager",
      icon: <Users className="h-4 w-4" />,
      items: [
        { title: "Students", href: "/dashboard/students", icon: <Users className="h-4 w-4" />, badge: "1,248" },
        { title: "Student Profile", href: "/dashboard/student-profile", icon: <UserCircle className="h-4 w-4" /> },
        { title: "ID Cards", href: "/dashboard/id-cards", icon: <FileText className="h-4 w-4" /> },
      ],
    },
    {
      title: "Employee Module",
      value: "employee-module",
      icon: <Briefcase className="h-4 w-4" />,
      items: [
        { title: "Staff", href: "/dashboard/staff", icon: <Briefcase className="h-4 w-4" /> },
        { title: "Attendance", href: "/dashboard/staff-attendance", icon: <BarChart3 className="h-4 w-4" /> },
        { title: "Payroll", href: "/dashboard/payroll", icon: <CreditCard className="h-4 w-4" /> },
      ],
    },
    {
      title: "Stock & Inventory",
      value: "inventory",
      icon: <Package className="h-4 w-4" />,
      items: [
        { title: "Dashboard", href: "/dashboard/inventory", icon: <LayoutDashboard className="h-4 w-4" /> },
        { title: "Items", href: "/dashboard/inventory/items", icon: <Box className="h-4 w-4" /> },
        { title: "Categories", href: "/dashboard/inventory/categories", icon: <FolderTree className="h-4 w-4" /> },
        { title: "Suppliers", href: "/dashboard/inventory/suppliers", icon: <Truck className="h-4 w-4" /> },
        {
          title: "Purchase Orders",
          href: "/dashboard/inventory/purchase-orders",
          icon: <ShoppingCart className="h-4 w-4" />,
        },
      ],
    },
    {
      title: "Transport Module",
      value: "transport",
      icon: <Bus className="h-4 w-4" />,
      items: [
        { title: "Dashboard", href: "/dashboard/transport", icon: <LayoutDashboard className="h-4 w-4" /> },
        { title: "Vehicles", href: "/dashboard/transport/vehicles", icon: <Car className="h-4 w-4" /> },
        { title: "Routes", href: "/dashboard/transport/routes", icon: <Map className="h-4 w-4" /> },
        { title: "Drivers", href: "/dashboard/transport/drivers", icon: <UserCircle className="h-4 w-4" /> },
        { title: "Bus Tracking", href: "/dashboard/transport/tracking", icon: <MapPin className="h-4 w-4" /> },
      ],
    },
    {
      title: "Library Management",
      value: "library",
      icon: <BookOpen className="h-4 w-4" />,
      items: [
        { title: "Dashboard", href: "/dashboard/library", icon: <LayoutDashboard className="h-4 w-4" /> },
        { title: "Books", href: "/dashboard/library/books", icon: <Book className="h-4 w-4" /> },
        { title: "Members", href: "/dashboard/library/members", icon: <Users className="h-4 w-4" /> },
        { title: "Issue/Return", href: "/dashboard/library/issue-return", icon: <Repeat className="h-4 w-4" /> },
        { title: "Fines", href: "/dashboard/library/fines", icon: <DollarSign className="h-4 w-4" /> },
      ],
    },
    {
      title: "NEP Module",
      value: "nep",
      icon: <Lightbulb className="h-4 w-4" />,
      items: [
        { title: "Dashboard", href: "/dashboard/nep", icon: <LayoutDashboard className="h-4 w-4" /> },
        { title: "Curriculum", href: "/dashboard/nep/curriculum", icon: <FileText className="h-4 w-4" /> },
        { title: "Assessments", href: "/dashboard/nep/assessments", icon: <ClipboardCheck className="h-4 w-4" /> },
        { title: "Skill Development", href: "/dashboard/nep/skills", icon: <Sparkles className="h-4 w-4" /> },
        { title: "Vocational Training", href: "/dashboard/nep/vocational", icon: <Hammer className="h-4 w-4" /> },
      ],
    },
    {
      title: "General Accounting",
      value: "general-accounting",
      icon: <Landmark className="h-4 w-4" />,
      items: [
        { title: "Accounts", href: "/dashboard/accounts", icon: <Calculator className="h-4 w-4" /> },
        { title: "Expenses", href: "/dashboard/expenses", icon: <CreditCard className="h-4 w-4" /> },
        { title: "Income", href: "/dashboard/income", icon: <PieChart className="h-4 w-4" /> },
      ],
    },
    {
      title: "Academic Portfolio",
      value: "academic-portfolio",
      icon: <GraduationCap className="h-4 w-4" />,
      items: [
        { title: "Classes", href: "/dashboard/classes", icon: <BookOpen className="h-4 w-4" /> },
        { title: "Subjects", href: "/dashboard/subjects", icon: <BookMarked className="h-4 w-4" /> },
        { title: "Timetable", href: "/dashboard/timetable", icon: <Calendar className="h-4 w-4" /> },
        { title: "Attendance", href: "/dashboard/attendance", icon: <BarChart3 className="h-4 w-4" /> },
      ],
    },
    {
      title: "Examination",
      value: "examination",
      icon: <ClipboardList className="h-4 w-4" />,
      items: [
        { title: "Exams", href: "/dashboard/exams", icon: <ClipboardList className="h-4 w-4" /> },
        { title: "Results", href: "/dashboard/results", icon: <Award className="h-4 w-4" /> },
        { title: "Report Cards", href: "/dashboard/report-cards", icon: <FileText className="h-4 w-4" /> },
      ],
    },
    {
      title: "Fee Module Adv",
      value: "fee-module",
      icon: <CreditCard className="h-4 w-4" />,
      items: [
        { title: "Dashboard", href: "/dashboard/fees", icon: <LayoutDashboard className="h-4 w-4" /> },
        { title: "Fee Structure", href: "/dashboard/fees/structure", icon: <BookOpen className="h-4 w-4" /> },
        { title: "Fee Collection", href: "/dashboard/fees/collect", icon: <CreditCard className="h-4 w-4" /> },
        { title: "Defaulters", href: "/dashboard/fees/defaulters", icon: <FileBarChart className="h-4 w-4" /> },
        { title: "Advanced Settings", href: "/dashboard/fees/advanced", icon: <Settings className="h-4 w-4" /> },
      ],
    },
    {
      title: "Reports",
      value: "reports",
      icon: <FileBarChart className="h-4 w-4" />,
      items: [
        { title: "Academic", href: "/dashboard/reports/academic", icon: <FileText className="h-4 w-4" /> },
        { title: "Financial", href: "/dashboard/reports/financial", icon: <PieChart className="h-4 w-4" /> },
        { title: "Attendance", href: "/dashboard/reports/attendance", icon: <BarChart3 className="h-4 w-4" /> },
      ],
    },
  ]

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-30 flex h-14 items-center gap-4 border-b bg-white px-4 md:px-6">
        <Sheet open={isMobileNavOpen} onOpenChange={setIsMobileNavOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" className="md:hidden">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Toggle Menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-72 p-0 bg-gradient-to-b from-[#6d28d9] to-[#7c3aed]">
            <div className="grid gap-4 py-4">
              <div className="px-4 py-2 flex items-center gap-2 border-b border-white/10 pb-4">
                <GraduationCap className="h-6 w-6 text-white" />
                <h2 className="text-lg font-semibold text-white">DigiServices</h2>
              </div>
              <div className="px-2">
                {menuItems.map((section) => (
                  <Collapsible
                    key={section.value}
                    open={openSections.includes(section.value)}
                    onOpenChange={() => toggleSection(section.value)}
                    className="mb-1"
                  >
                    <CollapsibleTrigger className="flex w-full items-center justify-between px-3 py-2 text-sm text-white hover:bg-violet-700/50 rounded-md">
                      <div className="flex items-center gap-2">
                        <span className="text-white">{section.icon}</span>
                        <span>{section.title}</span>
                      </div>
                      <ChevronRight
                        className={`h-4 w-4 transition-transform ${openSections.includes(section.value) ? "rotate-90" : ""}`}
                      />
                    </CollapsibleTrigger>
                    <CollapsibleContent className="pl-4 pt-1">
                      <div className="grid gap-1">
                        {section.items.map((item) => (
                          <NavItem
                            key={item.href}
                            href={item.href}
                            icon={item.icon}
                            title={item.title}
                            isActive={item.isActive}
                            badge={item.badge}
                          />
                        ))}
                      </div>
                    </CollapsibleContent>
                  </Collapsible>
                ))}
              </div>
            </div>
          </SheetContent>
        </Sheet>

        <div className="flex items-center gap-2">
          <GraduationCap className="h-6 w-6 text-violet-600" />
          <h2 className="text-lg font-semibold hidden md:block">DigiServices</h2>
        </div>

        <div className="flex-1"></div>

        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" className="relative">
            <Bell className="h-5 w-5" />
            <span className="absolute top-1 right-1 h-2 w-2 rounded-full bg-theme-500"></span>
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                <Avatar className="h-8 w-8">
                  <AvatarImage src="/abstract-geometric-shapes.png" alt="User" />
                  <AvatarFallback>AD</AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56" align="end" forceMount>
              <DropdownMenuLabel className="font-normal">
                <div className="flex flex-col space-y-1">
                  <p className="text-sm font-medium leading-none">{user?.username || "Admin User"}</p>
                  <p className="text-xs leading-none text-muted-foreground">{user?.role || "admin"}@netkampus.com</p>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <UserCircle className="mr-2 h-4 w-4" />
                <span>Profile</span>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Settings className="mr-2 h-4 w-4" />
                <span>Settings</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={() => {
                  localStorage.removeItem("user")
                  window.location.href = "/"
                }}
              >
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </header>

      <div className="flex flex-1">
        <aside className="hidden w-64 bg-gradient-to-b from-[#6d28d9] to-[#7c3aed] md:block">
          <div className="flex h-full flex-col gap-2 p-4">
            {menuItems.map((section) => (
              <Collapsible
                key={section.value}
                open={openSections.includes(section.value)}
                onOpenChange={() => toggleSection(section.value)}
                className="mb-1"
              >
                <CollapsibleTrigger className="flex w-full items-center justify-between px-3 py-2 text-sm text-white hover:bg-violet-700/50 rounded-md">
                  <div className="flex items-center gap-2">
                    <span className="text-white">{section.icon}</span>
                    <span>{section.title}</span>
                  </div>
                  <ChevronRight
                    className={`h-4 w-4 transition-transform ${openSections.includes(section.value) ? "rotate-90" : ""}`}
                  />
                </CollapsibleTrigger>
                <CollapsibleContent className="pl-4 pt-1">
                  <div className="grid gap-1">
                    {section.items.map((item) => (
                      <NavItem
                        key={item.href}
                        href={item.href}
                        icon={item.icon}
                        title={item.title}
                        isActive={item.isActive}
                        badge={item.badge}
                      />
                    ))}
                  </div>
                </CollapsibleContent>
              </Collapsible>
            ))}
          </div>
        </aside>

        <main className="flex-1 bg-gray-50">{children}</main>
      </div>
    </div>
  )
}
