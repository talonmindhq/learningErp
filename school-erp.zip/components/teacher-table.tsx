"use client"

import { useState } from "react"
import Link from "next/link"
import { Edit, Eye, MoreHorizontal, Trash } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export function TeacherTable() {
  const [teachers] = useState([
    {
      id: 1,
      name: "John Smith",
      email: "john.smith@school.com",
      subject: "Mathematics",
      joinDate: "2020-01-15",
      status: "Active",
    },
    {
      id: 2,
      name: "Emily Johnson",
      email: "emily.johnson@school.com",
      subject: "English",
      joinDate: "2019-08-10",
      status: "Active",
    },
    {
      id: 3,
      name: "Michael Brown",
      email: "michael.brown@school.com",
      subject: "Science",
      joinDate: "2021-03-22",
      status: "Active",
    },
    {
      id: 4,
      name: "Sarah Davis",
      email: "sarah.davis@school.com",
      subject: "History",
      joinDate: "2018-11-05",
      status: "Active",
    },
    {
      id: 5,
      name: "Robert Wilson",
      email: "robert.wilson@school.com",
      subject: "Physical Education",
      joinDate: "2022-02-14",
      status: "Active",
    },
    {
      id: 6,
      name: "Jennifer Taylor",
      email: "jennifer.taylor@school.com",
      subject: "Art",
      joinDate: "2020-09-01",
      status: "On Leave",
    },
    {
      id: 7,
      name: "David Martinez",
      email: "david.martinez@school.com",
      subject: "Computer Science",
      joinDate: "2021-07-15",
      status: "Active",
    },
    {
      id: 8,
      name: "Lisa Anderson",
      email: "lisa.anderson@school.com",
      subject: "Music",
      joinDate: "2019-05-20",
      status: "Active",
    },
    {
      id: 9,
      name: "James Thomas",
      email: "james.thomas@school.com",
      subject: "Geography",
      joinDate: "2022-01-10",
      status: "Inactive",
    },
    {
      id: 10,
      name: "Patricia Moore",
      email: "patricia.moore@school.com",
      subject: "Chemistry",
      joinDate: "2020-04-12",
      status: "Active",
    },
  ])

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Name</TableHead>
          <TableHead>Email</TableHead>
          <TableHead>Subject</TableHead>
          <TableHead>Join Date</TableHead>
          <TableHead>Status</TableHead>
          <TableHead className="text-right">Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {teachers.map((teacher) => (
          <TableRow key={teacher.id}>
            <TableCell className="font-medium">{teacher.name}</TableCell>
            <TableCell>{teacher.email}</TableCell>
            <TableCell>{teacher.subject}</TableCell>
            <TableCell>{teacher.joinDate}</TableCell>
            <TableCell>
              <Badge
                variant={
                  teacher.status === "Active" ? "default" : teacher.status === "On Leave" ? "outline" : "secondary"
                }
              >
                {teacher.status}
              </Badge>
            </TableCell>
            <TableCell className="text-right">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <MoreHorizontal className="h-4 w-4" />
                    <span className="sr-only">Actions</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>Actions</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href={`/teachers/${teacher.id}`}>
                      <Eye className="mr-2 h-4 w-4" />
                      View
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href={`/teachers/${teacher.id}/edit`}>
                      <Edit className="mr-2 h-4 w-4" />
                      Edit
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="text-destructive">
                    <Trash className="mr-2 h-4 w-4" />
                    Delete
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )
}
