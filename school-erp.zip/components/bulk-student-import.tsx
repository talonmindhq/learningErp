"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { Download, Upload, AlertCircle, CheckCircle2 } from "lucide-react"
import { importStudentsFromExcel } from "@/app/actions/student-import-actions"
import { useToast } from "@/components/ui/use-toast"

export function BulkStudentImport() {
  const [file, setFile] = useState<File | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const [progress, setProgress] = useState(0)
  const [results, setResults] = useState<{
    success: boolean
    imported: number
    failed: number
    errors: string[]
  } | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0]
    if (selectedFile) {
      // Check if file is Excel
      if (!selectedFile.name.endsWith(".xlsx") && !selectedFile.name.endsWith(".xls")) {
        toast({
          title: "Invalid file format",
          description: "Please upload an Excel file (.xlsx or .xls)",
          variant: "destructive",
        })
        return
      }

      setFile(selectedFile)
      setResults(null)
    }
  }

  const handleUpload = async () => {
    if (!file) return

    setIsUploading(true)
    setProgress(10)

    try {
      // Create a FormData object to send the file
      const formData = new FormData()
      formData.append("file", file)

      // Simulate progress (in a real app, you might get this from the server)
      const progressInterval = setInterval(() => {
        setProgress((prev) => {
          const newProgress = prev + 10
          if (newProgress >= 90) {
            clearInterval(progressInterval)
            return 90
          }
          return newProgress
        })
      }, 500)

      // Call the server action to import students
      const result = await importStudentsFromExcel(formData)

      clearInterval(progressInterval)
      setProgress(100)

      if (result.success) {
        setResults({
          success: true,
          imported: result.imported,
          failed: result.failed,
          errors: result.errors || [],
        })

        toast({
          title: "Import completed",
          description: `Successfully imported ${result.imported} students.`,
        })
      } else {
        setResults({
          success: false,
          imported: 0,
          failed: 0,
          errors: [result.error || "Unknown error occurred"],
        })

        toast({
          title: "Import failed",
          description: result.error || "Failed to import students",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error importing students:", error)

      setResults({
        success: false,
        imported: 0,
        failed: 0,
        errors: [error instanceof Error ? error.message : "Unknown error occurred"],
      })

      toast({
        title: "Import failed",
        description: "An error occurred while importing students",
        variant: "destructive",
      })
    } finally {
      setIsUploading(false)
    }
  }

  const handleDownloadTemplate = () => {
    // In a real app, this would download a template file from the server
    // For now, we'll just provide a link to a static template
    window.open("/api/students/template", "_blank")
  }

  const resetForm = () => {
    setFile(null)
    setResults(null)
    setProgress(0)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4">
        <div className="flex flex-col gap-2">
          <h3 className="text-lg font-medium">Step 1: Download Template</h3>
          <p className="text-sm text-muted-foreground">Download the Excel template and fill it with student data.</p>
          <Button variant="outline" onClick={handleDownloadTemplate} className="w-fit">
            <Download className="mr-2 h-4 w-4" />
            Download Template
          </Button>
        </div>

        <div className="flex flex-col gap-2">
          <h3 className="text-lg font-medium">Step 2: Upload Filled Template</h3>
          <p className="text-sm text-muted-foreground">Upload the Excel file with student data.</p>

          <div className="grid w-full max-w-sm items-center gap-1.5">
            <input
              type="file"
              id="student-excel"
              className="hidden"
              accept=".xlsx,.xls"
              onChange={handleFileChange}
              disabled={isUploading}
              ref={fileInputRef}
            />
            <div className="flex gap-2">
              <Button variant="secondary" onClick={() => fileInputRef.current?.click()} disabled={isUploading}>
                Select File
              </Button>
              {file && <p className="flex items-center text-sm">{file.name}</p>}
            </div>
          </div>
        </div>

        {file && (
          <div className="flex flex-col gap-2">
            <h3 className="text-lg font-medium">Step 3: Import Students</h3>
            <p className="text-sm text-muted-foreground">Click the button below to start importing students.</p>
            <div className="flex gap-2">
              <Button onClick={handleUpload} disabled={isUploading || !file}>
                <Upload className="mr-2 h-4 w-4" />
                {isUploading ? "Importing..." : "Import Students"}
              </Button>
              <Button variant="outline" onClick={resetForm} disabled={isUploading}>
                Reset
              </Button>
            </div>
          </div>
        )}
      </div>

      {isUploading && (
        <div className="space-y-2">
          <p className="text-sm font-medium">Importing students...</p>
          <Progress value={progress} className="h-2" />
          <p className="text-xs text-muted-foreground">{progress}% complete</p>
        </div>
      )}

      {results && (
        <Alert variant={results.success ? "default" : "destructive"}>
          <div className="flex items-center gap-2">
            {results.success ? <CheckCircle2 className="h-4 w-4" /> : <AlertCircle className="h-4 w-4" />}
            <AlertTitle>{results.success ? "Import Completed" : "Import Failed"}</AlertTitle>
          </div>
          <AlertDescription>
            <div className="mt-2 space-y-2">
              {results.success && (
                <>
                  <p>Successfully imported {results.imported} students.</p>
                  {results.failed > 0 && <p>Failed to import {results.failed} students.</p>}
                </>
              )}

              {results.errors.length > 0 && (
                <div className="mt-2">
                  <p className="font-medium">Errors:</p>
                  <ul className="ml-4 list-disc">
                    {results.errors.slice(0, 5).map((error, index) => (
                      <li key={index} className="text-sm">
                        {error}
                      </li>
                    ))}
                    {results.errors.length > 5 && (
                      <li className="text-sm">...and {results.errors.length - 5} more errors</li>
                    )}
                  </ul>
                </div>
              )}
            </div>
          </AlertDescription>
        </Alert>
      )}
    </div>
  )
}
