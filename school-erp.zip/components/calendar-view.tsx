"use client"

import { Calendar } from "@/components/ui/calendar"
import { useState } from "react"

export function CalendarView() {
  const [date, setDate] = useState<Date | undefined>(new Date())

  return (
    <div className="p-2">
      <Calendar mode="single" selected={date} onSelect={setDate} className="rounded-md border" />
    </div>
  )
}
