import React from "react"
import { Button } from "@/components/ui/button"
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"
import { Plus } from "lucide-react"

interface PageTemplateProps {
  title: string
  description: string
  breadcrumbs: { title: string; href: string; isCurrentPage?: boolean }[]
  children: React.ReactNode
  actionButton?: {
    label: string
    icon?: React.ReactNode
    onClick?: () => void
    href?: string
  }
}

export function PageTemplate({ title, description, breadcrumbs = [], children, actionButton }: PageTemplateProps) {
  return (
    <div className="flex-1 space-y-4 p-4 md:p-6">
      <div className="flex flex-col space-y-2 md:flex-row md:items-center md:justify-between md:space-y-0">
        <div>
          <div className="mb-2">
            <Breadcrumb>
              <BreadcrumbList>
                <BreadcrumbItem>
                  <BreadcrumbLink href="/dashboard">Dashboard</BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator />
                {Array.isArray(breadcrumbs) &&
                  breadcrumbs.map((breadcrumb, index) => (
                    <React.Fragment key={index}>
                      <BreadcrumbItem>
                        {breadcrumb.isCurrentPage ? (
                          <span>{breadcrumb.title}</span>
                        ) : (
                          <BreadcrumbLink href={breadcrumb.href}>{breadcrumb.title}</BreadcrumbLink>
                        )}
                      </BreadcrumbItem>
                      {index < breadcrumbs.length - 1 && <BreadcrumbSeparator />}
                    </React.Fragment>
                  ))}
              </BreadcrumbList>
            </Breadcrumb>
          </div>
          <h2 className="text-2xl font-bold tracking-tight">{title}</h2>
          <p className="text-muted-foreground">{description}</p>
        </div>
        <div className="flex items-center gap-2">
          {actionButton && (
            <Button className="bg-theme-500 hover:bg-theme-600 text-white">
              {actionButton.icon || <Plus className="mr-2 h-4 w-4" />}
              {actionButton.label}
            </Button>
          )}
        </div>
      </div>
      {children}
    </div>
  )
}
