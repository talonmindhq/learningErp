"use client"

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

export function EnrollmentTrend() {
  const data = [
    {
      name: "Apr",
      "New Admissions": 20,
      "Total Students": 1150,
    },
    {
      name: "May",
      "New Admissions": 28,
      "Total Students": 1178,
    },
    {
      name: "Jun",
      "New Admissions": 40,
      "Total Students": 1218,
    },
    {
      name: "Jul",
      "New Admissions": 27,
      "Total Students": 1245,
    },
    {
      name: "Aug",
      "New Admissions": 18,
      "Total Students": 1263,
    },
    {
      name: "Sep",
      "New Admissions": 23,
      "Total Students": 1286,
    },
    {
      name: "Oct",
      "New Admissions": 34,
      "Total Students": 1320,
    },
    {
      name: "Nov",
      "New Admissions": 30,
      "Total Students": 1350,
    },
    {
      name: "Dec",
      "New Admissions": 25,
      "Total Students": 1375,
    },
    {
      name: "Jan",
      "New Admissions": 35,
      "Total Students": 1410,
    },
    {
      name: "Feb",
      "New Admissions": 41,
      "Total Students": 1451,
    },
    {
      name: "Mar",
      "New Admissions": 43,
      "Total Students": 1494,
    },
  ]

  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={data}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis yAxisId="left" />
          <YAxis yAxisId="right" orientation="right" />
          <Tooltip />
          <Legend />
          <Line
            yAxisId="left"
            type="monotone"
            dataKey="New Admissions"
            stroke="#00509d"
            activeDot={{ r: 8 }}
            strokeWidth={2}
          />
          <Line yAxisId="right" type="monotone" dataKey="Total Students" stroke="#ffb000" strokeWidth={2} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
