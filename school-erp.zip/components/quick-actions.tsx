"use client"

import { Button } from "@/components/ui/button"
import { UserPlus, CreditCard, FileText, Bell, Calendar, Users } from "lucide-react"

export function QuickActions() {
  const actions = [
    {
      title: "Add Student",
      icon: <UserPlus className="h-4 w-4" />,
      color: "bg-theme-100 text-theme-500",
      href: "/dashboard/students/add",
    },
    {
      title: "Fee Collection",
      icon: <CreditCard className="h-4 w-4" />,
      color: "bg-accent1-100 text-accent1-500",
      href: "/dashboard/fee-collection",
    },
    {
      title: "Attendance",
      icon: <Users className="h-4 w-4" />,
      color: "bg-accent2-100 text-accent2-500",
      href: "/dashboard/attendance",
    },
    {
      title: "Add Notice",
      icon: <Bell className="h-4 w-4" />,
      color: "bg-theme-200 text-theme-600",
      href: "/dashboard/notices/add",
    },
    {
      title: "Reports",
      icon: <FileText className="h-4 w-4" />,
      color: "bg-accent2-200 text-accent2-600",
      href: "/dashboard/reports",
    },
    {
      title: "Calendar",
      icon: <Calendar className="h-4 w-4" />,
      color: "bg-accent1-200 text-accent1-600",
      href: "/dashboard/calendar",
    },
  ]

  return (
    <div className="grid grid-cols-2 gap-2">
      {actions.map((action, index) => (
        <Button
          key={index}
          variant="outline"
          className="flex flex-col items-center justify-center h-20 space-y-1 hover:bg-gray-50"
          asChild
        >
          <a href={action.href}>
            <div className={`rounded-full p-2 ${action.color}`}>{action.icon}</div>
            <span className="text-xs font-medium">{action.title}</span>
          </a>
        </Button>
      ))}
    </div>
  )
}
