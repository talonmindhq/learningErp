"use client"

import type React from "react"

import { useEffect, useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { BookOpen, Bus, Calendar, CreditCard, Home, LifeBuoy, Users, UserCircle, FileText } from 'lucide-react'
import { Button } from "@/components/ui/button"

interface SidebarItem {
  title: string
  href: string
  icon: React.ElementType
  permission: string
}

// Update the sidebarItems array to include the grades section
const sidebarItems: SidebarItem[] = [
  {
    title: "Dashboard",
    href: "/",
    icon: Home,
    permission: "*", // Everyone can access
  },
  {
    title: "Students",
    href: "/students",
    icon: Users,
    permission: "manage_students",
  },
  {
    title: "Teachers",
    href: "/teachers",
    icon: UserCircle,
    permission: "manage_teachers",
  },
  {
    title: "Fees",
    href: "/fees",
    icon: CreditCard,
    permission: "manage_fees",
  },
  {
    title: "Attendance",
    href: "/attendance",
    icon: Calendar,
    permission: "manage_attendance",
  },
  {
    title: "Transportation",
    href: "/transportation",
    icon: Bus,
    permission: "manage_transportation",
  },
  {
    title: "Grades",
    href: "/grades",
    icon: FileText,
    permission: "manage_grades",
  },
  {
    title: "Reports",
    href: "/reports",
    icon: FileText,
    permission: "manage_reports",
  },
  {
    title: "Helpdesk",
    href: "/helpdesk",
    icon: LifeBuoy,
    permission: "*", // Everyone can access
  },
]

export function Sidebar() {
  const pathname = usePathname()
  const [userPermissions, setUserPermissions] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    async function fetchUserPermissions() {
      try {
        const response = await fetch("/api/auth/permissions")
        const data = await response.json()
        setUserPermissions(data.permissions || [])
      } catch (error) {
        console.error("Error fetching user permissions:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchUserPermissions()
  }, [])

  // Filter sidebar items based on user permissions
  const filteredItems = sidebarItems.filter(
    (item) => item.permission === "*" || userPermissions.includes(item.permission),
  )

  if (isLoading) {
    return (
      <div className="hidden border-r bg-muted/40 md:block md:w-64">
        <div className="flex h-full max-h-screen flex-col gap-2">
          <div className="flex h-14 items-center border-b px-4">
            <Link href="/" className="flex items-center gap-2 font-semibold">
              <BookOpen className="h-6 w-6" />
              <span>School 360</span>
            </Link>
          </div>
          <div className="flex-1 overflow-auto py-2">
            <div className="grid items-start px-2 text-sm font-medium">
              {/* Loading skeleton */}
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-10 w-full animate-pulse rounded-md bg-muted my-1"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="hidden border-r bg-muted/40 md:block md:w-64">
      <div className="flex h-full max-h-screen flex-col gap-2">
        <div className="flex h-14 items-center border-b px-4">
          <Link href="/" className="flex items-center gap-2 font-semibold">
            <BookOpen className="h-6 w-6" />
            <span>School 360</span>
          </Link>
        </div>
        <div className="flex-1 overflow-auto py-2">
          <nav className="grid items-start px-2 text-sm font-medium">
            {filteredItems.map((item) => (
              <Button
                key={item.href}
                asChild
                variant={pathname === item.href ? "secondary" : "ghost"}
                className="justify-start"
              >
                <Link href={item.href}>
                  <item.icon className="mr-2 h-4 w-4" />
                  {item.title}
                </Link>
              </Button>
            ))}
          </nav>
        </div>
      </div>
    </div>
  )
}
