"use client"

import { useState } from "react"
import Link from "next/link"
import { Edit, Eye, MoreHorizontal, Trash, Users } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export function TransportationTable() {
  const [routes] = useState([
    {
      id: 1,
      name: "Route 1 - North",
      driver: "John Smith",
      vehicle: "Bus 101",
      capacity: 40,
      students: 32,
      status: "Active",
    },
    {
      id: 2,
      name: "Route 2 - South",
      driver: "Emily Johnson",
      vehicle: "Bus 102",
      capacity: 40,
      students: 38,
      status: "Active",
    },
    {
      id: 3,
      name: "Route 3 - East",
      driver: "Michael Brown",
      vehicle: "Bus 103",
      capacity: 40,
      students: 25,
      status: "Active",
    },
    {
      id: 4,
      name: "Route 4 - West",
      driver: "Sarah Davis",
      vehicle: "Bus 104",
      capacity: 40,
      students: 30,
      status: "Active",
    },
    {
      id: 5,
      name: "Route 5 - Central",
      driver: "Robert Wilson",
      vehicle: "Bus 105",
      capacity: 40,
      students: 35,
      status: "Inactive",
    },
  ])

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Route Name</TableHead>
          <TableHead>Driver</TableHead>
          <TableHead>Vehicle</TableHead>
          <TableHead>Capacity</TableHead>
          <TableHead>Students</TableHead>
          <TableHead>Status</TableHead>
          <TableHead className="text-right">Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {routes.map((route) => (
          <TableRow key={route.id}>
            <TableCell className="font-medium">{route.name}</TableCell>
            <TableCell>{route.driver}</TableCell>
            <TableCell>{route.vehicle}</TableCell>
            <TableCell>{route.capacity}</TableCell>
            <TableCell>{route.students}</TableCell>
            <TableCell>
              <Badge variant={route.status === "Active" ? "default" : "secondary"}>{route.status}</Badge>
            </TableCell>
            <TableCell className="text-right">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <MoreHorizontal className="h-4 w-4" />
                    <span className="sr-only">Actions</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>Actions</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href={`/transportation/${route.id}`}>
                      <Eye className="mr-2 h-4 w-4" />
                      View
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href={`/transportation/${route.id}/edit`}>
                      <Edit className="mr-2 h-4 w-4" />
                      Edit
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href={`/transportation/${route.id}/students`}>
                      <Users className="mr-2 h-4 w-4" />
                      View Students
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="text-destructive">
                    <Trash className="mr-2 h-4 w-4" />
                    Delete
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )
}
