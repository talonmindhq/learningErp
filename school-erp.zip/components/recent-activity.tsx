"use client"

import { UserPlus, CreditCard, FileText, Bell, CheckCircle2, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"

export function RecentActivity() {
  const activities = [
    {
      id: 1,
      title: "New student added",
      time: "2 hours ago",
      icon: <UserPlus className="h-3.5 w-3.5" />,
      color: "bg-theme-100 text-theme-500",
      user: "Admin",
    },
    {
      id: 2,
      title: "Fee collected",
      time: "3 hours ago",
      icon: <CreditCard className="h-3.5 w-3.5" />,
      color: "bg-accent1-100 text-accent1-500",
      user: "Accountant",
    },
    {
      id: 3,
      title: "Attendance marked",
      time: "5 hours ago",
      icon: <CheckCircle2 className="h-3.5 w-3.5" />,
      color: "bg-accent2-100 text-accent2-500",
      user: "Class Teacher",
    },
    {
      id: 4,
      title: "Notice published",
      time: "Yesterday",
      icon: <Bell className="h-3.5 w-3.5" />,
      color: "bg-theme-200 text-theme-600",
      user: "Principal",
    },
    {
      id: 5,
      title: "Report generated",
      time: "Yesterday",
      icon: <FileText className="h-3.5 w-3.5" />,
      color: "bg-accent2-200 text-accent2-600",
      user: "Admin",
    },
  ]

  return (
    <div className="space-y-4">
      {activities.map((activity) => (
        <div key={activity.id} className="border-b pb-3 last:border-0">
          <div className="flex items-start gap-3">
            <div className={`rounded-full p-1.5 ${activity.color}`}>{activity.icon}</div>
            <div className="space-y-1">
              <h4 className="text-sm font-medium">{activity.title}</h4>
              <div className="flex items-center">
                <Clock className="h-3 w-3 text-muted-foreground mr-1" />
                <span className="text-xs text-muted-foreground">{activity.time}</span>
                <span className="text-xs text-muted-foreground mx-1">•</span>
                <span className="text-xs text-muted-foreground">{activity.user}</span>
              </div>
            </div>
          </div>
        </div>
      ))}
      <Button variant="ghost" className="w-full text-xs h-8 text-theme-500 hover:bg-theme-50">
        View All Activity
      </Button>
    </div>
  )
}
