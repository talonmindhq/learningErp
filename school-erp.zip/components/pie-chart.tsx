"use client"

import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts"

interface PieChartProps {
  data: Array<{
    name: string
    value: number
  }>
  colors?: string[]
}

export function GradePieChart({
  data,
  colors = ["#4f46e5", "#60a5fa", "#34d399", "#fbbf24", "#f87171"],
}: PieChartProps) {
  // Default colors if not provided
  const chartColors = colors.length >= data.length ? colors : ["#4f46e5", "#60a5fa", "#34d399", "#fbbf24", "#f87171"]

  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            labelLine={false}
            outerRadius={80}
            fill="#8884d8"
            dataKey="value"
            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={chartColors[index % chartColors.length]} />
            ))}
          </Pie>
          <Tooltip formatter={(value) => [`${value} students`, "Count"]} />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </div>
  )
}
