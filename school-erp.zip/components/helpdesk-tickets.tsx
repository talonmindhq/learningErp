import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export function HelpdeskTickets() {
  const tickets = [
    {
      id: 1,
      subject: "Login Issue",
      user: "Olivia Martin",
      role: "Student",
      status: "Open",
      created: "2023-05-01",
    },
    {
      id: 2,
      subject: "Fee Payment Problem",
      user: "Jackson Lee",
      role: "Parent",
      status: "In Progress",
      created: "2023-05-02",
    },
    {
      id: 3,
      subject: "Attendance Correction",
      user: "Isabella Nguyen",
      role: "Student",
      status: "Closed",
      created: "2023-05-03",
    },
    {
      id: 4,
      subject: "Transport Route Change",
      user: "William Kim",
      role: "Student",
      status: "Open",
      created: "2023-05-04",
    },
    {
      id: 5,
      subject: "Grade Report Issue",
      user: "Sofia Davis",
      role: "Teacher",
      status: "In Progress",
      created: "2023-05-05",
    },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle>Helpdesk Tickets</CardTitle>
        <CardDescription>Recent support tickets raised in the system.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {tickets.map((ticket) => (
            <div key={ticket.id} className="flex items-center justify-between space-x-4">
              <div>
                <p className="text-sm font-medium leading-none">{ticket.subject}</p>
                <p className="text-sm text-muted-foreground">
                  {ticket.user} ({ticket.role})
                </p>
              </div>
              <div>
                <Badge
                  variant={
                    ticket.status === "Open" ? "default" : ticket.status === "In Progress" ? "outline" : "secondary"
                  }
                >
                  {ticket.status}
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
