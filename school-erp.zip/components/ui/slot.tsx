"use client"

import * as React from "react"

/**
 * A simple component that renders its children without any additional markup.
 * This is a replacement for Radix UI's Slot component to avoid dependency issues.
 */
const Slot = React.forwardRef<HTMLElement, React.HTMLAttributes<HTMLElement> & { asChild?: boolean }>(
  ({ children, asChild = false, ...props }, ref) => {
    // If asChild is true, we clone the single child and merge the props
    if (asChild && React.isValidElement(children)) {
      return React.cloneElement(children, {
        ...props,
        ...children.props,
        ref: ref
          ? // @ts-ignore - TypeScript doesn't know how to handle this properly
            (node: unknown) => {
              if (typeof ref === "function") ref(node as HTMLElement)
              const { ref: childRef } = children as unknown as {
                ref: React.Ref<HTMLElement>
              }
              if (childRef) {
                if (typeof childRef === "function") childRef(node as HTMLElement)
                else (childRef as React.MutableRefObject<HTMLElement>).current = node as HTMLElement
              }
            }
          : undefined,
      })
    }

    // Otherwise, render a span with the props
    return (
      <span ref={ref as React.Ref<HTMLSpanElement>} {...props}>
        {children}
      </span>
    )
  },
)
Slot.displayName = "Slot"

export { Slot }
