"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/components/ui/use-toast"
import { createInventoryItem } from "@/app/actions/inventory-actions"

interface AddInventoryItemFormProps {
  categories: string[]
  locations: string[]
}

export default function AddInventoryItemForm({ categories = [], locations = [] }: AddInventoryItemFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [newCategory, setNewCategory] = useState("")
  const [newLocation, setNewLocation] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("")
  const [selectedLocation, setSelectedLocation] = useState("")

  const handleSubmit = async (formData: FormData) => {
    setIsSubmitting(true)

    try {
      // If user entered a new category or location, use that instead of the selected one
      if (newCategory) {
        formData.set("category", newCategory)
      }

      if (newLocation) {
        formData.set("location", newLocation)
      }

      const response = await createInventoryItem(formData)

      if (response.success) {
        toast({
          title: "Item Added",
          description: "The inventory item has been added successfully.",
        })

        // Reset form
        const form = document.getElementById("add-inventory-form") as HTMLFormElement
        if (form) form.reset()
        setNewCategory("")
        setNewLocation("")
        setSelectedCategory("")
        setSelectedLocation("")
      } else {
        toast({
          title: "Error",
          description: response.error || "Failed to add inventory item",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error adding inventory item:", error)
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form id="add-inventory-form" action={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="name">Item Name</Label>
          <Input id="name" name="name" placeholder="Enter item name" required />
        </div>

        <div className="space-y-2">
          <Label htmlFor="quantity">Quantity</Label>
          <Input id="quantity" name="quantity" type="number" min="0" defaultValue="0" required />
        </div>

        <div className="space-y-2">
          <Label htmlFor="category">Category</Label>
          <div className="space-y-2">
            <Select value={selectedCategory} onValueChange={setSelectedCategory} name="category">
              <SelectTrigger>
                <SelectValue placeholder="Select a category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
                <SelectItem value="new">+ Add New Category</SelectItem>
              </SelectContent>
            </Select>

            {selectedCategory === "new" && (
              <Input
                placeholder="Enter new category"
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
              />
            )}
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="location">Location</Label>
          <div className="space-y-2">
            <Select value={selectedLocation} onValueChange={setSelectedLocation} name="location">
              <SelectTrigger>
                <SelectValue placeholder="Select a location" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                {locations.map((location) => (
                  <SelectItem key={location} value={location}>
                    {location}
                  </SelectItem>
                ))}
                <SelectItem value="new">+ Add New Location</SelectItem>
              </SelectContent>
            </Select>

            {selectedLocation === "new" && (
              <Input
                placeholder="Enter new location"
                value={newLocation}
                onChange={(e) => setNewLocation(e.target.value)}
              />
            )}
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea id="description" name="description" placeholder="Enter item description" rows={3} />
      </div>

      <Button type="submit" className="w-full md:w-auto" disabled={isSubmitting}>
        {isSubmitting ? "Adding..." : "Add Item"}
      </Button>
    </form>
  )
}
