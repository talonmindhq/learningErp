// Simple script to run tests with proper output formatting
const { execSync } = require("child_process")

console.log("\n🧪 Running School ERP Tests...\n")

try {
  // Run Jest tests with verbose output
  execSync("npm test -- --verbose", { stdio: "inherit" })

  console.log("\n✅ All tests passed successfully!\n")
} catch (error) {
  console.error("\n❌ Some tests failed. Please check the output above for details.\n")
  process.exit(1)
}
