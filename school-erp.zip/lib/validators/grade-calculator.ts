/**
 * Utility functions for validating and calculating grades
 */

// Calculate weighted grade based on assessments and scores
export function calculateWeightedGrade(assessments: { weight: number; score: number }[]): number {
  // Handle empty assessments
  if (assessments.length === 0) {
    return 0
  }

  // Validate that weights sum to approximately 100%
  const totalWeight = assessments.reduce((sum, assessment) => sum + assessment.weight, 0)
  if (Math.abs(totalWeight - 100) > 0.1) {
    console.warn(`Warning: Assessment weights sum to ${totalWeight}%, not 100%`)
  }

  // Calculate weighted grade
  const weightedGrade = assessments.reduce((total, assessment) => {
    // Convert weight from percentage to decimal (e.g., 40% -> 0.4)
    const weightDecimal = assessment.weight / 100
    return total + assessment.score * weightDecimal
  }, 0)

  // Round to 2 decimal places
  return Math.round(weightedGrade * 100) / 100
}

// Determine letter grade based on percentage
export function calculateLetterGrade(percentage: number): string {
  if (percentage >= 90) return "A"
  if (percentage >= 80) return "B"
  if (percentage >= 70) return "C"
  if (percentage >= 60) return "D"
  return "F"
}

// Calculate class statistics for a set of grades
export function calculateClassStatistics(grades: number[]): {
  average: number
  highest: number
  lowest: number
  median: number
  passingRate: number
} {
  if (!grades.length) {
    return { average: 0, highest: 0, lowest: 0, median: 0, passingRate: 0 }
  }

  // Sort grades for calculations
  const sortedGrades = [...grades].sort((a, b) => a - b)

  const sum = sortedGrades.reduce((total, grade) => total + grade, 0)
  const average = Math.round((sum / grades.length) * 100) / 100
  const highest = sortedGrades[sortedGrades.length - 1]
  const lowest = sortedGrades[0]

  // Calculate median
  let median
  const midIndex = Math.floor(sortedGrades.length / 2)
  if (sortedGrades.length % 2 === 0) {
    median = (sortedGrades[midIndex - 1] + sortedGrades[midIndex]) / 2
  } else {
    median = sortedGrades[midIndex]
  }

  // Calculate passing rate (grades >= 60%)
  const passingCount = sortedGrades.filter((grade) => grade >= 60).length
  const passingRate = Math.round((passingCount / grades.length) * 100)

  return { average, highest, lowest, median, passingRate }
}

// Validate assessment weights
export function validateAssessmentWeights(assessments: { weight: number }[]): {
  valid: boolean
  message: string
  totalWeight: number
} {
  const totalWeight = assessments.reduce((sum, assessment) => sum + assessment.weight, 0)

  // Allow small rounding errors (e.g., 99.99% should be considered valid)
  if (Math.abs(totalWeight - 100) > 0.1) {
    return {
      valid: false,
      message: `Assessment weights sum to ${totalWeight}%, not 100%`,
      totalWeight,
    }
  }

  return { valid: true, message: "Assessment weights are valid", totalWeight }
}

// Validate grade input
export function validateGradeInput(
  grade: number,
  maxScore = 100,
): {
  valid: boolean
  message: string
} {
  if (grade < 0) {
    return { valid: false, message: "Grade cannot be negative" }
  }

  if (grade > maxScore) {
    return { valid: false, message: `Grade cannot exceed maximum score of ${maxScore}` }
  }

  return { valid: true, message: "Grade is valid" }
}

export function calculateFinalGrade(grades: any[]): number | null {
  if (!grades || grades.length === 0) {
    return null
  }

  let totalWeight = 0
  let weightedSum = 0

  for (const grade of grades) {
    if (grade.weight && grade.max_marks && grade.marks) {
      const weight = grade.weight / 100 // Convert percentage to decimal
      const scorePercentage = (grade.marks / grade.max_marks) * 100

      weightedSum += scorePercentage * weight
      totalWeight += weight
    }
  }

  if (totalWeight === 0) {
    return null
  }

  const finalGrade = weightedSum / totalWeight
  return Math.round(finalGrade * 100) / 100 // Round to two decimal places
}
