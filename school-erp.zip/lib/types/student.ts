export interface Student {
  id: number
  first_name: string
  last_name: string
  email: string
  phone?: string | null
  grade: string
  address?: string | null
  admission_date?: string | null
  transport_route_id?: number | null
  status?: string | null
  admission_number?: string | null
  date_of_birth?: string | null
  gender?: string | null
  parent_name?: string | null
  parent_phone?: string | null
  parent_email?: string | null
}

export interface StudentFormData {
  first_name: string
  last_name: string
  email: string
  phone?: string
  grade: string
  address?: string
  admission_date?: string
  status?: string
  admission_number: string
  date_of_birth?: string
  gender?: string
  parent_name?: string
  parent_phone?: string
  parent_email?: string
}
