export interface InventoryItem {
  id: number
  name: string
  description: string | null
  quantity: number
  category: string | null
  location: string | null
  created_at: string
  updated_at: string
}
