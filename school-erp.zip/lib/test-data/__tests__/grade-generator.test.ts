import {
  generateTestAssessments,
  generateTestGrades,
  insertTestAssessments,
  insertTestGrades,
} from "../grade-generator"
import { executeQuery } from "@/lib/db"

// Mock the database functions
jest.mock("@/lib/db", () => ({
  executeQuery: jest.fn(),
}))

describe("Test Data Generator", () => {
  beforeEach(() => {
    // Reset mocks before each test
    jest.clearAllMocks()

    // Mock database responses
    ;(executeQuery as jest.Mock).mockImplementation((query) => {
      if (query.includes("assessment_types")) {
        return Promise.resolve([{ id: 1, name: "Quiz", weight: 10 }])
      }
      if (query.includes("subjects")) {
        return Promise.resolve([{ id: 1, name: "Math" }])
      }
      if (query.includes("academic_terms")) {
        return Promise.resolve([
          {
            id: 1,
            name: "Spring 2023",
            start_date: "2023-01-15",
            end_date: "2023-05-30",
          },
        ])
      }
      if (query.includes("grade FROM students")) {
        return Promise.resolve([{ grade: "10th" }])
      }
      if (query.includes("students WHERE grade")) {
        return Promise.resolve([
          { id: 1, first_name: "John", last_name: "Doe" },
          { id: 2, first_name: "Jane", last_name: "Smith" },
        ])
      }
      if (query === "BEGIN" || query === "COMMIT" || query === "ROLLBACK") {
        return Promise.resolve([])
      }
      if (query.includes("INSERT INTO")) {
        return Promise.resolve([{ id: 1 }])
      }
      return Promise.resolve([])
    })
  })

  describe("generateTestAssessments", () => {
    it("should generate the requested number of assessments", async () => {
      const assessments = await generateTestAssessments(5)
      expect(assessments.length).toBe(5)

      // Verify assessment properties
      assessments.forEach((assessment) => {
        expect(assessment).toHaveProperty("name")
        expect(assessment).toHaveProperty("description")
        expect(assessment).toHaveProperty("assessment_type_id")
        expect(assessment).toHaveProperty("subject_id")
        expect(assessment).toHaveProperty("max_score")
        expect(assessment).toHaveProperty("weight")
        expect(assessment).toHaveProperty("academic_term_id")
        expect(assessment).toHaveProperty("grade")
        expect(assessment).toHaveProperty("date")
      })
    })

    it("should handle missing reference data", async () => {
      // Mock empty assessment types
      ;(executeQuery as jest.Mock).mockImplementationOnce(() => Promise.resolve([]))

      const assessments = await generateTestAssessments(5)
      expect(assessments.length).toBe(0)
    })

    it("should generate assessments with weights between 10 and 40", async () => {
      const assessments = await generateTestAssessments(10)

      assessments.forEach((assessment) => {
        expect(assessment.weight).toBeGreaterThanOrEqual(10)
        expect(assessment.weight).toBeLessThanOrEqual(40)
      })
    })
  })

  describe("generateTestGrades", () => {
    it("should generate grades for all students", async () => {
      // Mock assessment result
      ;(executeQuery as jest.Mock).mockImplementationOnce(() => Promise.resolve([{ id: 1, grade: "10th" }]))

      const assessmentId = 1

      const grades = await generateTestGrades(assessmentId)
      expect(grades.length).toBe(2) // Two students

      // Verify grade properties
      grades.forEach((grade) => {
        expect(grade).toHaveProperty("student_id")
        expect(grade).toHaveProperty("assessment_id", assessmentId)
        expect(grade).toHaveProperty("score")

        // Verify score is within valid range
        expect(grade.score).toBeGreaterThanOrEqual(0)
        expect(grade.score).toBeLessThanOrEqual(100)
      })
    })

    it("should handle assessment not found", async () => {
      // Mock empty assessment result
      ;(executeQuery as jest.Mock).mockImplementationOnce(() => Promise.resolve([]))

      await expect(generateTestGrades(999)).rejects.toThrow("Assessment with ID 999 not found")
    })

    it("should handle no students found", async () => {
      // Mock assessment result
      ;(executeQuery as jest.Mock).mockImplementationOnce(() => Promise.resolve([{ id: 1, grade: "10th" }]))

      // Mock empty students result
      ;(executeQuery as jest.Mock).mockImplementationOnce(() => Promise.resolve([]))

      await expect(generateTestGrades(1)).rejects.toThrow("No active students found in grade 10th")
    })

    it("should generate some grades with remarks", async () => {
      // Mock assessment result
      ;(executeQuery as jest.Mock).mockImplementationOnce(() => Promise.resolve([{ id: 1, grade: "10th" }]))

      // Mock a larger set of students for better statistical sampling
      ;(executeQuery as jest.Mock).mockImplementationOnce(() => {
        return Promise.resolve(
          Array.from({ length: 20 }, (_, i) => ({
            id: i + 1,
            first_name: `Student`,
            last_name: `${i + 1}`,
          })),
        )
      })

      const grades = await generateTestGrades(1)
      expect(grades.length).toBe(20)

      // Some grades should have remarks
      const gradesWithRemarks = grades.filter((g) => g.remarks !== undefined)
      expect(gradesWithRemarks.length).toBeGreaterThan(0)
    })
  })

  describe("insertTestAssessments", () => {
    it("should insert assessments and return their IDs", async () => {
      const assessments = [
        {
          name: "Test Quiz 1",
          description: "Test description",
          assessment_type_id: 1,
          subject_id: 1,
          max_score: 100,
          weight: 20,
          academic_term_id: 1,
          grade: "10th",
          date: "2023-05-15",
        },
        {
          name: "Test Quiz 2",
          description: "Test description",
          assessment_type_id: 1,
          subject_id: 1,
          max_score: 100,
          weight: 30,
          academic_term_id: 1,
          academic_term_id: 1,
          grade: "10th",
          date: "2023-05-20",
        },
      ]

      const ids = await insertTestAssessments(assessments)
      expect(ids.length).toBe(2)
      expect(ids).toEqual([1, 1]) // Mock returns id: 1 for each insert

      // Verify transaction was used
      expect(executeQuery).toHaveBeenCalledWith("BEGIN")
      expect(executeQuery).toHaveBeenCalledWith("COMMIT")
    })

    it("should handle database errors and rollback", async () => {
      // Mock BEGIN transaction
      ;(executeQuery as jest.Mock).mockResolvedValueOnce([])

      // Mock error during insert
      ;(executeQuery as jest.Mock).mockRejectedValueOnce(new Error("Database error"))

      // Mock ROLLBACK
      ;(executeQuery as jest.Mock).mockResolvedValueOnce([])

      const assessments = [
        {
          name: "Test Quiz",
          description: "Test description",
          assessment_type_id: 1,
          subject_id: 1,
          max_score: 100,
          weight: 20,
          academic_term_id: 1,
          grade: "10th",
          date: "2023-05-15",
        },
      ]

      const ids = await insertTestAssessments(assessments)
      expect(ids.length).toBe(0)

      // Verify ROLLBACK was called
      expect(executeQuery).toHaveBeenCalledWith("ROLLBACK")
    })
  })

  describe("insertTestGrades", () => {
    it("should insert grades and return success", async () => {
      const grades = [
        {
          student_id: 1,
          assessment_id: 1,
          score: 85,
          remarks: "Good work",
        },
        {
          student_id: 2,
          assessment_id: 1,
          score: 92,
          remarks: "Excellent",
        },
      ]

      const success = await insertTestGrades(grades)
      expect(success).toBe(true)

      // Verify transaction was used
      expect(executeQuery).toHaveBeenCalledWith("BEGIN")
      expect(executeQuery).toHaveBeenCalledWith("COMMIT")
    })

    it("should handle database errors and rollback", async () => {
      // Mock BEGIN transaction
      ;(executeQuery as jest.Mock).mockResolvedValueOnce([])

      // Mock error during insert
      ;(executeQuery as jest.Mock).mockRejectedValueOnce(new Error("Database error"))

      // Mock ROLLBACK
      ;(executeQuery as jest.Mock).mockResolvedValueOnce([])

      const grades = [
        {
          student_id: 1,
          assessment_id: 1,
          score: 85,
          remarks: "Good work",
        },
      ]

      const success = await insertTestGrades(grades)
      expect(success).toBe(false)

      // Verify ROLLBACK was called
      expect(executeQuery).toHaveBeenCalledWith("ROLLBACK")
    })
  })
})
