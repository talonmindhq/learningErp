/**
 * Utility to generate test data for assessments and grades
 */

import { executeQuery } from "@/lib/db"

// Types for generated data
interface GeneratedAssessment {
  name: string
  description: string
  assessment_type_id: number
  subject_id: number
  max_score: number
  weight: number
  academic_term_id: number
  grade: string
  date: string
}

interface GeneratedGrade {
  student_id: number
  assessment_id: number
  score: number
  remarks?: string
}

// Generate random assessment data
export async function generateTestAssessments(count = 5): Promise<GeneratedAssessment[]> {
  try {
    // Fetch existing assessment types, subjects, and academic terms
    const assessmentTypes = await executeQuery("SELECT id FROM assessment_types")
    const subjects = await executeQuery("SELECT id FROM subjects")
    const academicTerms = await executeQuery("SELECT id FROM academic_terms")
    const grades = await executeQuery("SELECT DISTINCT grade FROM students")

    if (!assessmentTypes.length || !subjects.length || !academicTerms.length || !grades.length) {
      throw new Error("Missing required reference data for generating assessments")
    }

    const assessmentNames = [
      "Quiz",
      "Mid-Term Exam",
      "Final Exam",
      "Assignment",
      "Project",
      "Presentation",
      "Lab Work",
      "Homework",
      "Essay",
      "Research Paper",
    ]

    const generatedAssessments: GeneratedAssessment[] = []

    for (let i = 0; i < count; i++) {
      const assessmentType = assessmentTypes[Math.floor(Math.random() * assessmentTypes.length)]
      const subject = subjects[Math.floor(Math.random() * subjects.length)]
      const academicTerm = academicTerms[Math.floor(Math.random() * academicTerms.length)]
      const grade = grades[Math.floor(Math.random() * grades.length)]

      // Generate a random date within the current academic term
      const termStart = new Date(academicTerm.start_date)
      const termEnd = new Date(academicTerm.end_date)
      const randomDate = new Date(termStart.getTime() + Math.random() * (termEnd.getTime() - termStart.getTime()))

      // Generate a random weight between 10 and 40
      const weight = Math.floor(Math.random() * 31) + 10

      generatedAssessments.push({
        name: `${assessmentNames[Math.floor(Math.random() * assessmentNames.length)]} ${i + 1}`,
        description: `Test assessment ${i + 1} for ${subject.name}`,
        assessment_type_id: assessmentType.id,
        subject_id: subject.id,
        max_score: 100,
        weight: weight,
        academic_term_id: academicTerm.id,
        grade: grade.grade,
        date: randomDate.toISOString().split("T")[0],
      })
    }

    return generatedAssessments
  } catch (error) {
    console.error("Error generating test assessments:", error)
    return []
  }
}

// Generate random grades for students
export async function generateTestGrades(assessmentId: number): Promise<GeneratedGrade[]> {
  try {
    // Get the assessment details
    const assessments = await executeQuery("SELECT * FROM assessments WHERE id = $1", [assessmentId])

    if (!assessments.length) {
      throw new Error(`Assessment with ID ${assessmentId} not found`)
    }

    const assessment = assessments[0]

    // Get students in the specified grade
    const students = await executeQuery("SELECT id FROM students WHERE grade = $1 AND status = 'Active'", [
      assessment.grade,
    ])

    if (!students.length) {
      throw new Error(`No active students found in grade ${assessment.grade}`)
    }

    const remarks = [
      "Excellent work!",
      "Good effort",
      "Needs improvement",
      "Outstanding performance",
      "Please see me after class",
      "Great progress",
      "Missing some key concepts",
      "Very creative approach",
    ]

    const generatedGrades: GeneratedGrade[] = []

    // Generate grades for each student
    for (const student of students) {
      // Generate a random score between 50 and 100
      // Using a bell curve distribution to make it more realistic
      let score = Math.floor(Math.random() * 51) + 50

      // Occasionally generate a very high or very low score
      if (Math.random() < 0.1) {
        score = Math.floor(Math.random() * 50) // Low score (0-49)
      } else if (Math.random() < 0.1) {
        score = Math.floor(Math.random() * 10) + 91 // High score (91-100)
      }

      // Add remarks for some students
      const hasRemarks = Math.random() < 0.3 // 30% chance of having remarks

      generatedGrades.push({
        student_id: student.id,
        assessment_id: assessmentId,
        score: score,
        remarks: hasRemarks ? remarks[Math.floor(Math.random() * remarks.length)] : undefined,
      })
    }

    return generatedGrades
  } catch (error) {
    console.error("Error generating test grades:", error)
    return []
  }
}

// Insert generated assessments into the database
export async function insertTestAssessments(assessments: GeneratedAssessment[]): Promise<number[]> {
  try {
    const insertedIds: number[] = []

    // Begin transaction
    await executeQuery("BEGIN")

    for (const assessment of assessments) {
      const result = await executeQuery(
        `INSERT INTO assessments 
         (name, description, assessment_type_id, subject_id, max_score, weight, academic_term_id, grade, date) 
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) 
         RETURNING id`,
        [
          assessment.name,
          assessment.description,
          assessment.assessment_type_id,
          assessment.subject_id,
          assessment.max_score,
          assessment.weight,
          assessment.academic_term_id,
          assessment.grade,
          assessment.date,
        ],
      )

      insertedIds.push(result[0].id)
    }

    // Commit transaction
    await executeQuery("COMMIT")

    return insertedIds
  } catch (error) {
    // Rollback transaction on error
    await executeQuery("ROLLBACK")
    console.error("Error inserting test assessments:", error)
    return []
  }
}

// Insert generated grades into the database
export async function insertTestGrades(grades: GeneratedGrade[]): Promise<boolean> {
  try {
    // Begin transaction
    await executeQuery("BEGIN")

    for (const grade of grades) {
      await executeQuery(
        `INSERT INTO grades 
         (student_id, assessment_id, score, remarks) 
         VALUES ($1, $2, $3, $4)`,
        [grade.student_id, grade.assessment_id, grade.score, grade.remarks || null],
      )
    }

    // Commit transaction
    await executeQuery("COMMIT")

    return true
  } catch (error) {
    // Rollback transaction on error
    await executeQuery("ROLLBACK")
    console.error("Error inserting test grades:", error)
    return false
  }
}
