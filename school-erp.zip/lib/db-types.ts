// Define TypeScript types that match your actual database schema

// Academic Terms
export interface AcademicTerm {
  id: number
  name: string
  start_date: string
  end_date: string
  is_current: boolean
  created_at: string
}

// Assessment Types
export interface AssessmentType {
  id: number
  name: string
  description: string | null
  weight: number
  created_at: string
}

// Assessments
export interface Assessment {
  id: number
  title: string
  description: string | null
  assessment_type_id: number
  subject: string
  max_score: number
  teacher_id: number
  assessment_date: string
  grade: string
  created_at: string
}

// Attendance
export interface Attendance {
  id: number
  student_id: number
  date: string
  status: string
  remarks: string | null
  recorded_by: number
  recorded_at: string
}

// Users (based on what we've seen)
export interface User {
  id: number
  email: string
  password: string
  role: string
  last_login: string | null
  created_at: string
}
