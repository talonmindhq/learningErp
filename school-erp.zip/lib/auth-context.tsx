"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

// Define the user type
type User = {
  id: string
  name: string
  email: string
  role: string
}

// Define the auth context type
type AuthContextType = {
  user: User | null
  login: (email: string, password: string, role: string) => Promise<boolean>
  logout: () => void
  isLoading: boolean
}

// Create the auth context
const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Create a provider component
export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  // Load user from localStorage on mount
  useEffect(() => {
    const storedUser = localStorage.getItem("user")
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser))
      } catch (error) {
        console.error("Failed to parse stored user:", error)
        localStorage.removeItem("user")
      }
    }
    setIsLoading(false)
  }, [])

  // Login function - client-side only, no API calls
  const login = async (email: string, password: string, role: string): Promise<boolean> => {
    setIsLoading(true)

    try {
      // For testing purposes, accept any credentials
      // In a real app, this would validate against the database

      // Create a mock user based on the provided credentials
      const mockUser: User = {
        id: "1",
        name: email
          .split("@")[0]
          .replace(/\./g, " ")
          .replace(/\b\w/g, (l) => l.toUpperCase()),
        email,
        role,
      }

      // Store the user in localStorage
      localStorage.setItem("user", JSON.stringify(mockUser))

      // Update the state
      setUser(mockUser)
      setIsLoading(false)

      return true
    } catch (error) {
      console.error("Login error:", error)
      setIsLoading(false)
      return false
    }
  }

  // Logout function
  const logout = () => {
    localStorage.removeItem("user")
    setUser(null)
  }

  return <AuthContext.Provider value={{ user, login, logout, isLoading }}>{children}</AuthContext.Provider>
}

// Create a hook to use the auth context
export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
