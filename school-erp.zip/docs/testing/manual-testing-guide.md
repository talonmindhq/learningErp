# Manual Testing Guide for School ERP

This guide provides step-by-step instructions for manually testing the Grade Management and Enhanced Reporting features of the School 360 ERP system.

## Prerequisites

Before starting the manual testing, ensure you have:

1. A test environment with the School ERP system installed
2. Test user accounts with different roles (Admin, Teacher, Student)
3. Sample data for testing (or use the Test Data Generator)

## 1. Grade Calculation Validator Testing

### Test Case 1.1: Basic Weighted Grade Calculation

1. **Setup:**
   - Log in as a Teacher
   - Navigate to Grades > Create Assessment
   - Create two assessments for the same subject, term, and grade:
     - Assessment 1: Quiz, weight 40%
     - Assessment 2: Exam, weight 60%

2. **Test Steps:**
   - Enter grades for a student:
     - Assessment 1: 80/100
     - Assessment 2: 90/100
   
3. **Expected Result:**
   - The weighted grade should be 86% (80 × 0.4 + 90 × 0.6)
   - The letter grade should be B

### Test Case 1.2: Edge Case - Weights Don't Sum to 100%

1. **Setup:**
   - Log in as a Teacher
   - Navigate to Grades > Create Assessment
   - Try to create assessments with weights that don't sum to 100%

2. **Test Steps:**
   - Create Assessment 1: Quiz, weight 30%
   - Create Assessment 2: Exam, weight 30%
   - Create Assessment 3: Project, weight 30%
   - Try to save these assessments

3. **Expected Result:**
   - The system should show a warning that weights don't sum to 100%
   - The system should prevent saving the assessments

### Test Case 1.3: Letter Grade Boundary Cases

1. **Setup:**
   - Log in as a Teacher
   - Navigate to Grades > Create Assessment
   - Create an assessment with 100% weight

2. **Test Steps:**
   - Enter the following grades for different students:
     - Student 1: 90% (boundary for A)
     - Student 2: 89.99% (just below A boundary)
     - Student 3: 80% (boundary for B)
     - Student 4: 70% (boundary for C)
     - Student 5: 60% (boundary for D)
     - Student 6: 59.99% (just below D boundary)

3. **Expected Result:**
   - Student 1 should receive an A
   - Student 2 should receive a B
   - Student 3 should receive a B
   - Student 4 should receive a C
   - Student 5 should receive a D
   - Student 6 should receive an F

## 2. Enhanced Error Handling Testing

### Test Case 2.1: Invalid Grade Input

1. **Setup:**
   - Log in as a Teacher
   - Navigate to an existing assessment's grade entry page

2. **Test Steps:**
   - Try to enter the following invalid grades:
     - Negative grade (-10)
     - Grade exceeding maximum score (110/100)
     - Non-numeric value (e.g., "A+")

3. **Expected Result:**
   - The system should prevent saving negative grades
   - The system should prevent saving grades exceeding the maximum score
   - The system should prevent saving non-numeric grades
   - Clear error messages should be displayed for each case

### Test Case 2.2: Transaction Handling

1. **Setup:**
   - Log in as a Teacher
   - Navigate to an assessment's grade entry page with multiple students

2. **Test Steps:**
   - Enter valid grades for most students
   - Enter an invalid grade for one student (e.g., 110/100)
   - Try to save all grades at once

3. **Expected Result:**
   - The system should not save any grades (all-or-nothing behavior)
   - An error message should indicate which student's grade is invalid
   - All entered grades should remain in the form for correction

## 3. Test Data Generator Testing

### Test Case 3.1: Generate Test Assessments

1. **Setup:**
   - Log in as an Admin
   - Navigate to Test Data > Generate Test Data

2. **Test Steps:**
   - Set the number of assessments to 5
   - Check "Generate Grades"
   - Click "Generate Test Data"

3. **Expected Result:**
   - 5 new assessments should be created with realistic names and weights
   - Assessments should be distributed across subjects and terms
   - Grades should be generated for all students in the corresponding grades
   - A success message should be displayed

### Test Case 3.2: Verify Generated Data

1. **Setup:**
   - Log in as an Admin
   - Navigate to Grades > Assessments

2. **Test Steps:**
   - View the newly generated assessments
   - Check the grade distribution for one of the assessments

3. **Expected Result:**
   - Assessments should have valid weights (10-40%)
   - Grades should follow a bell curve distribution
   - Some grades should have remarks

## 4. Grade Report Page Testing

### Test Case 4.1: Filter Functionality

1. **Setup:**
   - Log in as an Admin
   - Navigate to Reports > Grade Reports

2. **Test Steps:**
   - Test the following filter combinations:
     - Filter by grade only (e.g., 10th)
     - Filter by subject only (e.g., Math)
     - Filter by term only (e.g., Spring 2023)
     - Filter by grade and subject
     - Filter by grade, subject, and term
     - Clear all filters

3. **Expected Result:**
   - The report should update correctly for each filter combination
   - Class statistics should be recalculated based on the filtered data
   - The grade distribution chart should update accordingly
   - The student grades table should show only relevant data

### Test Case 4.2: PDF Report Generation

1. **Setup:**
   - Log in as an Admin
   - Navigate to Reports > Grade Reports
   - Apply some filters (e.g., 10th grade, Math)

2. **Test Steps:**
   - Click "Download PDF"
   - Open the downloaded PDF

3. **Expected Result:**
   - The PDF should include school branding (logo, colors)
   - The PDF should include the applied filters
   - The PDF should include class statistics
   - The PDF should include the student grades table
   - The formatting should be professional and consistent

### Test Case 4.3: Mobile Responsiveness

1. **Setup:**
   - Log in as an Admin on a mobile device (or use browser developer tools to simulate)
   - Navigate to Reports > Grade Reports

2. **Test Steps:**
   - Check the layout of filters
   - Check the class statistics display
   - Check the grade distribution chart
   - Check the student grades table

3. **Expected Result:**
   - Filters should stack vertically on small screens
   - Class statistics should be displayed in a grid that adapts to screen size
   - The chart should be responsive and readable
   - The table should be scrollable horizontally if needed
   - All content should be accessible without horizontal scrolling of the page

## 5. Role-Based Access Testing

### Test Case 5.1: Admin Access

1. **Setup:**
   - Log in as an Admin

2. **Test Steps:**
   - Navigate to all grade management features
   - Try to create, edit, and delete assessments
   - Try to view and generate reports for all grades and subjects

3. **Expected Result:**
   - Admin should have full access to all features
   - Admin should be able to create, edit, and delete assessments
   - Admin should be able to view and generate reports for all grades and subjects

### Test Case 5.2: Teacher Access

1. **Setup:**
   - Log in as a Teacher

2. **Test Steps:**
   - Try to view assessments for your assigned subjects
   - Try to enter grades for your assigned classes
   - Try to view reports for your assigned classes
   - Try to view reports for classes you don't teach

3. **Expected Result:**
   - Teacher should be able to view assessments for assigned subjects
   - Teacher should be able to enter grades for assigned classes
   - Teacher should be able to view reports for

## 3. UI/UX Enhancements for Mobile

Let's implement some UI/UX improvements for the Grade Report page to make it more mobile-friendly:

```typescriptreact file="app/reports/grades/page.tsx"
[v0-no-op-code-block-prefix]"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"
import { getGradeReportData } from "@/app/actions/grade-actions"
import {
  calculateWeightedGrade,
  calculateLetterGrade,
  calculateClassStatistics,
} from "@/lib/validators/grade-calculator"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

export default function GradeReportPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [reportData, setReportData] = useState<any[]>([])
  const [filters, setFilters] = useState<{
    grades: any[]
    subjects: any[]
    terms: any[]
  }>({
    grades: [],
    subjects: [],
    terms: [],
  })
  const [selectedFilters, setSelectedFilters] = useState<{
    grade: string
    subjectId: string
    termId: string
  }>({
    grade: "",
    subjectId: "",
    termId: "",
  })
  const [processedData, setProcessedData] = useState<{
    studentGrades: any[]
    classStatistics: any
    gradeDistribution: any[]
  }>({
    studentGrades: [],
    classStatistics: { average: 0, highest: 0, lowest: 0, median: 0, passingRate: 0 },
    gradeDistribution: [],
  })

  useEffect(() => {
    fetchReportData()
  }, [])

  useEffect(() => {
    if (reportData.length > 0) {
      processReportData()
    }
  }, [reportData, selectedFilters])

  async function fetchReportData() {
    setIsLoading(true)
    try {
      const result = await getGradeReportData({
        grade: selectedFilters.grade || undefined,
        subjectId: selectedFilters.subjectId ? Number.parseInt(selectedFilters.subjectId) : undefined,
        termId: selectedFilters.termId ? Number.parseInt(selectedFilters.termId) : undefined,
      })

      if (result.success) {
        setReportData(result.data.reportData)
        setFilters(result.data.filters)
      } else {
        toast({
          title: "Error",
          description: result.message || "Failed to fetch grade report data",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error fetching grade report data:", error)
      toast({
        title: "Error",
        description: "An unexpected error occurred",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  function processReportData() {
    // Group data by student
    const studentMap = new Map()

    reportData.forEach((record) => {
      // Apply filters
      if (
        (selectedFilters.grade && record.student_grade !== selectedFilters.grade) ||
        (selectedFilters.subjectId && record.subject_id.toString() !== selectedFilters.subjectId) ||
        (selectedFilters.termId && record.term_id.toString() !== selectedFilters.termId)
      ) {
        return
      }

      const studentId = record.student_id
      if (!studentMap.has(studentId)) {
        studentMap.set(studentId, {
          id: studentId,
          name: record.student_name,
          grade: record.student_grade,
          subjects: new Map(),
        })
      }

      const student = studentMap.get(studentId)
      const subjectId = record.subject_id

      if (!student.subjects.has(subjectId)) {
        student.subjects.set(subjectId, {
          id: subjectId,
          name: record.subject_name,
          assessments: [],
          weightedGrade: 0,
          letterGrade: "",
        })
      }

      const subject = student.subjects.get(subjectId)
      subject.assessments.push({
        id: record.assessment_id,
        name: record.assessment_name,
        weight: Number.parseFloat(record.assessment_weight),
        score: Number.parseFloat(record.score),
        remarks: record.remarks,
      })
    })

    // Calculate weighted grades for each student and subject
    const studentGrades = []
    const allGrades = []

    studentMap.forEach((student) => {
      student.subjects.forEach((subject) => {
        // Calculate weighted grade
        const weightedGrade = calculateWeightedGrade(
          subject.assessments.map((a: any) => ({
            weight: a.weight,
            score: a.score,
          })),
        )

        subject.weightedGrade = weightedGrade
        subject.letterGrade = calculateLetterGrade(weightedGrade)
        allGrades.push(weightedGrade)
      })

      // Convert subjects map to array
      const subjectsArray = Array.from(student.subjects.values())

      // Calculate overall average across all subjects
      const overallAverage =
        subjectsArray.reduce((sum: number, subject: any) => sum + subject.weightedGrade, 0) / subjectsArray.length

      studentGrades.push({
        ...student,
        subjects: subjectsArray,
        overallAverage: Math.round(overallAverage * 100) / 100,
        overallLetterGrade: calculateLetterGrade(overallAverage),
      })
    })

    // Calculate class statistics
    const classStatistics = calculateClassStatistics(allGrades)

    // Calculate grade distribution
    const gradeDistribution = [
      { name: "A", count: 0 },
      { name: "B", count: 0 },
      { name: "C", count: 0 },
      { name: "D", count: 0 },
      { name: "F", count: 0 },
    ]

    allGrades.forEach((grade) => {
      const letterGrade = calculateLetterGrade(grade)
      const index = gradeDistribution.findIndex((item) => item.name === letterGrade)
      if (index !== -1) {
        gradeDistribution[index].count++
      }
    })

    setProcessedData({
      studentGrades,
      classStatistics,
      gradeDistribution,
    })
  }

  function handleFilterChange(filter: string, value: string) {
    setSelectedFilters((prev) => ({
      ...prev,
      [filter]: value === "all" ? "" : value,
    }))
  }

  function handleApplyFilters() {
    fetchReportData()
  }

  function handleDownloadPDF() {
    // Construct query parameters
    const params = new URLSearchParams()
    if (selectedFilters.grade) params.append("grade", selectedFilters.grade)
    if (selectedFilters.subjectId) params.append("subjectId", selectedFilters.subjectId)
    if (selectedFilters.termId) params.append("termId", selectedFilters.termId)

    // Open the PDF in a new tab
    window.open(`/api/reports/grades/pdf?${params.toString()}`, "_blank")
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h1 className="text-2xl sm:text-3xl font-bold">Grade Reports</h1>
        <Button onClick={handleDownloadPDF} disabled={isLoading || reportData.length === 0} className="w-full sm:w-auto">
          Download PDF
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Filters</CardTitle>
          <CardDescription>Filter the grade report by grade, subject, and academic term.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <div className="space-y-2">
              <label className="text-sm font-medium">Grade</label>
              <Select value={selectedFilters.grade} onValueChange={(value) => handleFilterChange("grade", value)}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="All Grades" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Grades</SelectItem>
                  {filters.grades.map((grade) => (
                    <SelectItem key={grade.grade} value={grade.grade}>
                      {grade.grade} Grade
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Subject</label>
              <Select
                value={selectedFilters.subjectId}
                onValueChange={(value) => handleFilterChange("subjectId", value)}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="All Subjects" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Subjects</SelectItem>
                  {filters.subjects.map((subject) => (
                    <SelectItem key={subject.id} value={subject.id.toString()}>
                      {subject.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 sm:col-span-2 lg:col-span-1">
              <label className="text-sm font-medium">Academic Term</label>
              <Select value={selectedFilters.termId} onValueChange={(value) => handleFilterChange("termId", value)}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="All Terms" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Terms</SelectItem>
                  {filters.terms.map((term) => (
                    <SelectItem key={term.id} value={term.id.toString()}>
                      {term.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="mt-4 flex justify-end">
            <Button onClick={handleApplyFilters} disabled={isLoading}>
              Apply Filters
            </Button>
          </div>
        </CardContent>
      </Card>

      {isLoading ? (
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-center items-center py-8">
              <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
              <span className="ml-3">Loading grade report data...</span>
            </div>
          </CardContent>
        </Card>
      ) : (
        <>
          {processedData.studentGrades.length === 0 ? (
            <Card>
              <CardContent className="p-6">
                <div className="flex justify-center">
                  <p>No grade data found for the selected filters.</p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <>
              <Card>
                <CardHeader>
                  <CardTitle>Class Performance</CardTitle>
                  <CardDescription>Overall statistics for the selected class.</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-5 md:gap-4">
                    <div className="rounded-lg border p-2 text-center md:p-3">
                      <p className="text-xs font-medium text-muted-foreground md:text-sm">Class Average</p>
                      <p className="text-lg font-bold md:text-2xl">{processedData.classStatistics.average}%</p>
                    </div>
                    <div className="rounded-lg border p-2 text-center md:p-3">
                      <p className="text-xs font-medium text-muted-foreground md:text-sm">Highest Grade</p>
                      <p className="text-lg font-bold md:text-2xl">{processedData.classStatistics.highest}%</p>
                    </div>
                    <div className="rounded-lg border p-2 text-center md:p-3">
                      <p className="text-xs font-medium text-muted-foreground md:text-sm">Lowest Grade</p>
                      <p className="text-lg font-bold md:text-2xl">{processedData.classStatistics.lowest}%</p>
                    </div>
                    <div className="rounded-lg border p-2 text-center md:p-3">
                      <p className="text-xs font-medium text-muted-foreground md:text-sm">Median Grade</p>
                      <p className="text-lg font-bold md:text-2xl">{processedData.classStatistics.median}%</p>
                    </div>
                    <div className="rounded-lg border p-2 text-center md:p-3 sm:col-span-3 md:col-span-1">
                      <p className="text-xs font-medium text-muted-foreground md:text-sm">Passing Rate</p>
                      <p className="text-lg font-bold md:text-2xl">{processedData.classStatistics.passingRate}%</p>
                    </div>
                  </div>

                  <div className="mt-6">
                    <h3 className="mb-4 text-lg font-medium">Grade Distribution</h3>
                    <div className="h-48 md:h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={processedData.gradeDistribution}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Bar dataKey="count" name="Number of Students" fill="#4f46e5" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Student Grades</CardTitle>
                  <CardDescription>Individual student performance.</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto -mx-4 sm:mx-0">
                    <div className="inline-block min-w-full align-middle px-4 sm:px-0">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Student</TableHead>
                            <TableHead>Grade</TableHead>
                            {selectedFilters.subjectId ? (
                              <>
                                <TableHead>Score</TableHead>
                                <TableHead>Letter Grade</TableHead>
                              </>
                            ) : (
                              <>
                                <TableHead>Overall Average</TableHead>
                                <TableHead>Overall Grade</TableHead>
                                <TableHead className="hidden md:table-cell">Subjects</TableHead>
                              </>
                            )}
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {processedData.studentGrades.map((student) => (
                            <TableRow key={student.id}>
                              <TableCell className="font-medium">{student.name}</TableCell>
                              <TableCell>{student.grade}</TableCell>
                              {selectedFilters.subjectId ? (
                                <>
                                  <TableCell>{student.subjects[0]?.weightedGrade.toFixed(2)}%</TableCell>
                                  <TableCell>{student.subjects[0]?.letterGrade}</TableCell>
                                </>
                              ) : (
                                <>
                                  <TableCell>{student.overallAverage.toFixed(2)}%</TableCell>
                                  <TableCell>{student.overallLetterGrade}</TableCell>
                                  <TableCell className="hidden md:table-cell">
                                    <div className="flex flex-wrap gap-1">
                                      {student.subjects.map((subject: any) => (
                                        <div
                                          key={subject.id}
                                          className="rounded-md bg-muted px-1.5 py-0.5 text-xs"
                                          title={`${subject.name}: ${subject.weightedGrade.toFixed(2)}% (${subject.letterGrade})`}
                                        >
                                          {subject.name}: {subject.letterGrade}
                                        </div>
                                      ))}
                                    </div>
                                  </TableCell>
                                </>
                              )}
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </>
      )}
    </div>
  )
}
