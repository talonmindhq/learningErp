// Basic test to verify Jest is working
describe("Basic Test", () => {
  it("should pass", () => {
    expect(true).toBe(true)
  })
})
