import Link from "next/link"
import { PlusCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { FeesTable } from "@/components/fees-table"

export default function FeesPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Fees Management</h1>
        <Button asChild>
          <Link href="/fees/new">
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Fee Record
          </Link>
        </Button>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Fee Records</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <Input placeholder="Search fee records..." className="max-w-sm" />
              <Button variant="outline">Search</Button>
            </div>
            <FeesTable />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
