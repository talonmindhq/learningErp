"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { toast } from "@/components/ui/use-toast"

export default function TestDataPage() {
  const [isGenerating, setIsGenerating] = useState(false)
  const [assessmentCount, setAssessmentCount] = useState(5)
  const [generateGrades, setGenerateGrades] = useState(true)

  async function handleGenerateTestData() {
    setIsGenerating(true)

    try {
      const response = await fetch("/api/test-data/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          assessmentCount,
          generateGrades,
        }),
      })

      const data = await response.json()

      if (response.ok) {
        toast({
          title: "Success",
          description: data.message,
        })
      } else {
        toast({
          title: "Error",
          description: data.error || "Failed to generate test data",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error generating test data:", error)
      toast({
        title: "Error",
        description: "An unexpected error occurred",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Generate Test Data</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Test Data Generator</CardTitle>
          <CardDescription>
            Generate test data for assessments and grades to help with testing and development.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="assessmentCount">Number of Assessments</Label>
                <Input
                  id="assessmentCount"
                  type="number"
                  min="1"
                  max="20"
                  value={assessmentCount}
                  onChange={(e) => setAssessmentCount(Number.parseInt(e.target.value))}
                />
                <p className="text-sm text-muted-foreground">The number of random assessments to generate.</p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="generateGrades">Generate Grades</Label>
                <div className="flex items-center space-x-2">
                  <Switch id="generateGrades" checked={generateGrades} onCheckedChange={setGenerateGrades} />
                  <span>{generateGrades ? "Yes" : "No"}</span>
                </div>
                <p className="text-sm text-muted-foreground">Whether to generate random grades for each assessment.</p>
              </div>
            </div>

            <div className="flex justify-end">
              <Button onClick={handleGenerateTestData} disabled={isGenerating}>
                {isGenerating ? "Generating..." : "Generate Test Data"}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Important Notes</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="list-disc space-y-2 pl-6">
            <li>This tool is intended for testing and development purposes only.</li>
            <li>Generated data will be random but realistic, with grades following a bell curve distribution.</li>
            <li>
              The tool will create assessments for various subjects, grades, and terms that exist in your database.
            </li>
            <li>
              If you choose to generate grades, the system will create grades for all active students in the
              corresponding grade.
            </li>
            <li>You can use this data to test the grade management and reporting features.</li>
            <li>
              <strong>Warning:</strong> This action cannot be undone. Generated data will be permanently added to the
              database.
            </li>
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}
