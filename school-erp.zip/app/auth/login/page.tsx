"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Mail, Lock, Users, School } from "lucide-react"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [role, setRole] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    try {
      // Create FormData object as requested
      const formData = new FormData()
      formData.append("email", email)
      formData.append("password", password)
      formData.append("role", role)

      console.log("🚀 Submitting login with:", { email, role })

      // Submit to your existing API endpoint
      const response = await fetch("/api/auth/login", {
        method: "POST",
        body: formData,
      })

      console.log("📡 Response status:", response.status)

      // Get the response data regardless of status
      const data = await response.json()
      console.log("📥 API Response:", data)

      if (response.ok && data.success) {
        console.log("✅ Login successful!")

        // Store user info if provided by your backend
        if (data.user) {
          localStorage.setItem("user", JSON.stringify(data.user))

          // Also set a cookie for the middleware
          document.cookie = `auth-user=${JSON.stringify(data.user)}; path=/; max-age=86400`
        }

        // Force redirect using window.location instead of router.push
        console.log("🔄 Redirecting to dashboard...")
        window.location.href = "/"
      } else {
        // Show detailed error message from your backend
        const errorMessage = data.message || `Login failed (${response.status})`
        setError(errorMessage)
        console.log("❌ Login failed:", errorMessage)
      }
    } catch (err) {
      console.error("🔥 Login error:", err)
      setError("Unable to connect to the server. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  // Quick fill functions for testing
  const fillTestUser = () => {
    setEmail("test@example.com")
    setPassword("simple_password")
    setRole("Admin")
  }

  const fillAdminUser = () => {
    setEmail("admin@school.com")
    setPassword("simple_password")
    setRole("Admin")
  }

  const fillTeacherUser = () => {
    setEmail("teacher1@school.com")
    setPassword("simple_password")
    setRole("Teacher")
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <School className="h-12 w-12 text-blue-600" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900">School 360</h1>
          <p className="text-gray-600 mt-2">Sign in to your account</p>
        </div>

        {/* Login Card */}
        <Card className="shadow-lg">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl font-semibold text-center">Welcome back</CardTitle>
            <CardDescription className="text-center">Enter your credentials to access your account</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Email Field */}
              <div className="space-y-2">
                <Label htmlFor="email" className="text-sm font-medium">
                  Email
                </Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10"
                    required
                    disabled={isLoading}
                  />
                </div>
              </div>

              {/* Password Field */}
              <div className="space-y-2">
                <Label htmlFor="password" className="text-sm font-medium">
                  Password
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="password"
                    type="password"
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10"
                    required
                    disabled={isLoading}
                  />
                </div>
              </div>

              {/* Role Field */}
              <div className="space-y-2">
                <Label htmlFor="role" className="text-sm font-medium">
                  Role
                </Label>
                <div className="relative">
                  <Users className="absolute left-3 top-3 h-4 w-4 text-gray-400 z-10" />
                  <Select value={role} onValueChange={setRole} disabled={isLoading} required>
                    <SelectTrigger className="pl-10">
                      <SelectValue placeholder="Select your role" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Admin">Admin</SelectItem>
                      <SelectItem value="Teacher">Teacher</SelectItem>
                      <SelectItem value="Student">Student</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Error Message */}
              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              {/* Submit Button */}
              <Button type="submit" className="w-full" disabled={isLoading || !email || !password || !role}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Signing in...
                  </>
                ) : (
                  "Sign In"
                )}
              </Button>
            </form>

            {/* Footer */}
            <div className="mt-6 text-center">
              <p className="text-sm text-gray-600">
                Need help?{" "}
                <a href="#" className="text-blue-600 hover:text-blue-500 font-medium">
                  Contact support
                </a>
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Available Users for Testing */}
        <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
          <h3 className="text-sm font-medium text-blue-800 mb-3">Available Test Users:</h3>
          <div className="space-y-2">
            <Button
              variant="outline"
              size="sm"
              onClick={fillTestUser}
              disabled={isLoading}
              className="w-full text-xs justify-start"
            >
              test@example.com (Admin)
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={fillAdminUser}
              disabled={isLoading}
              className="w-full text-xs justify-start"
            >
              admin@school.com (Admin)
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={fillTeacherUser}
              disabled={isLoading}
              className="w-full text-xs justify-start"
            >
              teacher1@school.com (Teacher)
            </Button>
          </div>
          <p className="text-xs text-blue-600 mt-2">
            All users use password: <code className="bg-blue-100 px-1 rounded">simple_password</code>
          </p>
        </div>
      </div>
    </div>
  )
}
