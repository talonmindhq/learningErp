"use client"

import { useState } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Search, Download, Calendar, ArrowLeft, ArrowRight, CheckCircle2, XCircle, AlertCircle } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

export default function AttendancePage() {
  const [selectedClass, setSelectedClass] = useState("Grade 1-A")
  const [selectedMonth, setSelectedMonth] = useState("May 2024")
  const [searchQuery, setSearchQuery] = useState("")

  // Sample classes
  const classes = ["Grade 1-A", "Grade 1-B", "Grade 2-A", "Grade 8-C", "Grade 10-A", "Grade 12-B"]

  // Sample months
  const months = ["January 2024", "February 2024", "March 2024", "April 2024", "May 2024", "June 2024"]

  // Sample students
  const students = [
    {
      id: 1,
      name: "John Doe",
      rollNo: "G1A001",
      present: 18,
      absent: 2,
      late: 1,
      percentage: "90%",
      daily: [
        { date: "2024-05-01", status: "present" },
        { date: "2024-05-02", status: "present" },
        { date: "2024-05-03", status: "present" },
        { date: "2024-05-06", status: "present" },
        { date: "2024-05-07", status: "absent" },
        { date: "2024-05-08", status: "present" },
        { date: "2024-05-09", status: "present" },
        { date: "2024-05-10", status: "present" },
        { date: "2024-05-13", status: "present" },
        { date: "2024-05-14", status: "present" },
        { date: "2024-05-15", status: "present" },
        { date: "2024-05-16", status: "present" },
        { date: "2024-05-17", status: "present" },
        { date: "2024-05-20", status: "present" },
        { date: "2024-05-21", status: "late" },
        { date: "2024-05-22", status: "present" },
        { date: "2024-05-23", status: "present" },
        { date: "2024-05-24", status: "present" },
        { date: "2024-05-27", status: "present" },
        { date: "2024-05-28", status: "present" },
        { date: "2024-05-29", status: "absent" },
      ],
    },
    {
      id: 2,
      name: "Jane Smith",
      rollNo: "G1A002",
      present: 21,
      absent: 0,
      late: 0,
      percentage: "100%",
      daily: [
        { date: "2024-05-01", status: "present" },
        { date: "2024-05-02", status: "present" },
        { date: "2024-05-03", status: "present" },
        { date: "2024-05-06", status: "present" },
        { date: "2024-05-07", status: "present" },
        { date: "2024-05-08", status: "present" },
        { date: "2024-05-09", status: "present" },
        { date: "2024-05-10", status: "present" },
        { date: "2024-05-13", status: "present" },
        { date: "2024-05-14", status: "present" },
        { date: "2024-05-15", status: "present" },
        { date: "2024-05-16", status: "present" },
        { date: "2024-05-17", status: "present" },
        { date: "2024-05-20", status: "present" },
        { date: "2024-05-21", status: "present" },
        { date: "2024-05-22", status: "present" },
        { date: "2024-05-23", status: "present" },
        { date: "2024-05-24", status: "present" },
        { date: "2024-05-27", status: "present" },
        { date: "2024-05-28", status: "present" },
        { date: "2024-05-29", status: "present" },
      ],
    },
    {
      id: 3,
      name: "Michael Johnson",
      rollNo: "G1A003",
      present: 16,
      absent: 3,
      late: 2,
      percentage: "85%",
      daily: [
        { date: "2024-05-01", status: "present" },
        { date: "2024-05-02", status: "present" },
        { date: "2024-05-03", status: "late" },
        { date: "2024-05-06", status: "present" },
        { date: "2024-05-07", status: "present" },
        { date: "2024-05-08", status: "absent" },
        { date: "2024-05-09", status: "present" },
        { date: "2024-05-10", status: "present" },
        { date: "2024-05-13", status: "present" },
        { date: "2024-05-14", status: "present" },
        { date: "2024-05-15", status: "present" },
        { date: "2024-05-16", status: "absent" },
        { date: "2024-05-17", status: "present" },
        { date: "2024-05-20", status: "present" },
        { date: "2024-05-21", status: "late" },
        { date: "2024-05-22", status: "present" },
        { date: "2024-05-23", status: "present" },
        { date: "2024-05-24", status: "present" },
        { date: "2024-05-27", status: "present" },
        { date: "2024-05-28", status: "absent" },
        { date: "2024-05-29", status: "present" },
      ],
    },
    {
      id: 4,
      name: "Emily Davis",
      rollNo: "G1A004",
      present: 19,
      absent: 1,
      late: 1,
      percentage: "95%",
      daily: [
        { date: "2024-05-01", status: "present" },
        { date: "2024-05-02", status: "present" },
        { date: "2024-05-03", status: "present" },
        { date: "2024-05-06", status: "present" },
        { date: "2024-05-07", status: "present" },
        { date: "2024-05-08", status: "present" },
        { date: "2024-05-09", status: "present" },
        { date: "2024-05-10", status: "present" },
        { date: "2024-05-13", status: "present" },
        { date: "2024-05-14", status: "late" },
        { date: "2024-05-15", status: "present" },
        { date: "2024-05-16", status: "present" },
        { date: "2024-05-17", status: "present" },
        { date: "2024-05-20", status: "present" },
        { date: "2024-05-21", status: "present" },
        { date: "2024-05-22", status: "present" },
        { date: "2024-05-23", status: "present" },
        { date: "2024-05-24", status: "present" },
        { date: "2024-05-27", status: "present" },
        { date: "2024-05-28", status: "absent" },
        { date: "2024-05-29", status: "present" },
      ],
    },
    {
      id: 5,
      name: "David Wilson",
      rollNo: "G1A005",
      present: 17,
      absent: 2,
      late: 2,
      percentage: "85%",
      daily: [
        { date: "2024-05-01", status: "present" },
        { date: "2024-05-02", status: "present" },
        { date: "2024-05-03", status: "present" },
        { date: "2024-05-06", status: "late" },
        { date: "2024-05-07", status: "present" },
        { date: "2024-05-08", status: "present" },
        { date: "2024-05-09", status: "present" },
        { date: "2024-05-10", status: "present" },
        { date: "2024-05-13", status: "absent" },
        { date: "2024-05-14", status: "present" },
        { date: "2024-05-15", status: "present" },
        { date: "2024-05-16", status: "present" },
        { date: "2024-05-17", status: "present" },
        { date: "2024-05-20", status: "present" },
        { date: "2024-05-21", status: "late" },
        { date: "2024-05-22", status: "present" },
        { date: "2024-05-23", status: "present" },
        { date: "2024-05-24", status: "present" },
        { date: "2024-05-27", status: "present" },
        { date: "2024-05-28", status: "absent" },
        { date: "2024-05-29", status: "present" },
      ],
    },
  ]

  // Get all dates for the selected month
  const getDatesForMonth = () => {
    const dates = []
    students.forEach((student) => {
      student.daily.forEach((day) => {
        if (!dates.includes(day.date)) {
          dates.push(day.date)
        }
      })
    })
    return dates.sort()
  }

  const dates = getDatesForMonth()

  const filteredStudents = students.filter(
    (student) =>
      student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.rollNo.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handlePreviousMonth = () => {
    const currentIndex = months.indexOf(selectedMonth)
    if (currentIndex > 0) {
      setSelectedMonth(months[currentIndex - 1])
    }
  }

  const handleNextMonth = () => {
    const currentIndex = months.indexOf(selectedMonth)
    if (currentIndex < months.length - 1) {
      setSelectedMonth(months[currentIndex + 1])
    }
  }

  return (
    <PageTemplate
      title="Attendance"
      description="Track and manage student attendance records."
      breadcrumbs={[
        { title: "Academic Portfolio", href: "#" },
        { title: "Attendance", href: "/dashboard/attendance", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Take Attendance",
        icon: <Calendar className="h-4 w-4 mr-2" />,
        href: "/dashboard/attendance/take",
      }}
    >
      <div className="grid gap-4">
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle>Attendance Register</CardTitle>
              <div className="flex items-center gap-2">
                <Select value={selectedClass} onValueChange={setSelectedClass}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Select class" />
                  </SelectTrigger>
                  <SelectContent>
                    {classes.map((cls) => (
                      <SelectItem key={cls} value={cls}>
                        {cls}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="icon" onClick={handlePreviousMonth}>
                    <ArrowLeft className="h-4 w-4" />
                  </Button>
                  <span className="text-sm font-medium">{selectedMonth}</span>
                  <Button variant="outline" size="icon" onClick={handleNextMonth}>
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </div>
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Search students..."
                    className="w-64 pl-8"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline">
                      <Download className="h-4 w-4 mr-2" />
                      Export
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    <DropdownMenuItem>Export as PDF</DropdownMenuItem>
                    <DropdownMenuItem>Export as Excel</DropdownMenuItem>
                    <DropdownMenuItem>Print Attendance</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="summary" className="w-full">
              <TabsList className="grid w-[300px] grid-cols-2 mb-4">
                <TabsTrigger value="summary">Summary View</TabsTrigger>
                <TabsTrigger value="daily">Daily View</TabsTrigger>
              </TabsList>

              <TabsContent value="summary">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[100px]">Roll No</TableHead>
                      <TableHead>Student Name</TableHead>
                      <TableHead>Present</TableHead>
                      <TableHead>Absent</TableHead>
                      <TableHead>Late</TableHead>
                      <TableHead>Percentage</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredStudents.map((student) => (
                      <TableRow key={student.id}>
                        <TableCell className="font-medium">{student.rollNo}</TableCell>
                        <TableCell>{student.name}</TableCell>
                        <TableCell>{student.present}</TableCell>
                        <TableCell>{student.absent}</TableCell>
                        <TableCell>{student.late}</TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className={
                              Number.parseInt(student.percentage) >= 90
                                ? "bg-green-50 text-green-700 hover:bg-green-50"
                                : Number.parseInt(student.percentage) >= 80
                                  ? "bg-blue-50 text-blue-700 hover:bg-blue-50"
                                  : "bg-red-50 text-red-700 hover:bg-red-50"
                            }
                          >
                            {student.percentage}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TabsContent>

              <TabsContent value="daily">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[100px]">Roll No</TableHead>
                        <TableHead className="w-[200px]">Student Name</TableHead>
                        {dates.map((date) => {
                          const d = new Date(date)
                          return (
                            <TableHead key={date} className="text-center w-[60px]">
                              {d.getDate()}
                            </TableHead>
                          )
                        })}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredStudents.map((student) => (
                        <TableRow key={student.id}>
                          <TableCell className="font-medium">{student.rollNo}</TableCell>
                          <TableCell>{student.name}</TableCell>
                          {dates.map((date) => {
                            const attendance = student.daily.find((day) => day.date === date)
                            return (
                              <TableCell key={date} className="text-center p-2">
                                {attendance ? (
                                  attendance.status === "present" ? (
                                    <CheckCircle2 className="h-5 w-5 text-green-500 mx-auto" />
                                  ) : attendance.status === "absent" ? (
                                    <XCircle className="h-5 w-5 text-red-500 mx-auto" />
                                  ) : (
                                    <AlertCircle className="h-5 w-5 text-amber-500 mx-auto" />
                                  )
                                ) : (
                                  <span className="text-gray-300">-</span>
                                )}
                              </TableCell>
                            )
                          })}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                <div className="flex items-center gap-4 mt-4 text-sm">
                  <div className="flex items-center gap-1">
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                    <span>Present</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <XCircle className="h-4 w-4 text-red-500" />
                    <span>Absent</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <AlertCircle className="h-4 w-4 text-amber-500" />
                    <span>Late</span>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </PageTemplate>
  )
}
