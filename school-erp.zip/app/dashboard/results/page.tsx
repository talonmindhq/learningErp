"use client"

import { useState } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { MoreHorizontal, Search, Plus, Edit, Download, Printer, Eye, Mail } from "lucide-react"

export default function ResultsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedExam, setSelectedExam] = useState("1")
  const [selectedClass, setSelectedClass] = useState("Grade 1-A")
  const [selectedStudent, setSelectedStudent] = useState(null)
  const [isPreviewOpen, setIsPreviewOpen] = useState(false)

  // Sample data for exams
  const exams = [
    { id: "1", name: "First Term Examination" },
    { id: "2", name: "Mid-Term Assessment" },
    { id: "3", name: "Final Examination" },
    { id: "4", name: "Monthly Test - April" },
  ]

  // Sample data for classes
  const classes = ["Grade 1-A", "Grade 1-B", "Grade 2-A", "Grade 8-C", "Grade 10-A", "Grade 12-B"]

  // Sample data for students
  const students = [
    {
      id: 1,
      name: "John Doe",
      rollNo: "G1A001",
      totalMarks: 450,
      percentage: 90,
      grade: "A+",
      rank: 1,
      status: "Pass",
      subjects: [
        { name: "Mathematics", marks: 95, grade: "A+", remarks: "Excellent" },
        { name: "English", marks: 88, grade: "A", remarks: "Very Good" },
        { name: "Science", marks: 92, grade: "A+", remarks: "Excellent" },
        { name: "Social Studies", marks: 85, grade: "A", remarks: "Very Good" },
        { name: "Art", marks: 90, grade: "A+", remarks: "Excellent" },
      ],
    },
    {
      id: 2,
      name: "Jane Smith",
      rollNo: "G1A002",
      totalMarks: 430,
      percentage: 86,
      grade: "A",
      rank: 2,
      status: "Pass",
      subjects: [
        { name: "Mathematics", marks: 90, grade: "A+", remarks: "Excellent" },
        { name: "English", marks: 92, grade: "A+", remarks: "Excellent" },
        { name: "Science", marks: 85, grade: "A", remarks: "Very Good" },
        { name: "Social Studies", marks: 80, grade: "A-", remarks: "Good" },
        { name: "Art", marks: 83, grade: "A-", remarks: "Good" },
      ],
    },
    {
      id: 3,
      name: "Michael Johnson",
      rollNo: "G1A003",
      totalMarks: 380,
      percentage: 76,
      grade: "B+",
      rank: 4,
      status: "Pass",
      subjects: [
        { name: "Mathematics", marks: 75, grade: "B+", remarks: "Good" },
        { name: "English", marks: 80, grade: "A-", remarks: "Good" },
        { name: "Science", marks: 78, grade: "B+", remarks: "Good" },
        { name: "Social Studies", marks: 72, grade: "B", remarks: "Satisfactory" },
        { name: "Art", marks: 75, grade: "B+", remarks: "Good" },
      ],
    },
    {
      id: 4,
      name: "Emily Davis",
      rollNo: "G1A004",
      totalMarks: 425,
      percentage: 85,
      grade: "A",
      rank: 3,
      status: "Pass",
      subjects: [
        { name: "Mathematics", marks: 88, grade: "A", remarks: "Very Good" },
        { name: "English", marks: 90, grade: "A+", remarks: "Excellent" },
        { name: "Science", marks: 85, grade: "A", remarks: "Very Good" },
        { name: "Social Studies", marks: 82, grade: "A-", remarks: "Good" },
        { name: "Art", marks: 80, grade: "A-", remarks: "Good" },
      ],
    },
    {
      id: 5,
      name: "David Wilson",
      rollNo: "G1A005",
      totalMarks: 320,
      percentage: 64,
      grade: "C+",
      rank: 5,
      status: "Pass",
      subjects: [
        { name: "Mathematics", marks: 65, grade: "C+", remarks: "Average" },
        { name: "English", marks: 70, grade: "B-", remarks: "Satisfactory" },
        { name: "Science", marks: 68, grade: "C+", remarks: "Average" },
        { name: "Social Studies", marks: 62, grade: "C", remarks: "Average" },
        { name: "Art", marks: 55, grade: "D+", remarks: "Needs Improvement" },
      ],
    },
  ]

  const filteredStudents = students.filter(
    (student) =>
      student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.rollNo.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handlePreview = (student) => {
    setSelectedStudent(student)
    setIsPreviewOpen(true)
  }

  return (
    <PageTemplate
      title="Examination Results"
      description="View and manage student examination results and performance."
      breadcrumbs={[
        { title: "Examination", href: "#" },
        { title: "Results", href: "/dashboard/results", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Enter Results",
        icon: <Plus className="h-4 w-4 mr-2" />,
        href: "/dashboard/results/enter",
      }}
    >
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle>Examination Results</CardTitle>
            <div className="flex items-center gap-2">
              <Select value={selectedExam} onValueChange={setSelectedExam}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="Select exam" />
                </SelectTrigger>
                <SelectContent>
                  {exams.map((exam) => (
                    <SelectItem key={exam.id} value={exam.id}>
                      {exam.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={selectedClass} onValueChange={setSelectedClass}>
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="Select class" />
                </SelectTrigger>
                <SelectContent>
                  {classes.map((cls) => (
                    <SelectItem key={cls} value={cls}>
                      {cls}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search students..."
                  className="w-64 pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Export
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem>Export as PDF</DropdownMenuItem>
                  <DropdownMenuItem>Export as Excel</DropdownMenuItem>
                  <DropdownMenuItem>Print Results</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[100px]">Roll No</TableHead>
                <TableHead>Student Name</TableHead>
                <TableHead>Total Marks</TableHead>
                <TableHead>Percentage</TableHead>
                <TableHead>Grade</TableHead>
                <TableHead>Rank</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredStudents.map((student) => (
                <TableRow key={student.id}>
                  <TableCell className="font-medium">{student.rollNo}</TableCell>
                  <TableCell>{student.name}</TableCell>
                  <TableCell>{student.totalMarks}/500</TableCell>
                  <TableCell>{student.percentage}%</TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={
                        student.grade === "A+" || student.grade === "A"
                          ? "bg-green-50 text-green-700 hover:bg-green-50"
                          : student.grade === "A-" || student.grade === "B+"
                            ? "bg-blue-50 text-blue-700 hover:bg-blue-50"
                            : student.grade === "B" || student.grade === "B-"
                              ? "bg-purple-50 text-purple-700 hover:bg-purple-50"
                              : "bg-amber-50 text-amber-700 hover:bg-amber-50"
                      }
                    >
                      {student.grade}
                    </Badge>
                  </TableCell>
                  <TableCell>{student.rank}</TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={
                        student.status === "Pass"
                          ? "bg-green-50 text-green-700 hover:bg-green-50"
                          : "bg-red-50 text-red-700 hover:bg-red-50"
                      }
                    >
                      {student.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <span className="sr-only">Open menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuItem onClick={() => handlePreview(student)}>
                          <Eye className="mr-2 h-4 w-4" />
                          <span>View Result</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Printer className="mr-2 h-4 w-4" />
                          <span>Print Result</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Download className="mr-2 h-4 w-4" />
                          <span>Download PDF</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Mail className="mr-2 h-4 w-4" />
                          <span>Email to Parent</span>
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem>
                          <Edit className="mr-2 h-4 w-4" />
                          <span>Edit Result</span>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Result Preview Dialog */}
      <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Result Card: {selectedStudent?.name}</DialogTitle>
            <DialogDescription>
              Detailed examination results for {exams.find((exam) => exam.id === selectedExam)?.name}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Student Name</p>
                <p>{selectedStudent?.name}</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Roll Number</p>
                <p>{selectedStudent?.rollNo}</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Class</p>
                <p>{selectedClass}</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Examination</p>
                <p>{exams.find((exam) => exam.id === selectedExam)?.name}</p>
              </div>
            </div>

            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Subject</TableHead>
                  <TableHead>Marks</TableHead>
                  <TableHead>Grade</TableHead>
                  <TableHead>Remarks</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {selectedStudent?.subjects.map((subject, index) => (
                  <TableRow key={index}>
                    <TableCell>{subject.name}</TableCell>
                    <TableCell>{subject.marks}/100</TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={
                          subject.grade === "A+" || subject.grade === "A"
                            ? "bg-green-50 text-green-700 hover:bg-green-50"
                            : subject.grade === "A-" || subject.grade === "B+"
                              ? "bg-blue-50 text-blue-700 hover:bg-blue-50"
                              : subject.grade === "B" || subject.grade === "B-"
                                ? "bg-purple-50 text-purple-700 hover:bg-purple-50"
                                : subject.grade === "C+" || subject.grade === "C"
                                  ? "bg-amber-50 text-amber-700 hover:bg-amber-50"
                                  : "bg-red-50 text-red-700 hover:bg-red-50"
                        }
                      >
                        {subject.grade}
                      </Badge>
                    </TableCell>
                    <TableCell>{subject.remarks}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>

            <div className="grid grid-cols-3 gap-4 pt-4 border-t">
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Total Marks</p>
                <p className="font-medium">{selectedStudent?.totalMarks}/500</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Percentage</p>
                <p className="font-medium">{selectedStudent?.percentage}%</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Grade</p>
                <Badge
                  variant="outline"
                  className={
                    selectedStudent?.grade === "A+" || selectedStudent?.grade === "A"
                      ? "bg-green-50 text-green-700 hover:bg-green-50"
                      : selectedStudent?.grade === "A-" || selectedStudent?.grade === "B+"
                        ? "bg-blue-50 text-blue-700 hover:bg-blue-50"
                        : selectedStudent?.grade === "B" || selectedStudent?.grade === "B-"
                          ? "bg-purple-50 text-purple-700 hover:bg-purple-50"
                          : "bg-amber-50 text-amber-700 hover:bg-amber-50"
                  }
                >
                  {selectedStudent?.grade}
                </Badge>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Rank</p>
                <p className="font-medium">{selectedStudent?.rank}</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Status</p>
                <Badge
                  variant="outline"
                  className={
                    selectedStudent?.status === "Pass"
                      ? "bg-green-50 text-green-700 hover:bg-green-50"
                      : "bg-red-50 text-red-700 hover:bg-red-50"
                  }
                >
                  {selectedStudent?.status}
                </Badge>
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <Button variant="outline">
                <Printer className="h-4 w-4 mr-2" />
                Print
              </Button>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Download
              </Button>
              <Button>
                <Mail className="h-4 w-4 mr-2" />
                Email to Parent
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </PageTemplate>
  )
}
