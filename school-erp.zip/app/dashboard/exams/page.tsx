"use client"

import { useState } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { MoreHorizontal, Search, Plus, Edit, Trash2, FileText, Calendar, ClipboardList, Eye } from "lucide-react"
import { Progress } from "@/components/ui/progress"

export default function ExamsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedExam, setSelectedExam] = useState(null)
  const [isPreviewOpen, setIsPreviewOpen] = useState(false)

  // Sample data for exams
  const exams = [
    {
      id: 1,
      name: "First Term Examination",
      type: "Term",
      startDate: "2024-05-15",
      endDate: "2024-05-25",
      classes: ["Grade 1-A", "Grade 1-B", "Grade 2-A", "Grade 8-C", "Grade 10-A", "Grade 12-B"],
      status: "Ongoing",
      progress: 60,
      subjects: [
        { name: "Mathematics", date: "2024-05-15", time: "9:00 AM - 11:00 AM", status: "Completed" },
        { name: "English", date: "2024-05-17", time: "9:00 AM - 11:00 AM", status: "Completed" },
        { name: "Science", date: "2024-05-20", time: "9:00 AM - 11:00 AM", status: "Completed" },
        { name: "Social Studies", date: "2024-05-22", time: "9:00 AM - 11:00 AM", status: "Scheduled" },
        { name: "Art", date: "2024-05-24", time: "9:00 AM - 11:00 AM", status: "Scheduled" },
      ],
    },
    {
      id: 2,
      name: "Mid-Term Assessment",
      type: "Assessment",
      startDate: "2024-03-10",
      endDate: "2024-03-15",
      classes: ["Grade 1-A", "Grade 1-B", "Grade 2-A"],
      status: "Completed",
      progress: 100,
      subjects: [
        { name: "Mathematics", date: "2024-03-10", time: "9:00 AM - 10:30 AM", status: "Completed" },
        { name: "English", date: "2024-03-12", time: "9:00 AM - 10:30 AM", status: "Completed" },
        { name: "Science", date: "2024-03-15", time: "9:00 AM - 10:30 AM", status: "Completed" },
      ],
    },
    {
      id: 3,
      name: "Final Examination",
      type: "Final",
      startDate: "2024-07-10",
      endDate: "2024-07-20",
      classes: ["Grade 1-A", "Grade 1-B", "Grade 2-A", "Grade 8-C", "Grade 10-A", "Grade 12-B"],
      status: "Scheduled",
      progress: 0,
      subjects: [
        { name: "Mathematics", date: "2024-07-10", time: "9:00 AM - 11:00 AM", status: "Scheduled" },
        { name: "English", date: "2024-07-12", time: "9:00 AM - 11:00 AM", status: "Scheduled" },
        { name: "Science", date: "2024-07-15", time: "9:00 AM - 11:00 AM", status: "Scheduled" },
        { name: "Social Studies", date: "2024-07-17", time: "9:00 AM - 11:00 AM", status: "Scheduled" },
        { name: "Art", date: "2024-07-19", time: "9:00 AM - 11:00 AM", status: "Scheduled" },
      ],
    },
    {
      id: 4,
      name: "Monthly Test - April",
      type: "Monthly",
      startDate: "2024-04-25",
      endDate: "2024-04-28",
      classes: ["Grade 10-A", "Grade 12-B"],
      status: "Completed",
      progress: 100,
      subjects: [
        { name: "Physics", date: "2024-04-25", time: "9:00 AM - 10:30 AM", status: "Completed" },
        { name: "Chemistry", date: "2024-04-26", time: "9:00 AM - 10:30 AM", status: "Completed" },
        { name: "Biology", date: "2024-04-27", time: "9:00 AM - 10:30 AM", status: "Completed" },
        { name: "Mathematics", date: "2024-04-28", time: "9:00 AM - 10:30 AM", status: "Completed" },
      ],
    },
  ]

  const filteredExams = exams.filter(
    (exam) =>
      exam.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      exam.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
      exam.status.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handlePreview = (exam) => {
    setSelectedExam(exam)
    setIsPreviewOpen(true)
  }

  const formatDate = (dateString) => {
    const options = { year: "numeric", month: "short", day: "numeric" }
    return new Date(dateString).toLocaleDateString(undefined, options)
  }

  return (
    <PageTemplate
      title="Examinations"
      description="Manage school examinations, schedules, and results."
      breadcrumbs={[
        { title: "Examination", href: "#" },
        { title: "Exams", href: "/dashboard/exams", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Create Exam",
        icon: <Plus className="h-4 w-4 mr-2" />,
        href: "/dashboard/exams/create",
      }}
    >
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle>All Examinations</CardTitle>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search exams..."
                  className="w-64 pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Select defaultValue="all">
                <SelectTrigger className="w-36">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="scheduled">Scheduled</SelectItem>
                  <SelectItem value="ongoing">Ongoing</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Exam Name</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Duration</TableHead>
                <TableHead>Classes</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Progress</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredExams.map((exam) => (
                <TableRow key={exam.id}>
                  <TableCell className="font-medium">{exam.name}</TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={
                        exam.type === "Term"
                          ? "bg-blue-50 text-blue-700 hover:bg-blue-50"
                          : exam.type === "Final"
                            ? "bg-purple-50 text-purple-700 hover:bg-purple-50"
                            : exam.type === "Assessment"
                              ? "bg-green-50 text-green-700 hover:bg-green-50"
                              : "bg-orange-50 text-orange-700 hover:bg-orange-50"
                      }
                    >
                      {exam.type}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {formatDate(exam.startDate)} - {formatDate(exam.endDate)}
                  </TableCell>
                  <TableCell>{exam.classes.length} Classes</TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={
                        exam.status === "Completed"
                          ? "bg-green-50 text-green-700 hover:bg-green-50"
                          : exam.status === "Ongoing"
                            ? "bg-blue-50 text-blue-700 hover:bg-blue-50"
                            : "bg-amber-50 text-amber-700 hover:bg-amber-50"
                      }
                    >
                      {exam.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Progress value={exam.progress} className="h-2 w-[60px]" />
                      <span className="text-xs">{exam.progress}%</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <span className="sr-only">Open menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuItem onClick={() => handlePreview(exam)}>
                          <Eye className="mr-2 h-4 w-4" />
                          <span>Preview</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Calendar className="mr-2 h-4 w-4" />
                          <span>View Schedule</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <ClipboardList className="mr-2 h-4 w-4" />
                          <span>View Results</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <FileText className="mr-2 h-4 w-4" />
                          <span>Generate Report</span>
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem>
                          <Edit className="mr-2 h-4 w-4" />
                          <span>Edit</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600">
                          <Trash2 className="mr-2 h-4 w-4" />
                          <span>Delete</span>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Exam Preview Dialog */}
      <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Exam Details: {selectedExam?.name}</DialogTitle>
            <DialogDescription>
              Comprehensive information about the examination, schedule, and subjects.
            </DialogDescription>
          </DialogHeader>

          <Tabs defaultValue="details">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="schedule">Schedule</TabsTrigger>
            </TabsList>

            <TabsContent value="details" className="space-y-4 pt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Exam Name</p>
                  <p>{selectedExam?.name}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Type</p>
                  <p>{selectedExam?.type}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Start Date</p>
                  <p>{selectedExam && formatDate(selectedExam.startDate)}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">End Date</p>
                  <p>{selectedExam && formatDate(selectedExam.endDate)}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Status</p>
                  <Badge
                    variant="outline"
                    className={
                      selectedExam?.status === "Completed"
                        ? "bg-green-50 text-green-700 hover:bg-green-50"
                        : selectedExam?.status === "Ongoing"
                          ? "bg-blue-50 text-blue-700 hover:bg-blue-50"
                          : "bg-amber-50 text-amber-700 hover:bg-amber-50"
                    }
                  >
                    {selectedExam?.status}
                  </Badge>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Progress</p>
                  <div className="flex items-center gap-2">
                    <Progress value={selectedExam?.progress} className="h-2 w-[100px]" />
                    <span>{selectedExam?.progress}%</span>
                  </div>
                </div>
                <div className="space-y-1 col-span-2">
                  <p className="text-sm font-medium text-muted-foreground">Classes</p>
                  <p>{selectedExam?.classes.join(", ")}</p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="schedule" className="pt-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Subject</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Time</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {selectedExam?.subjects.map((subject, index) => (
                    <TableRow key={index}>
                      <TableCell>{subject.name}</TableCell>
                      <TableCell>{formatDate(subject.date)}</TableCell>
                      <TableCell>{subject.time}</TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            subject.status === "Completed"
                              ? "bg-green-50 text-green-700 hover:bg-green-50"
                              : subject.status === "Ongoing"
                                ? "bg-blue-50 text-blue-700 hover:bg-blue-50"
                                : "bg-amber-50 text-amber-700 hover:bg-amber-50"
                          }
                        >
                          {subject.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </PageTemplate>
  )
}
