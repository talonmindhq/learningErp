import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"

export default function ExamResultsLoading() {
  return (
    <PageTemplate
      title="Examination Results"
      description="Analyze and manage student examination results and performance"
      breadcrumbs={[
        { title: "Dashboard", href: "/dashboard" },
        { title: "Examinations", href: "/dashboard/exams" },
        { title: "Results", href: "/dashboard/exams/results", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Download Analytics",
        href: "#",
      }}
    >
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <Skeleton className="h-8 w-48" />
            <div className="flex items-center gap-2">
              <Skeleton className="h-10 w-[250px]" />
              <Skeleton className="h-10 w-[150px]" />
              <Skeleton className="h-10 w-[180px]" />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between">
              <Skeleton className="h-10 w-64" />
              <Skeleton className="h-10 w-36" />
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between h-12 px-4 border-b">
                <Skeleton className="h-4 w-[10%]" />
                <Skeleton className="h-4 w-[15%]" />
                <Skeleton className="h-4 w-[10%]" />
                <Skeleton className="h-4 w-[10%]" />
                <Skeleton className="h-4 w-[10%]" />
                <Skeleton className="h-4 w-[10%]" />
                <Skeleton className="h-4 w-[10%]" />
                <Skeleton className="h-4 w-[10%]" />
                <Skeleton className="h-4 w-[10%]" />
              </div>

              {Array(8)
                .fill(null)
                .map((_, index) => (
                  <div key={index} className="flex items-center justify-between h-16 px-4 border-b">
                    <Skeleton className="h-4 w-[10%]" />
                    <Skeleton className="h-4 w-[15%]" />
                    <Skeleton className="h-4 w-[10%]" />
                    <Skeleton className="h-4 w-[10%]" />
                    <Skeleton className="h-4 w-[10%]" />
                    <Skeleton className="h-4 w-[10%]" />
                    <Skeleton className="h-4 w-[10%]" />
                    <Skeleton className="h-4 w-[10%]" />
                    <Skeleton className="h-8 w-[10%]" />
                  </div>
                ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </PageTemplate>
  )
}
