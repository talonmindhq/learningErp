"use client"

import { useState } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import {
  Search,
  MoreHorizontal,
  Download,
  Eye,
  BarChart4,
  BarChart,
  PieChart,
  LineChart,
  Printer,
  Mail,
} from "lucide-react"

export default function ExamResultsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedExam, setSelectedExam] = useState("1")
  const [selectedClass, setSelectedClass] = useState("all")
  const [selectedView, setSelectedView] = useState("students")

  // Sample data for exams
  const exams = [
    { id: "1", name: "First Term Examination 2023-24" },
    { id: "2", name: "Mid-Term Assessment 2023-24" },
    { id: "3", name: "Final Examination 2023-24" },
    { id: "4", name: "Monthly Test - April 2023" },
  ]

  // Sample data for classes
  const classes = ["Grade 1-A", "Grade 1-B", "Grade 2-A", "Grade 8-C", "Grade 10-A", "Grade 12-B"]

  // Sample data for students
  const students = [
    {
      id: 1,
      name: "John Doe",
      rollNo: "G1A001",
      class: "Grade 1-A",
      totalMarks: 450,
      maxMarks: 500,
      percentage: 90,
      grade: "A+",
      rank: 1,
      status: "Pass",
    },
    {
      id: 2,
      name: "Jane Smith",
      rollNo: "G1A002",
      class: "Grade 1-A",
      totalMarks: 430,
      maxMarks: 500,
      percentage: 86,
      grade: "A",
      rank: 2,
      status: "Pass",
    },
    {
      id: 3,
      name: "Michael Johnson",
      rollNo: "G1A003",
      class: "Grade 1-A",
      totalMarks: 380,
      maxMarks: 500,
      percentage: 76,
      grade: "B+",
      rank: 4,
      status: "Pass",
    },
    {
      id: 4,
      name: "Emily Davis",
      rollNo: "G1A004",
      class: "Grade 1-A",
      totalMarks: 425,
      maxMarks: 500,
      percentage: 85,
      grade: "A",
      rank: 3,
      status: "Pass",
    },
    {
      id: 5,
      name: "David Wilson",
      rollNo: "G1A005",
      class: "Grade 1-A",
      totalMarks: 320,
      maxMarks: 500,
      percentage: 64,
      grade: "C+",
      rank: 5,
      status: "Pass",
    },
    {
      id: 6,
      name: "Sarah Thompson",
      rollNo: "G1B001",
      class: "Grade 1-B",
      totalMarks: 470,
      maxMarks: 500,
      percentage: 94,
      grade: "A+",
      rank: 1,
      status: "Pass",
    },
    {
      id: 7,
      name: "Robert Brown",
      rollNo: "G1B002",
      class: "Grade 1-B",
      totalMarks: 420,
      maxMarks: 500,
      percentage: 84,
      grade: "A",
      rank: 2,
      status: "Pass",
    },
  ]

  // Sample data for class-wise results
  const classResults = [
    { class: "Grade 1-A", students: 35, passRate: 94, avgMarks: 410, highestMarks: 472, lowestMarks: 278 },
    { class: "Grade 1-B", students: 32, passRate: 91, avgMarks: 405, highestMarks: 470, lowestMarks: 265 },
    { class: "Grade 2-A", students: 38, passRate: 95, avgMarks: 415, highestMarks: 485, lowestMarks: 289 },
    { class: "Grade 2-B", students: 36, passRate: 89, avgMarks: 400, highestMarks: 468, lowestMarks: 255 },
    { class: "Grade 8-C", students: 42, passRate: 85, avgMarks: 378, highestMarks: 455, lowestMarks: 230 },
    { class: "Grade 10-A", students: 45, passRate: 82, avgMarks: 352, highestMarks: 475, lowestMarks: 210 },
    { class: "Grade 12-B", students: 40, passRate: 88, avgMarks: 415, highestMarks: 492, lowestMarks: 275 },
  ]

  // Sample data for grade-wise distribution
  const gradeDistribution = [
    { grade: "A+", count: 82, percentage: 18 },
    { grade: "A", count: 125, percentage: 27 },
    { grade: "B+", count: 95, percentage: 21 },
    { grade: "B", count: 78, percentage: 17 },
    { grade: "C+", count: 45, percentage: 10 },
    { grade: "C", count: 23, percentage: 5 },
    { grade: "D", count: 12, percentage: 2 },
  ]

  // Sample data for subject-wise performance
  const subjectPerformance = [
    { subject: "Mathematics", avgScore: 82, passRate: 93, highestScore: 98, lowestScore: 42 },
    { subject: "English", avgScore: 79, passRate: 95, highestScore: 96, lowestScore: 45 },
    { subject: "Science", avgScore: 81, passRate: 92, highestScore: 97, lowestScore: 43 },
    { subject: "Social Studies", avgScore: 78, passRate: 94, highestScore: 95, lowestScore: 41 },
    { subject: "Hindi", avgScore: 80, passRate: 91, highestScore: 96, lowestScore: 44 },
  ]

  // Filter students based on search query and selected class
  const filteredStudents = students.filter((student) => {
    const matchesSearch =
      student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.rollNo.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesClass = selectedClass === "all" || student.class === selectedClass

    return matchesSearch && matchesClass
  })

  return (
    <PageTemplate
      title="Examination Results"
      description="Analyze and manage student examination results and performance"
      breadcrumbs={[
        { title: "Dashboard", href: "/dashboard" },
        { title: "Examinations", href: "/dashboard/exams" },
        { title: "Results", href: "/dashboard/exams/results", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Download Analytics",
        icon: <Download className="h-4 w-4 mr-2" />,
        href: "#",
      }}
    >
      <div className="space-y-4">
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle>Examination Results</CardTitle>
              <div className="flex items-center gap-2">
                <Select value={selectedExam} onValueChange={setSelectedExam}>
                  <SelectTrigger className="w-[250px]">
                    <SelectValue placeholder="Select exam" />
                  </SelectTrigger>
                  <SelectContent>
                    {exams.map((exam) => (
                      <SelectItem key={exam.id} value={exam.id}>
                        {exam.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={selectedClass} onValueChange={setSelectedClass}>
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Select class" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Classes</SelectItem>
                    {classes.map((cls) => (
                      <SelectItem key={cls} value={cls}>
                        {cls}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={selectedView} onValueChange={setSelectedView}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Select view" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="students">Student-wise</SelectItem>
                    <SelectItem value="classes">Class-wise</SelectItem>
                    <SelectItem value="grades">Grade-wise</SelectItem>
                    <SelectItem value="subjects">Subject-wise</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {selectedView === "students" && (
              <div className="space-y-4">
                <div className="flex justify-between">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      type="search"
                      placeholder="Search students..."
                      className="w-64 pl-8"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  <Button variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Export Results
                  </Button>
                </div>

                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[100px]">Roll No</TableHead>
                        <TableHead>Student Name</TableHead>
                        <TableHead>Class</TableHead>
                        <TableHead>Total Marks</TableHead>
                        <TableHead>Percentage</TableHead>
                        <TableHead>Grade</TableHead>
                        <TableHead>Rank</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredStudents.map((student) => (
                        <TableRow key={student.id}>
                          <TableCell className="font-medium">{student.rollNo}</TableCell>
                          <TableCell>{student.name}</TableCell>
                          <TableCell>{student.class}</TableCell>
                          <TableCell>
                            {student.totalMarks}/{student.maxMarks}
                          </TableCell>
                          <TableCell>{student.percentage}%</TableCell>
                          <TableCell>
                            <Badge
                              variant="outline"
                              className={
                                student.grade === "A+" || student.grade === "A"
                                  ? "bg-green-50 text-green-700 hover:bg-green-50"
                                  : student.grade === "A-" || student.grade === "B+"
                                    ? "bg-blue-50 text-blue-700 hover:bg-blue-50"
                                    : student.grade === "B" || student.grade === "B-"
                                      ? "bg-purple-50 text-purple-700 hover:bg-purple-50"
                                      : "bg-amber-50 text-amber-700 hover:bg-amber-50"
                              }
                            >
                              {student.grade}
                            </Badge>
                          </TableCell>
                          <TableCell>{student.rank}</TableCell>
                          <TableCell>
                            <Badge
                              variant="outline"
                              className={
                                student.status === "Pass"
                                  ? "bg-green-50 text-green-700 hover:bg-green-50"
                                  : "bg-red-50 text-red-700 hover:bg-red-50"
                              }
                            >
                              {student.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" className="h-8 w-8 p-0">
                                  <span className="sr-only">Open menu</span>
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                <DropdownMenuItem>
                                  <Eye className="mr-2 h-4 w-4" />
                                  <span>View Result</span>
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Printer className="mr-2 h-4 w-4" />
                                  <span>Print Result</span>
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Download className="mr-2 h-4 w-4" />
                                  <span>Download PDF</span>
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Mail className="mr-2 h-4 w-4" />
                                  <span>Email to Parent</span>
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem>
                                  <span>View Subject-wise Score</span>
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                      {filteredStudents.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={9} className="text-center py-6 text-muted-foreground">
                            No students found matching your filters
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}

            {selectedView === "classes" && (
              <div className="space-y-6">
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Class</TableHead>
                        <TableHead>Students</TableHead>
                        <TableHead>Pass Rate</TableHead>
                        <TableHead>Average Marks</TableHead>
                        <TableHead>Highest Marks</TableHead>
                        <TableHead>Lowest Marks</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {classResults.map((cls, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">{cls.class}</TableCell>
                          <TableCell>{cls.students}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <span>{cls.passRate}%</span>
                              <Badge
                                variant="outline"
                                className={
                                  cls.passRate >= 90
                                    ? "bg-green-50 text-green-700"
                                    : cls.passRate >= 80
                                      ? "bg-blue-50 text-blue-700"
                                      : "bg-amber-50 text-amber-700"
                                }
                              >
                                {cls.passRate >= 90 ? "Excellent" : cls.passRate >= 80 ? "Good" : "Average"}
                              </Badge>
                            </div>
                          </TableCell>
                          <TableCell>{cls.avgMarks}/500</TableCell>
                          <TableCell>{cls.highestMarks}/500</TableCell>
                          <TableCell>{cls.lowestMarks}/500</TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm">
                              <BarChart className="h-4 w-4 mr-1" />
                              View Analysis
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Pass Rate Comparison</CardTitle>
                      <CardDescription>Class-wise pass percentage comparison</CardDescription>
                    </CardHeader>
                    <CardContent className="flex items-center justify-center h-80">
                      <BarChart4 className="h-60 w-60 text-gray-300" />
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardTitle>Average Scores Comparison</CardTitle>
                      <CardDescription>Class-wise average scores comparison</CardDescription>
                    </CardHeader>
                    <CardContent className="flex items-center justify-center h-80">
                      <BarChart className="h-60 w-60 text-gray-300" />
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}

            {selectedView === "grades" && (
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Grade Distribution</CardTitle>
                      <CardDescription>Overall grade distribution across all classes</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-center h-80">
                        <PieChart className="h-60 w-60 text-gray-300" />
                      </div>
                      <div className="grid grid-cols-2 gap-4 mt-4">
                        {gradeDistribution.map((grade, i) => (
                          <div key={i} className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div
                                className={`w-3 h-3 rounded-full ${
                                  grade.grade === "A+"
                                    ? "bg-green-500"
                                    : grade.grade === "A"
                                      ? "bg-green-400"
                                      : grade.grade === "B+"
                                        ? "bg-blue-500"
                                        : grade.grade === "B"
                                          ? "bg-blue-400"
                                          : grade.grade === "C+"
                                            ? "bg-purple-500"
                                            : grade.grade === "C"
                                              ? "bg-purple-400"
                                              : "bg-gray-400"
                                }`}
                              />
                              <span className="text-sm">Grade {grade.grade}</span>
                            </div>
                            <div className="flex gap-4">
                              <span className="text-sm">{grade.count} students</span>
                              <span className="text-sm text-muted-foreground">{grade.percentage}%</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardTitle>Performance Trends</CardTitle>
                      <CardDescription>Grade distribution trends over past exams</CardDescription>
                    </CardHeader>
                    <CardContent className="flex items-center justify-center h-80">
                      <LineChart className="h-60 w-60 text-gray-300" />
                    </CardContent>
                  </Card>
                </div>

                <Card>
                  <CardHeader>
                    <CardTitle>Top Performers</CardTitle>
                    <CardDescription>Students who achieved A+ grade</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Roll No</TableHead>
                          <TableHead>Student Name</TableHead>
                          <TableHead>Class</TableHead>
                          <TableHead>Percentage</TableHead>
                          <TableHead>Rank</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {students
                          .filter((s) => s.grade === "A+")
                          .map((student) => (
                            <TableRow key={student.id}>
                              <TableCell className="font-medium">{student.rollNo}</TableCell>
                              <TableCell>{student.name}</TableCell>
                              <TableCell>{student.class}</TableCell>
                              <TableCell>{student.percentage}%</TableCell>
                              <TableCell>{student.rank}</TableCell>
                              <TableCell className="text-right">
                                <Button variant="ghost" size="sm">
                                  <Eye className="h-4 w-4 mr-1" />
                                  View Result
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </div>
            )}

            {selectedView === "subjects" && (
              <div className="space-y-6">
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Subject</TableHead>
                        <TableHead>Average Score (%)</TableHead>
                        <TableHead>Pass Rate</TableHead>
                        <TableHead>Highest Score</TableHead>
                        <TableHead>Lowest Score</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {subjectPerformance.map((subject, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">{subject.subject}</TableCell>
                          <TableCell>{subject.avgScore}%</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <span>{subject.passRate}%</span>
                              <Badge
                                variant="outline"
                                className={
                                  subject.passRate >= 90
                                    ? "bg-green-50 text-green-700"
                                    : subject.passRate >= 80
                                      ? "bg-blue-50 text-blue-700"
                                      : "bg-amber-50 text-amber-700"
                                }
                              >
                                {subject.passRate >= 90 ? "Excellent" : subject.passRate >= 80 ? "Good" : "Average"}
                              </Badge>
                            </div>
                          </TableCell>
                          <TableCell>{subject.highestScore}%</TableCell>
                          <TableCell>{subject.lowestScore}%</TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm">
                              <BarChart className="h-4 w-4 mr-1" />
                              View Analysis
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Subject Performance Comparison</CardTitle>
                      <CardDescription>Average scores by subject</CardDescription>
                    </CardHeader>
                    <CardContent className="flex items-center justify-center h-80">
                      <BarChart className="h-60 w-60 text-gray-300" />
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardTitle>Pass Rate by Subject</CardTitle>
                      <CardDescription>Subject-wise pass rate comparison</CardDescription>
                    </CardHeader>
                    <CardContent className="flex items-center justify-center h-80">
                      <BarChart4 className="h-60 w-60 text-gray-300" />
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </PageTemplate>
  )
}
