"use client"

import { useState } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { MoreHorizontal, Search, Plus, Edit, Trash2, Users, BookOpen, Calendar, Eye } from "lucide-react"

export default function ClassesPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedClass, setSelectedClass] = useState(null)
  const [isPreviewOpen, setIsPreviewOpen] = useState(false)

  // Sample data for classes
  const classes = [
    {
      id: 1,
      name: "Grade 1-A",
      section: "A",
      level: "Primary",
      students: 32,
      classTeacher: "Mrs. Johnson",
      subjects: 6,
      room: "P-101",
    },
    {
      id: 2,
      name: "Grade 1-B",
      section: "B",
      level: "Primary",
      students: 30,
      classTeacher: "Mr. Smith",
      subjects: 6,
      room: "P-102",
    },
    {
      id: 3,
      name: "Grade 2-A",
      section: "A",
      level: "Primary",
      students: 28,
      classTeacher: "Mrs. Davis",
      subjects: 7,
      room: "P-201",
    },
    {
      id: 4,
      name: "Grade 8-C",
      section: "C",
      level: "Middle",
      students: 35,
      classTeacher: "Mr. Wilson",
      subjects: 9,
      room: "M-303",
    },
    {
      id: 5,
      name: "Grade 10-A",
      section: "A",
      level: "High",
      students: 30,
      classTeacher: "Mrs. Brown",
      subjects: 10,
      room: "H-101",
    },
    {
      id: 6,
      name: "Grade 12-B",
      section: "B",
      level: "High",
      students: 25,
      classTeacher: "Mr. Taylor",
      subjects: 8,
      room: "H-205",
    },
  ]

  // Sample data for students in a class
  const classStudents = [
    { id: 1, name: "John Doe", rollNo: "G1A001", gender: "Male", attendance: "95%" },
    { id: 2, name: "Jane Smith", rollNo: "G1A002", gender: "Female", attendance: "98%" },
    { id: 3, name: "Michael Johnson", rollNo: "G1A003", gender: "Male", attendance: "92%" },
    { id: 4, name: "Emily Davis", rollNo: "G1A004", gender: "Female", attendance: "97%" },
    { id: 5, name: "David Wilson", rollNo: "G1A005", gender: "Male", attendance: "90%" },
  ]

  // Sample data for subjects in a class
  const classSubjects = [
    { id: 1, name: "Mathematics", teacher: "Mrs. Johnson", weeklyClasses: 5 },
    { id: 2, name: "English", teacher: "Mr. Smith", weeklyClasses: 5 },
    { id: 3, name: "Science", teacher: "Mrs. Davis", weeklyClasses: 4 },
    { id: 4, name: "Social Studies", teacher: "Mr. Wilson", weeklyClasses: 3 },
    { id: 5, name: "Art", teacher: "Mrs. Brown", weeklyClasses: 2 },
    { id: 6, name: "Physical Education", teacher: "Mr. Taylor", weeklyClasses: 2 },
  ]

  // Sample data for timetable
  const classTimetable = [
    { day: "Monday", periods: ["Mathematics", "English", "Science", "Lunch", "Social Studies", "Art"] },
    { day: "Tuesday", periods: ["English", "Mathematics", "Science", "Lunch", "Physical Education", "Social Studies"] },
    { day: "Wednesday", periods: ["Science", "Mathematics", "English", "Lunch", "Art", "Social Studies"] },
    {
      day: "Thursday",
      periods: ["Mathematics", "Science", "English", "Lunch", "Social Studies", "Physical Education"],
    },
    { day: "Friday", periods: ["English", "Mathematics", "Science", "Lunch", "Social Studies", "Art"] },
  ]

  const filteredClasses = classes.filter(
    (cls) =>
      cls.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      cls.classTeacher.toLowerCase().includes(searchQuery.toLowerCase()) ||
      cls.level.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handlePreview = (cls) => {
    setSelectedClass(cls)
    setIsPreviewOpen(true)
  }

  return (
    <PageTemplate
      title="Classes"
      description="Manage school classes, sections, and related information."
      breadcrumbs={[
        { title: "Academic Portfolio", href: "#" },
        { title: "Classes", href: "/dashboard/classes", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Add Class",
        icon: <Plus className="h-4 w-4 mr-2" />,
        href: "/dashboard/classes/add",
      }}
    >
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle>All Classes</CardTitle>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search classes..."
                  className="w-64 pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Select defaultValue="all">
                <SelectTrigger className="w-36">
                  <SelectValue placeholder="Filter by level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Levels</SelectItem>
                  <SelectItem value="primary">Primary</SelectItem>
                  <SelectItem value="middle">Middle</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Class Name</TableHead>
                <TableHead>Level</TableHead>
                <TableHead>Class Teacher</TableHead>
                <TableHead>Students</TableHead>
                <TableHead>Subjects</TableHead>
                <TableHead>Room</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredClasses.map((cls) => (
                <TableRow key={cls.id}>
                  <TableCell className="font-medium">{cls.name}</TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={
                        cls.level === "Primary"
                          ? "bg-blue-50 text-blue-700 hover:bg-blue-50"
                          : cls.level === "Middle"
                            ? "bg-purple-50 text-purple-700 hover:bg-purple-50"
                            : "bg-green-50 text-green-700 hover:bg-green-50"
                      }
                    >
                      {cls.level}
                    </Badge>
                  </TableCell>
                  <TableCell>{cls.classTeacher}</TableCell>
                  <TableCell>{cls.students}</TableCell>
                  <TableCell>{cls.subjects}</TableCell>
                  <TableCell>{cls.room}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <span className="sr-only">Open menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuItem onClick={() => handlePreview(cls)}>
                          <Eye className="mr-2 h-4 w-4" />
                          <span>Preview</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Users className="mr-2 h-4 w-4" />
                          <span>View Students</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <BookOpen className="mr-2 h-4 w-4" />
                          <span>View Subjects</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Calendar className="mr-2 h-4 w-4" />
                          <span>View Timetable</span>
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem>
                          <Edit className="mr-2 h-4 w-4" />
                          <span>Edit</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600">
                          <Trash2 className="mr-2 h-4 w-4" />
                          <span>Delete</span>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Class Preview Dialog */}
      <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Class Details: {selectedClass?.name}</DialogTitle>
            <DialogDescription>
              Comprehensive information about the class, students, subjects, and timetable.
            </DialogDescription>
          </DialogHeader>

          <Tabs defaultValue="details">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="students">Students</TabsTrigger>
              <TabsTrigger value="subjects">Subjects</TabsTrigger>
              <TabsTrigger value="timetable">Timetable</TabsTrigger>
            </TabsList>

            <TabsContent value="details" className="space-y-4 pt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Class Name</p>
                  <p>{selectedClass?.name}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Section</p>
                  <p>{selectedClass?.section}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Level</p>
                  <p>{selectedClass?.level}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Room</p>
                  <p>{selectedClass?.room}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Class Teacher</p>
                  <p>{selectedClass?.classTeacher}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Number of Students</p>
                  <p>{selectedClass?.students}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Number of Subjects</p>
                  <p>{selectedClass?.subjects}</p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="students" className="pt-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Roll No</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Gender</TableHead>
                    <TableHead>Attendance</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {classStudents.map((student) => (
                    <TableRow key={student.id}>
                      <TableCell>{student.rollNo}</TableCell>
                      <TableCell>{student.name}</TableCell>
                      <TableCell>{student.gender}</TableCell>
                      <TableCell>{student.attendance}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TabsContent>

            <TabsContent value="subjects" className="pt-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Subject</TableHead>
                    <TableHead>Teacher</TableHead>
                    <TableHead>Weekly Classes</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {classSubjects.map((subject) => (
                    <TableRow key={subject.id}>
                      <TableCell>{subject.name}</TableCell>
                      <TableCell>{subject.teacher}</TableCell>
                      <TableCell>{subject.weeklyClasses}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TabsContent>

            <TabsContent value="timetable" className="pt-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Day</TableHead>
                    <TableHead>Period 1</TableHead>
                    <TableHead>Period 2</TableHead>
                    <TableHead>Period 3</TableHead>
                    <TableHead>Period 4</TableHead>
                    <TableHead>Period 5</TableHead>
                    <TableHead>Period 6</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {classTimetable.map((day) => (
                    <TableRow key={day.day}>
                      <TableCell className="font-medium">{day.day}</TableCell>
                      {day.periods.map((period, index) => (
                        <TableCell key={index} className={period === "Lunch" ? "bg-gray-100" : ""}>
                          {period}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </PageTemplate>
  )
}
