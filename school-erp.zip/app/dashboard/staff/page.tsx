"use client"

import { useState } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Plus, Eye, Phone, Mail, MoreHorizontal, Car } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function StaffPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [departmentFilter, setDepartmentFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")

  // Sample data
  const staff = [
    {
      id: "EMP001",
      name: "Dr. Rajesh Patel",
      department: "Science",
      designation: "Senior Teacher",
      phone: "+91 9876543210",
      email: "rajesh.p@example.com",
      joinDate: "2018-06-15",
      status: "active",
    },
    {
      id: "EMP002",
      name: "Mrs. Sunita Sharma",
      department: "Mathematics",
      designation: "HOD",
      phone: "+91 8765432109",
      email: "sunita.s@example.com",
      joinDate: "2015-07-10",
      status: "active",
    },
    {
      id: "EMP003",
      name: "Mr. Amit Verma",
      department: "English",
      designation: "Teacher",
      phone: "+91 7654321098",
      email: "amit.v@example.com",
      joinDate: "2020-03-22",
      status: "active",
    },
    {
      id: "EMP004",
      name: "Mrs. Priya Gupta",
      department: "Social Studies",
      designation: "Teacher",
      phone: "+91 6543210987",
      email: "priya.g@example.com",
      joinDate: "2019-08-05",
      status: "on_leave",
    },
    {
      id: "EMP005",
      name: "Mr. Vikram Singh",
      department: "Physical Education",
      designation: "Sports Coach",
      phone: "+91 5432109876",
      email: "vikram.s@example.com",
      joinDate: "2021-01-15",
      status: "active",
    },
    // Add transport staff from Tamil Nadu
    {
      id: "EMP101",
      name: "Murugan Selvaraj",
      department: "Transport",
      designation: "Driver",
      phone: "+91 9876543210",
      email: "murugan.s@example.com",
      joinDate: "2015-06-10",
      status: "active",
      transportId: "DRV-101",
      vehicle: "BUS-101",
    },
    {
      id: "EMP102",
      name: "Senthil Kumar",
      department: "Transport",
      designation: "Driver",
      phone: "+91 8765432109",
      email: "senthil.k@example.com",
      joinDate: "2018-04-15",
      status: "active",
      transportId: "DRV-102",
      vehicle: "BUS-102",
    },
    {
      id: "EMP103",
      name: "Karthik Rajan",
      department: "Transport",
      designation: "Driver",
      phone: "+91 7654321098",
      email: "karthik.r@example.com",
      joinDate: "2011-08-22",
      status: "active",
      transportId: "DRV-103",
      vehicle: "BUS-103",
    },
    {
      id: "EMP104",
      name: "Vijay Prakash",
      department: "Transport",
      designation: "Driver",
      phone: "+91 6543210987",
      email: "vijay.p@example.com",
      joinDate: "2016-11-05",
      status: "active",
      transportId: "DRV-104",
      vehicle: "BUS-104",
    },
    {
      id: "EMP105",
      name: "Ramesh Chandran",
      department: "Transport",
      designation: "Driver",
      phone: "+91 5432109876",
      email: "ramesh.c@example.com",
      joinDate: "2013-03-18",
      status: "active",
      transportId: "DRV-105",
      vehicle: "BUS-105",
    },
  ]

  const filteredStaff = staff.filter((employee) => {
    const matchesSearch =
      employee.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      employee.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      employee.designation.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesDepartment = departmentFilter === "all" || employee.department === departmentFilter
    const matchesStatus = statusFilter === "all" || employee.status === statusFilter

    return matchesSearch && matchesDepartment && matchesStatus
  })

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-500">Active</Badge>
      case "on_leave":
        return <Badge className="bg-amber-500">On Leave</Badge>
      case "inactive":
        return <Badge className="bg-gray-500">Inactive</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
  }

  return (
    <PageTemplate
      title="Staff"
      description="Manage school staff and faculty"
      breadcrumbs={[
        { title: "Employee Module", href: "/dashboard/staff" },
        { title: "Staff", href: "/dashboard/staff", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Add Staff",
        icon: <Plus className="mr-2 h-4 w-4" />,
        href: "/dashboard/staff/add",
      }}
    >
      <Card>
        <CardHeader className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
          <CardTitle>All Staff</CardTitle>
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search staff..."
                className="pl-8 w-full sm:w-[250px]"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="Filter by department" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Departments</SelectItem>
                <SelectItem value="Science">Science</SelectItem>
                <SelectItem value="Mathematics">Mathematics</SelectItem>
                <SelectItem value="English">English</SelectItem>
                <SelectItem value="Social Studies">Social Studies</SelectItem>
                <SelectItem value="Physical Education">Physical Education</SelectItem>
                <SelectItem value="Transport">Transport</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-[150px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="on_leave">On Leave</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead className="hidden md:table-cell">Designation</TableHead>
                  <TableHead className="hidden md:table-cell">Contact</TableHead>
                  <TableHead className="hidden md:table-cell">Join Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredStaff.map((employee) => (
                  <TableRow key={employee.id}>
                    <TableCell className="font-medium">{employee.id}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Avatar className="h-8 w-8">
                          <AvatarImage
                            src={`/abstract-geometric-shapes.png?key=css7y&height=32&width=32&query=${employee.name}`}
                            alt={employee.name}
                          />
                          <AvatarFallback>{getInitials(employee.name)}</AvatarFallback>
                        </Avatar>
                        <span>{employee.name}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        {employee.department}
                        {employee.department === "Transport" && employee.vehicle && (
                          <Badge variant="outline" className="ml-2 bg-blue-50 text-blue-700 border-blue-200">
                            <Car className="h-3 w-3 mr-1" />
                            {employee.vehicle}
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">{employee.designation}</TableCell>
                    <TableCell className="hidden md:table-cell">
                      <div className="flex flex-col">
                        <div className="flex items-center text-xs text-muted-foreground">
                          <Phone className="mr-1 h-3 w-3" />
                          {employee.phone}
                        </div>
                        <div className="flex items-center text-xs text-muted-foreground mt-1">
                          <Mail className="mr-1 h-3 w-3" />
                          {employee.email}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      {new Date(employee.joinDate).toLocaleDateString()}
                    </TableCell>
                    <TableCell>{getStatusBadge(employee.status)}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="ghost" size="icon" title="View Profile">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" title="More Options">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </PageTemplate>
  )
}
