"use client"

import { useState, useEffect } from "react"
import { Bus, Search, Filter, Download, Plus, Users, Route, Calendar, AlertCircle, User, Car } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

// Tamil Nadu vehicle and route data
const tamilNaduVehicles = [
  {
    id: "BUS-101",
    type: "School Bus",
    registration: "TN-01-AB-1234",
    capacity: 42,
    route: "Chennai Central Route",
    status: "Active",
    driver: "Murugan Selvaraj",
    driverId: "DRV-101",
    currentLocation: { lat: 13.0827, lng: 80.2707 }, // Chennai
    lastUpdated: "08:45 AM",
  },
  {
    id: "BUS-102",
    type: "Mini Bus",
    registration: "TN-01-CD-5678",
    capacity: 24,
    route: "Coimbatore Route",
    status: "Maintenance",
    driver: "Senthil Kumar",
    driverId: "DRV-102",
    currentLocation: { lat: 11.0168, lng: 76.9558 }, // Coimbatore
    lastUpdated: "08:30 AM",
  },
  {
    id: "BUS-103",
    type: "School Bus",
    registration: "TN-01-EF-9012",
    capacity: 42,
    route: "Madurai Route",
    status: "Active",
    driver: "Karthik Rajan",
    driverId: "DRV-103",
    currentLocation: { lat: 9.9252, lng: 78.1198 }, // Madurai
    lastUpdated: "08:50 AM",
  },
  {
    id: "BUS-104",
    type: "Van",
    registration: "TN-01-GH-3456",
    capacity: 12,
    route: "Trichy Route",
    status: "Standby",
    driver: "Vijay Prakash",
    driverId: "DRV-104",
    currentLocation: { lat: 10.7905, lng: 78.7047 }, // Trichy
    lastUpdated: "08:15 AM",
  },
  {
    id: "BUS-105",
    type: "School Bus",
    registration: "TN-01-IJ-7890",
    capacity: 42,
    route: "Salem Route",
    status: "Active",
    driver: "Ramesh Chandran",
    driverId: "DRV-105",
    currentLocation: { lat: 11.6643, lng: 78.146 }, // Salem
    lastUpdated: "08:40 AM",
  },
]

const tamilNaduRoutes = [
  {
    id: "RT-101",
    name: "Chennai Central Route",
    stops: ["T. Nagar", "Nungambakkam", "Egmore", "Mylapore", "Adyar", "Velachery", "Tambaram", "School Campus"],
    distance: 18.5,
    startTime: "7:30 AM",
    endTime: "8:45 AM",
    students: 125,
  },
  {
    id: "RT-102",
    name: "Coimbatore Route",
    stops: ["Peelamedu", "Singanallur", "Ondipudur", "Sulur", "Avinashi Road", "School Campus"],
    distance: 12.2,
    startTime: "7:45 AM",
    endTime: "8:30 AM",
    students: 98,
  },
  {
    id: "RT-103",
    name: "Madurai Route",
    stops: [
      "Mattuthavani",
      "Arapalayam",
      "Goripalayam",
      "Tallakulam",
      "Anna Nagar",
      "Surveyor Colony",
      "K.K. Nagar",
      "Bypass Road",
      "School Campus",
    ],
    distance: 14.3,
    startTime: "7:15 AM",
    endTime: "8:45 AM",
    students: 142,
  },
  {
    id: "RT-104",
    name: "Trichy Route",
    stops: ["Srirangam", "Thiruvanaikoil", "Thillai Nagar", "Woraiyur", "K.K. Nagar", "Airport", "School Campus"],
    distance: 9.7,
    startTime: "7:30 AM",
    endTime: "8:30 AM",
    students: 87,
  },
  {
    id: "RT-105",
    name: "Salem Route",
    stops: ["Hasthampatti", "Four Roads", "Fairlands", "Alagapuram", "School Campus"],
    distance: 6.5,
    startTime: "8:00 AM",
    endTime: "9:00 AM",
    students: 65,
  },
]

const tamilNaduDrivers = [
  {
    id: "DRV-101",
    name: "Murugan Selvaraj",
    licenseNo: "TN-DL-20110034567",
    contact: "9876543210",
    experience: 8,
    assignedVehicle: "BUS-101",
    status: "Active",
    employeeId: "EMP101",
    salary: 28000,
    address: "123, Anna Nagar, Chennai",
    joiningDate: "2015-06-10",
  },
  {
    id: "DRV-102",
    name: "Senthil Kumar",
    licenseNo: "TN-DL-20130045678",
    contact: "8765432109",
    experience: 5,
    assignedVehicle: "BUS-102",
    status: "Active",
    employeeId: "EMP102",
    salary: 25000,
    address: "45, R.S. Puram, Coimbatore",
    joiningDate: "2018-04-15",
  },
  {
    id: "DRV-103",
    name: "Karthik Rajan",
    licenseNo: "TN-DL-20090056789",
    contact: "7654321098",
    experience: 12,
    assignedVehicle: "BUS-103",
    status: "Active",
    employeeId: "EMP103",
    salary: 32000,
    address: "78, K.K. Nagar, Madurai",
    joiningDate: "2011-08-22",
  },
  {
    id: "DRV-104",
    name: "Vijay Prakash",
    licenseNo: "TN-DL-20150067890",
    contact: "6543210987",
    experience: 7,
    assignedVehicle: "BUS-104",
    status: "Active",
    employeeId: "EMP104",
    salary: 26000,
    address: "34, Thillai Nagar, Trichy",
    joiningDate: "2016-11-05",
  },
  {
    id: "DRV-105",
    name: "Ramesh Chandran",
    licenseNo: "TN-DL-20100078901",
    contact: "5432109876",
    experience: 10,
    assignedVehicle: "BUS-105",
    status: "Active",
    employeeId: "EMP105",
    salary: 30000,
    address: "56, Hasthampatti, Salem",
    joiningDate: "2013-03-18",
  },
]

const tamilNaduStudents = [
  {
    id: "STD-1001",
    name: "Arun Kumar",
    class: "Class 8A",
    route: "Chennai Central Route",
    stop: "T. Nagar",
    pickupTime: "7:35 AM",
    feeStatus: "Paid",
  },
  {
    id: "STD-1002",
    name: "Divya Prakash",
    class: "Class 5B",
    route: "Coimbatore Route",
    stop: "Peelamedu",
    pickupTime: "7:50 AM",
    feeStatus: "Paid",
  },
  {
    id: "STD-1003",
    name: "Arjun Ramasamy",
    class: "Class 10C",
    route: "Madurai Route",
    stop: "Anna Nagar",
    pickupTime: "7:25 AM",
    feeStatus: "Pending",
  },
  {
    id: "STD-1004",
    name: "Ananya Gopal",
    class: "Class 7A",
    route: "Trichy Route",
    stop: "Thillai Nagar",
    pickupTime: "7:40 AM",
    feeStatus: "Paid",
  },
  {
    id: "STD-1005",
    name: "Vihaan Mehta",
    class: "Class 9B",
    route: "Salem Route",
    stop: "Fairlands",
    pickupTime: "8:10 AM",
    feeStatus: "Paid",
  },
]

export default function TransportPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [routeFilter, setRouteFilter] = useState("all")
  const [selectedVehicle, setSelectedVehicle] = useState("all")
  const [mapLoaded, setMapLoaded] = useState(false)

  // Filter vehicles based on search query and route
  const filteredVehicles = tamilNaduVehicles.filter((vehicle) => {
    const matchesSearch =
      vehicle.registration.toLowerCase().includes(searchQuery.toLowerCase()) ||
      vehicle.driver.toLowerCase().includes(searchQuery.toLowerCase()) ||
      vehicle.id.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesRoute = routeFilter === "all" || vehicle.route === routeFilter
    return matchesSearch && matchesRoute
  })

  // Get unique routes for filter
  const routeOptions = ["all", ...new Set(tamilNaduVehicles.map((vehicle) => vehicle.route))]

  // Simulate loading the map
  useEffect(() => {
    const timer = setTimeout(() => {
      setMapLoaded(true)
    }, 1500)
    return () => clearTimeout(timer)
  }, [])

  return (
    <div className="flex-1 space-y-4 p-4 md:p-8">
      <div className="flex items-center justify-between">
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/dashboard">Dashboard</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>Transport Management</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Button className="bg-theme-500 hover:bg-theme-600 text-white">
            <Plus className="mr-2 h-4 w-4" />
            Add Vehicle
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-l-4 border-l-theme-500 hover:shadow-md transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Vehicles</CardTitle>
            <div className="rounded-full bg-theme-100 p-2 text-theme-500">
              <Bus className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{tamilNaduVehicles.length}</div>
            <p className="text-xs text-muted-foreground">
              {tamilNaduVehicles.filter((v) => v.type === "School Bus").length} Buses,{" "}
              {tamilNaduVehicles.filter((v) => v.type === "Mini Bus").length} Mini Buses,{" "}
              {tamilNaduVehicles.filter((v) => v.type === "Van").length} Vans
            </p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-accent2-500 hover:shadow-md transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Routes</CardTitle>
            <div className="rounded-full bg-accent2-100 p-2 text-accent2-500">
              <Route className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{tamilNaduRoutes.length}</div>
            <p className="text-xs text-muted-foreground">
              Covering {tamilNaduRoutes.reduce((acc, route) => acc + route.distance, 0).toFixed(1)} km
            </p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-accent1-500 hover:shadow-md transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Students Using Transport</CardTitle>
            <div className="rounded-full bg-accent1-100 p-2 text-accent1-500">
              <Users className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{tamilNaduRoutes.reduce((acc, route) => acc + route.students, 0)}</div>
            <p className="text-xs text-muted-foreground">Out of 1,248 students</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-theme-400 hover:shadow-md transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Maintenance Alerts</CardTitle>
            <div className="rounded-full bg-theme-100 p-2 text-theme-400">
              <AlertCircle className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {tamilNaduVehicles.filter((v) => v.status === "Maintenance").length}
            </div>
            <p className="text-xs text-muted-foreground">Vehicle under maintenance</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Live Bus Tracking - Tamil Nadu</CardTitle>
          <CardDescription>Track all school buses in real-time across Tamil Nadu</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="w-full md:w-1/4 space-y-4">
              <Select value={selectedVehicle} onValueChange={setSelectedVehicle}>
                <SelectTrigger>
                  <SelectValue placeholder="Select Vehicle" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Vehicles</SelectItem>
                  {tamilNaduVehicles.map((vehicle) => (
                    <SelectItem key={vehicle.id} value={vehicle.id}>
                      {vehicle.id} - {vehicle.route}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Active Vehicles</h3>
                {tamilNaduVehicles
                  .filter((v) => v.status === "Active")
                  .map((vehicle) => (
                    <div
                      key={vehicle.id}
                      className={`flex items-center justify-between p-2 border rounded-md ${
                        selectedVehicle === vehicle.id ? "border-theme-500 bg-theme-50" : ""
                      } cursor-pointer`}
                      onClick={() => setSelectedVehicle(vehicle.id)}
                    >
                      <div>
                        <p className="font-medium">{vehicle.id}</p>
                        <p className="text-xs text-muted-foreground">{vehicle.route}</p>
                      </div>
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                        On Route
                      </Badge>
                    </div>
                  ))}
              </div>
            </div>

            <div className="w-full md:w-3/4 h-[400px] bg-gray-100 rounded-md relative overflow-hidden">
              {!mapLoaded ? (
                <div className="flex items-center justify-center h-full">
                  <div className="text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-theme-500 mx-auto"></div>
                    <p className="mt-4 text-muted-foreground">Loading Tamil Nadu map...</p>
                  </div>
                </div>
              ) : (
                <>
                  {/* Tamil Nadu Map */}
                  <img src="/tamil-nadu-map.png" alt="Tamil Nadu Map" className="w-full h-full object-cover" />

                  {/* Vehicle Markers */}
                  {tamilNaduVehicles
                    .filter((v) => selectedVehicle === "all" || v.id === selectedVehicle)
                    .map((vehicle, index) => {
                      // Calculate position based on index for demo purposes
                      // In a real app, you would use actual GPS coordinates
                      const top = 20 + ((index * 70) % 300)
                      const left = 30 + ((index * 150) % 600)

                      return (
                        <div
                          key={vehicle.id}
                          className="absolute flex flex-col items-center"
                          style={{ top: `${top}px`, left: `${left}px` }}
                        >
                          <div className="relative">
                            <Bus className="h-6 w-6 text-theme-600" />
                            <span className="absolute -top-1 -right-1 flex h-3 w-3">
                              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-theme-400 opacity-75"></span>
                              <span className="relative inline-flex rounded-full h-3 w-3 bg-theme-500"></span>
                            </span>
                          </div>
                          <div className="mt-1 px-2 py-1 bg-white rounded-md shadow-md text-xs">
                            <p className="font-bold">{vehicle.id}</p>
                            <p className="text-[10px] text-muted-foreground">Last updated: {vehicle.lastUpdated}</p>
                          </div>
                        </div>
                      )
                    })}

                  {/* Route Lines - simplified for demo */}
                  <svg className="absolute top-0 left-0 w-full h-full pointer-events-none">
                    {tamilNaduVehicles
                      .filter((v) => selectedVehicle === "all" || v.id === selectedVehicle)
                      .map((vehicle, index) => {
                        // Calculate route paths for demo purposes
                        const startX = 30 + ((index * 150) % 600)
                        const startY = 20 + ((index * 70) % 300)
                        const endX = 700 - ((index * 50) % 200)
                        const endY = 350 - ((index * 30) % 100)

                        return (
                          <path
                            key={vehicle.id}
                            d={`M ${startX},${startY} C ${startX + 100},${startY + 50} ${endX - 100},${endY - 50} ${endX},${endY}`}
                            stroke={["#7c3aed", "#2563eb", "#059669", "#d97706", "#dc2626"][index % 5]}
                            strokeWidth="2"
                            fill="none"
                            strokeDasharray="5,5"
                            opacity="0.6"
                          />
                        )
                      })}
                  </svg>
                </>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="vehicles" className="w-full">
        <TabsList className="grid w-full md:w-auto grid-cols-4 h-auto">
          <TabsTrigger value="vehicles">Vehicles</TabsTrigger>
          <TabsTrigger value="routes">Routes</TabsTrigger>
          <TabsTrigger value="drivers">Drivers</TabsTrigger>
          <TabsTrigger value="students">Students</TabsTrigger>
        </TabsList>

        <TabsContent value="vehicles" className="space-y-4">
          <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
            <div className="relative w-full md:w-80">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search vehicles..."
                className="w-full pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex flex-col sm:flex-row w-full md:w-auto gap-2">
              <Select value={routeFilter} onValueChange={setRouteFilter}>
                <SelectTrigger className="w-full sm:w-[180px]">
                  <SelectValue placeholder="Route" />
                </SelectTrigger>
                <SelectContent>
                  {routeOptions.map((route) => (
                    <SelectItem key={route} value={route}>
                      {route === "all" ? "All Routes" : route}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
              <Button variant="outline" className="hidden md:flex">
                <Calendar className="mr-2 h-4 w-4" />
                Schedule
              </Button>
            </div>
          </div>

          <Card>
            <CardHeader className="py-4">
              <CardTitle>Vehicle List</CardTitle>
              <CardDescription>Manage your school transport vehicles and their details.</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Vehicle ID</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Registration</TableHead>
                    <TableHead>Driver</TableHead>
                    <TableHead>Route</TableHead>
                    <TableHead>Capacity</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredVehicles.map((vehicle) => (
                    <TableRow key={vehicle.id}>
                      <TableCell className="font-medium">{vehicle.id}</TableCell>
                      <TableCell>{vehicle.type}</TableCell>
                      <TableCell>{vehicle.registration}</TableCell>
                      <TableCell>{vehicle.driver}</TableCell>
                      <TableCell>{vehicle.route}</TableCell>
                      <TableCell>{vehicle.capacity} students</TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            vehicle.status === "Active"
                              ? "bg-green-50 text-green-700 border-green-200"
                              : vehicle.status === "Maintenance"
                                ? "bg-amber-50 text-amber-700 border-amber-200"
                                : "bg-blue-50 text-blue-700 border-blue-200"
                          }
                        >
                          {vehicle.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="routes" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Transport Routes</CardTitle>
              <CardDescription>Manage your school transport routes and stops.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex justify-end mb-4">
                <Button className="bg-theme-500 hover:bg-theme-600 text-white">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Route
                </Button>
              </div>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Route ID</TableHead>
                    <TableHead>Route Name</TableHead>
                    <TableHead>Stops</TableHead>
                    <TableHead>Distance</TableHead>
                    <TableHead>Start Time</TableHead>
                    <TableHead>End Time</TableHead>
                    <TableHead>Students</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tamilNaduRoutes.map((route) => (
                    <TableRow key={route.id}>
                      <TableCell className="font-medium">{route.id}</TableCell>
                      <TableCell>{route.name}</TableCell>
                      <TableCell>{route.stops.length} stops</TableCell>
                      <TableCell>{route.distance} km</TableCell>
                      <TableCell>{route.startTime}</TableCell>
                      <TableCell>{route.endTime}</TableCell>
                      <TableCell>{route.students} students</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* Route Details */}
          <Card>
            <CardHeader>
              <CardTitle>Route Details</CardTitle>
              <CardDescription>View detailed information about each route and its stops</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {tamilNaduRoutes.map((route) => (
                  <div key={route.id} className="border rounded-md p-4">
                    <div className="flex justify-between items-center mb-2">
                      <h3 className="font-bold">{route.name}</h3>
                      <Badge variant="outline">{route.students} students</Badge>
                    </div>
                    <div className="text-sm text-muted-foreground mb-2">
                      {route.distance} km • {route.startTime} to {route.endTime}
                    </div>
                    <div className="mt-4">
                      <h4 className="text-sm font-medium mb-2">Stops:</h4>
                      <div className="space-y-2">
                        {route.stops.map((stop, index) => (
                          <div key={index} className="flex items-center">
                            <div
                              className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${
                                index === 0
                                  ? "bg-green-100 text-green-700"
                                  : index === route.stops.length - 1
                                    ? "bg-theme-100 text-theme-700"
                                    : "bg-gray-100 text-gray-700"
                              }`}
                            >
                              {index + 1}
                            </div>
                            <div className="ml-2">{stop}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="drivers" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Drivers</CardTitle>
              <CardDescription>Manage your school transport drivers and their details.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex justify-end mb-4">
                <Button className="bg-theme-500 hover:bg-theme-600 text-white">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Driver
                </Button>
              </div>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Driver ID</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>License No.</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead>Experience</TableHead>
                    <TableHead>Assigned Vehicle</TableHead>
                    <TableHead>Employee ID</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tamilNaduDrivers.map((driver) => (
                    <TableRow key={driver.id}>
                      <TableCell className="font-medium">{driver.id}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Avatar className="h-8 w-8">
                            <AvatarImage
                              src={`/abstract-geometric-shapes.png?height=32&width=32&query=${driver.name}`}
                              alt={driver.name}
                            />
                            <AvatarFallback>{driver.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          {driver.name}
                        </div>
                      </TableCell>
                      <TableCell>{driver.licenseNo}</TableCell>
                      <TableCell>{driver.contact}</TableCell>
                      <TableCell>{driver.experience} years</TableCell>
                      <TableCell>{driver.assignedVehicle}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                          {driver.employeeId}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="default">Active</Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* Driver Details with Payroll Connection */}
          <Card>
            <CardHeader>
              <CardTitle>Driver Payroll Information</CardTitle>
              <CardDescription>View driver payroll details connected to the employee module</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {tamilNaduDrivers.map((driver) => (
                  <div key={driver.id} className="border rounded-md p-4">
                    <div className="flex justify-between items-center mb-2">
                      <div className="flex items-center gap-2">
                        <Avatar className="h-10 w-10">
                          <AvatarImage
                            src={`/abstract-geometric-shapes.png?height=40&width=40&query=${driver.name}`}
                            alt={driver.name}
                          />
                          <AvatarFallback>{driver.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="font-bold">{driver.name}</h3>
                          <div className="text-sm text-muted-foreground">
                            <span className="flex items-center">
                              <User className="h-3 w-3 mr-1" />
                              {driver.employeeId}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-medium">Monthly Salary</div>
                        <div className="text-lg font-bold">₹{driver.salary.toLocaleString()}</div>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-2 mt-4 text-sm">
                      <div>
                        <div className="text-muted-foreground">Joining Date</div>
                        <div>{new Date(driver.joiningDate).toLocaleDateString()}</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Experience</div>
                        <div>{driver.experience} years</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Vehicle Assigned</div>
                        <div className="flex items-center">
                          <Car className="h-3 w-3 mr-1" />
                          {driver.assignedVehicle}
                        </div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Contact</div>
                        <div>{driver.contact}</div>
                      </div>
                    </div>
                    <div className="mt-4 pt-4 border-t flex justify-between">
                      <Button variant="outline" size="sm">
                        View Full Profile
                      </Button>
                      <Button variant="outline" size="sm" className="bg-theme-50 text-theme-700 border-theme-200">
                        View Payroll
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="students" className="space-y-4">
          <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
            <div className="relative w-full md:w-80">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input type="search" placeholder="Search students..." className="w-full pl-8" />
            </div>
            <div className="flex flex-col sm:flex-row w-full md:w-auto gap-2">
              <Select defaultValue="all">
                <SelectTrigger className="w-full sm:w-[180px]">
                  <SelectValue placeholder="Route" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Routes</SelectItem>
                  {tamilNaduRoutes.map((route) => (
                    <SelectItem key={route.id} value={route.id}>
                      {route.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <Card>
            <CardHeader className="py-4">
              <CardTitle>Students Using Transport</CardTitle>
              <CardDescription>Manage students using the school transport service.</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student ID</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Class</TableHead>
                    <TableHead>Route</TableHead>
                    <TableHead>Stop</TableHead>
                    <TableHead>Pickup Time</TableHead>
                    <TableHead>Fee Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tamilNaduStudents.map((student) => (
                    <TableRow key={student.id}>
                      <TableCell className="font-medium">{student.id}</TableCell>
                      <TableCell>{student.name}</TableCell>
                      <TableCell>{student.class}</TableCell>
                      <TableCell>{student.route}</TableCell>
                      <TableCell>{student.stop}</TableCell>
                      <TableCell>{student.pickupTime}</TableCell>
                      <TableCell>
                        <Badge variant={student.feeStatus === "Pending" ? "destructive" : "success"}>
                          {student.feeStatus}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
