"use client"

import { useState } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Search,
  Plus,
  Eye,
  MoreHorizontal,
  Download,
  Printer,
  FileText,
  Mail,
  Phone,
  MapPin,
  Calendar,
} from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function StudentsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [classFilter, setClassFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")
  const [selectedStudent, setSelectedStudent] = useState<any>(null)
  const [isPreviewDialogOpen, setIsPreviewDialogOpen] = useState(false)

  // Sample data
  const students = [
    {
      id: "STU001",
      name: "Rahul Sharma",
      class: "Class X",
      section: "A",
      rollNo: "101",
      gender: "Male",
      status: "active",
      dob: "2008-05-15",
      bloodGroup: "B+",
      address: "123, Green Park, New Delhi",
      phone: "+91 9876543210",
      email: "rahul.s@example.com",
      fatherName: "Rajesh Sharma",
      motherName: "Sunita Sharma",
      admissionNo: "ADM2023101",
      joinDate: "2020-04-01",
    },
    {
      id: "STU002",
      name: "Priya Patel",
      class: "Class VIII",
      section: "B",
      rollNo: "102",
      gender: "Female",
      status: "active",
      dob: "2010-07-22",
      bloodGroup: "O+",
      address: "45, Patel Nagar, Mumbai",
      phone: "+91 8765432109",
      email: "priya.p@example.com",
      fatherName: "Suresh Patel",
      motherName: "Meena Patel",
      admissionNo: "ADM2023102",
      joinDate: "2021-04-05",
    },
    {
      id: "STU003",
      name: "Amit Kumar",
      class: "Class VI",
      section: "A",
      rollNo: "103",
      gender: "Male",
      status: "active",
      dob: "2012-03-10",
      bloodGroup: "A+",
      address: "78, Model Town, Delhi",
      phone: "+91 7654321098",
      email: "amit.k@example.com",
      fatherName: "Vijay Kumar",
      motherName: "Rani Kumar",
      admissionNo: "ADM2023103",
      joinDate: "2022-04-10",
    },
    {
      id: "STU004",
      name: "Sneha Gupta",
      class: "Class XI",
      section: "C",
      rollNo: "104",
      gender: "Female",
      status: "inactive",
      dob: "2007-11-18",
      bloodGroup: "AB+",
      address: "34, Civil Lines, Jaipur",
      phone: "+91 6543210987",
      email: "sneha.g@example.com",
      fatherName: "Rakesh Gupta",
      motherName: "Pooja Gupta",
      admissionNo: "ADM2023104",
      joinDate: "2019-04-15",
    },
    {
      id: "STU005",
      name: "Vikram Singh",
      class: "Class IX",
      section: "B",
      rollNo: "105",
      gender: "Male",
      status: "active",
      dob: "2009-08-25",
      bloodGroup: "B-",
      address: "56, Sector 18, Chandigarh",
      phone: "+91 5432109876",
      email: "vikram.s@example.com",
      fatherName: "Harpreet Singh",
      motherName: "Jaspreet Singh",
      admissionNo: "ADM2023105",
      joinDate: "2020-04-20",
    },
  ]

  const filteredStudents = students.filter((student) => {
    const matchesSearch =
      student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.rollNo.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesClass = classFilter === "all" || student.class === classFilter
    const matchesStatus = statusFilter === "all" || student.status === statusFilter

    return matchesSearch && matchesClass && matchesStatus
  })

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-500">Active</Badge>
      case "inactive":
        return <Badge className="bg-gray-500">Inactive</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
  }

  const handlePreviewStudent = (student: any) => {
    setSelectedStudent(student)
    setIsPreviewDialogOpen(true)
  }

  const handlePrintStudent = (student: any) => {
    // In a real application, this would open a print dialog with formatted student data
    alert(`Printing student record for ${student.name}`)
  }

  const handleDownloadStudent = (student: any) => {
    // In a real application, this would download a PDF or other format of student data
    alert(`Downloading student record for ${student.name}`)
  }

  return (
    <PageTemplate
      title="Students"
      description="View and manage all students"
      breadcrumbs={[
        { title: "Student Manager", href: "/dashboard/students" },
        { title: "Students", href: "/dashboard/students", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Add Student",
        icon: <Plus className="mr-2 h-4 w-4" />,
        href: "/dashboard/students/add",
      }}
    >
      <Card>
        <CardHeader className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
          <CardTitle>All Students</CardTitle>
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search students..."
                className="pl-8 w-full sm:w-[250px]"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select value={classFilter} onValueChange={setClassFilter}>
              <SelectTrigger className="w-full sm:w-[150px]">
                <SelectValue placeholder="Filter by class" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Classes</SelectItem>
                <SelectItem value="Class VI">Class VI</SelectItem>
                <SelectItem value="Class VII">Class VII</SelectItem>
                <SelectItem value="Class VIII">Class VIII</SelectItem>
                <SelectItem value="Class IX">Class IX</SelectItem>
                <SelectItem value="Class X">Class X</SelectItem>
                <SelectItem value="Class XI">Class XI</SelectItem>
                <SelectItem value="Class XII">Class XII</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-[150px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Class</TableHead>
                  <TableHead className="hidden md:table-cell">Section</TableHead>
                  <TableHead className="hidden md:table-cell">Roll No</TableHead>
                  <TableHead className="hidden md:table-cell">Gender</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredStudents.map((student) => (
                  <TableRow key={student.id}>
                    <TableCell className="font-medium">{student.id}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Avatar className="h-8 w-8">
                          <AvatarImage
                            src={`/abstract-geometric-shapes.png?height=32&width=32&query=${student.name}`}
                            alt={student.name}
                          />
                          <AvatarFallback>{getInitials(student.name)}</AvatarFallback>
                        </Avatar>
                        <span>{student.name}</span>
                      </div>
                    </TableCell>
                    <TableCell>{student.class}</TableCell>
                    <TableCell className="hidden md:table-cell">{student.section}</TableCell>
                    <TableCell className="hidden md:table-cell">{student.rollNo}</TableCell>
                    <TableCell className="hidden md:table-cell">{student.gender}</TableCell>
                    <TableCell>{getStatusBadge(student.status)}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <DropdownMenuItem onClick={() => handlePreviewStudent(student)}>
                            <Eye className="mr-2 h-4 w-4" />
                            Preview
                          </DropdownMenuItem>
                          <DropdownMenuItem asChild>
                            <a href={`/dashboard/student-profile?id=${student.id}`}>
                              <FileText className="mr-2 h-4 w-4" />
                              View Full Profile
                            </a>
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => handlePrintStudent(student)}>
                            <Printer className="mr-2 h-4 w-4" />
                            Print
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleDownloadStudent(student)}>
                            <Download className="mr-2 h-4 w-4" />
                            Download
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Student Preview Dialog */}
      <Dialog open={isPreviewDialogOpen} onOpenChange={setIsPreviewDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Student Preview</DialogTitle>
            <DialogDescription>Quick view of student information</DialogDescription>
          </DialogHeader>
          {selectedStudent && (
            <div className="space-y-4">
              <div className="flex items-center space-x-4 mb-4">
                <Avatar className="h-16 w-16">
                  <AvatarImage
                    src={`/abstract-geometric-shapes.png?height=64&width=64&query=${selectedStudent.name}`}
                    alt={selectedStudent.name}
                  />
                  <AvatarFallback>{getInitials(selectedStudent.name)}</AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="text-lg font-bold">{selectedStudent.name}</h3>
                  <p className="text-sm text-muted-foreground">
                    {selectedStudent.class} - {selectedStudent.section} | Roll No: {selectedStudent.rollNo}
                  </p>
                  <div className="mt-1">{getStatusBadge(selectedStudent.status)}</div>
                </div>
              </div>

              <Tabs defaultValue="basic" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="basic">Basic Info</TabsTrigger>
                  <TabsTrigger value="contact">Contact Details</TabsTrigger>
                </TabsList>
                <TabsContent value="basic" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">Admission No</h3>
                      <p>{selectedStudent.admissionNo}</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">Join Date</h3>
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-1 text-muted-foreground" />
                        <p>{new Date(selectedStudent.joinDate).toLocaleDateString()}</p>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">Date of Birth</h3>
                      <p>{new Date(selectedStudent.dob).toLocaleDateString()}</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">Blood Group</h3>
                      <p>{selectedStudent.bloodGroup}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">Father's Name</h3>
                      <p>{selectedStudent.fatherName}</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">Mother's Name</h3>
                      <p>{selectedStudent.motherName}</p>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="contact" className="space-y-4">
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Email</h3>
                    <div className="flex items-center">
                      <Mail className="h-4 w-4 mr-2 text-muted-foreground" />
                      <p>{selectedStudent.email}</p>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Phone</h3>
                    <div className="flex items-center">
                      <Phone className="h-4 w-4 mr-2 text-muted-foreground" />
                      <p>{selectedStudent.phone}</p>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Address</h3>
                    <div className="flex items-start">
                      <MapPin className="h-4 w-4 mr-2 text-muted-foreground mt-1" />
                      <p>{selectedStudent.address}</p>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          )}
          <DialogFooter className="flex justify-between">
            <Button variant="outline" onClick={() => setIsPreviewDialogOpen(false)}>
              Close
            </Button>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => selectedStudent && handlePrintStudent(selectedStudent)}>
                <Printer className="mr-2 h-4 w-4" />
                Print
              </Button>
              <Button variant="outline" onClick={() => selectedStudent && handleDownloadStudent(selectedStudent)}>
                <Download className="mr-2 h-4 w-4" />
                Download
              </Button>
              <Button className="bg-theme-500 hover:bg-theme-600" asChild>
                <a href={`/dashboard/student-profile?id=${selectedStudent?.id}`}>
                  <Eye className="mr-2 h-4 w-4" />
                  View Full Profile
                </a>
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageTemplate>
  )
}
