"use client"

import { useState } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Download, Filter, Plus, FileText, Car } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function PayrollPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [departmentFilter, setDepartmentFilter] = useState("all")
  const [monthFilter, setMonthFilter] = useState("current")

  // Sample payroll data
  const payrollData = [
    {
      id: "PAY001",
      employeeId: "EMP001",
      name: "Dr. Rajesh Patel",
      department: "Science",
      designation: "Senior Teacher",
      basicSalary: 65000,
      allowances: 15000,
      deductions: 8000,
      netSalary: 72000,
      paymentDate: "2023-04-28",
      status: "paid",
    },
    {
      id: "PAY002",
      employeeId: "EMP002",
      name: "Mrs. Sunita Sharma",
      department: "Mathematics",
      designation: "HOD",
      basicSalary: 70000,
      allowances: 18000,
      deductions: 9000,
      netSalary: 79000,
      paymentDate: "2023-04-28",
      status: "paid",
    },
    {
      id: "PAY003",
      employeeId: "EMP003",
      name: "Mr. Amit Verma",
      department: "English",
      designation: "Teacher",
      basicSalary: 55000,
      allowances: 12000,
      deductions: 7000,
      netSalary: 60000,
      paymentDate: "2023-04-28",
      status: "paid",
    },
    {
      id: "PAY004",
      employeeId: "EMP004",
      name: "Mrs. Priya Gupta",
      department: "Social Studies",
      designation: "Teacher",
      basicSalary: 55000,
      allowances: 12000,
      deductions: 7000,
      netSalary: 60000,
      paymentDate: "2023-04-28",
      status: "paid",
    },
    {
      id: "PAY005",
      employeeId: "EMP005",
      name: "Mr. Vikram Singh",
      department: "Physical Education",
      designation: "Sports Coach",
      basicSalary: 50000,
      allowances: 10000,
      deductions: 6000,
      netSalary: 54000,
      paymentDate: "2023-04-28",
      status: "paid",
    },
    // Add transport staff payroll
    {
      id: "PAY101",
      employeeId: "EMP101",
      name: "Murugan Selvaraj",
      department: "Transport",
      designation: "Driver",
      basicSalary: 28000,
      allowances: 5000,
      deductions: 3000,
      netSalary: 30000,
      paymentDate: "2023-04-28",
      status: "paid",
      transportId: "DRV-101",
      vehicle: "BUS-101",
    },
    {
      id: "PAY102",
      employeeId: "EMP102",
      name: "Senthil Kumar",
      department: "Transport",
      designation: "Driver",
      basicSalary: 25000,
      allowances: 4500,
      deductions: 2800,
      netSalary: 26700,
      paymentDate: "2023-04-28",
      status: "paid",
      transportId: "DRV-102",
      vehicle: "BUS-102",
    },
    {
      id: "PAY103",
      employeeId: "EMP103",
      name: "Karthik Rajan",
      department: "Transport",
      designation: "Driver",
      basicSalary: 32000,
      allowances: 6000,
      deductions: 3500,
      netSalary: 34500,
      paymentDate: "2023-04-28",
      status: "paid",
      transportId: "DRV-103",
      vehicle: "BUS-103",
    },
    {
      id: "PAY104",
      employeeId: "EMP104",
      name: "Vijay Prakash",
      department: "Transport",
      designation: "Driver",
      basicSalary: 26000,
      allowances: 4800,
      deductions: 2900,
      netSalary: 27900,
      paymentDate: "2023-04-28",
      status: "paid",
      transportId: "DRV-104",
      vehicle: "BUS-104",
    },
    {
      id: "PAY105",
      employeeId: "EMP105",
      name: "Ramesh Chandran",
      department: "Transport",
      designation: "Driver",
      basicSalary: 30000,
      allowances: 5500,
      deductions: 3200,
      netSalary: 32300,
      paymentDate: "2023-04-28",
      status: "paid",
      transportId: "DRV-105",
      vehicle: "BUS-105",
    },
  ]

  const filteredPayroll = payrollData.filter((record) => {
    const matchesSearch =
      record.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      record.employeeId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      record.id.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesDepartment = departmentFilter === "all" || record.department === departmentFilter

    return matchesSearch && matchesDepartment
  })

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "paid":
        return <Badge className="bg-green-500">Paid</Badge>
      case "pending":
        return <Badge className="bg-amber-500">Pending</Badge>
      case "failed":
        return <Badge className="bg-red-500">Failed</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
  }

  // Calculate department totals
  const departmentTotals = payrollData.reduce(
    (acc, record) => {
      const dept = record.department
      if (!acc[dept]) {
        acc[dept] = {
          count: 0,
          totalSalary: 0,
        }
      }
      acc[dept].count += 1
      acc[dept].totalSalary += record.netSalary
      return acc
    },
    {} as Record<string, { count: number; totalSalary: number }>,
  )

  return (
    <PageTemplate
      title="Payroll"
      description="Manage employee salaries and payroll processing"
      breadcrumbs={[
        { title: "Employee Module", href: "/dashboard/staff" },
        { title: "Payroll", href: "/dashboard/payroll", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Process Payroll",
        icon: <Plus className="mr-2 h-4 w-4" />,
        href: "/dashboard/payroll/process",
      }}
    >
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Employees</CardTitle>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              className="h-4 w-4 text-muted-foreground"
            >
              <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
              <path d="M16 3.13a4 4 0 0 1 0 7.75" />
            </svg>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{payrollData.length}</div>
            <p className="text-xs text-muted-foreground">
              {payrollData.filter((p) => p.department !== "Transport").length} Teaching,{" "}
              {payrollData.filter((p) => p.department === "Transport").length} Transport
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Salary Paid</CardTitle>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              className="h-4 w-4 text-muted-foreground"
            >
              <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
            </svg>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ₹{payrollData.reduce((sum, record) => sum + record.netSalary, 0).toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground">For the current month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Salary</CardTitle>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              className="h-4 w-4 text-muted-foreground"
            >
              <path d="M16 16v1a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h2m5.66 0H14a2 2 0 0 1 2 2v3.34" />
              <path d="M14 3v4a2 2 0 0 0 2 2h4" />
              <path d="M5 12h14" />
              <path d="M12 5v14" />
            </svg>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ₹
              {Math.round(
                payrollData.reduce((sum, record) => sum + record.netSalary, 0) / payrollData.length,
              ).toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground">Per employee</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Transport Staff</CardTitle>
            <Car className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{payrollData.filter((p) => p.department === "Transport").length}</div>
            <p className="text-xs text-muted-foreground">
              ₹
              {payrollData
                .filter((p) => p.department === "Transport")
                .reduce((sum, record) => sum + record.netSalary, 0)
                .toLocaleString()}{" "}
              total
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="payroll" className="mt-6">
        <TabsList>
          <TabsTrigger value="payroll">Payroll Records</TabsTrigger>
          <TabsTrigger value="departments">Department Summary</TabsTrigger>
          <TabsTrigger value="history">Payment History</TabsTrigger>
        </TabsList>
        <TabsContent value="payroll" className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search payroll..."
                  className="pl-8 w-full sm:w-[250px]"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
                <SelectTrigger className="w-full sm:w-[180px]">
                  <SelectValue placeholder="Filter by department" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Departments</SelectItem>
                  <SelectItem value="Science">Science</SelectItem>
                  <SelectItem value="Mathematics">Mathematics</SelectItem>
                  <SelectItem value="English">English</SelectItem>
                  <SelectItem value="Social Studies">Social Studies</SelectItem>
                  <SelectItem value="Physical Education">Physical Education</SelectItem>
                  <SelectItem value="Transport">Transport</SelectItem>
                </SelectContent>
              </Select>
              <Select value={monthFilter} onValueChange={setMonthFilter}>
                <SelectTrigger className="w-full sm:w-[150px]">
                  <SelectValue placeholder="Month" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="current">Current Month</SelectItem>
                  <SelectItem value="previous">Previous Month</SelectItem>
                  <SelectItem value="custom">Custom Range</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <Filter className="mr-2 h-4 w-4" />
                Filter
              </Button>
              <Button variant="outline" size="sm">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
            </div>
          </div>

          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Employee</TableHead>
                    <TableHead>Department</TableHead>
                    <TableHead className="hidden md:table-cell">Basic Salary</TableHead>
                    <TableHead className="hidden md:table-cell">Allowances</TableHead>
                    <TableHead className="hidden md:table-cell">Deductions</TableHead>
                    <TableHead>Net Salary</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPayroll.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell className="font-medium">{record.id}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Avatar className="h-8 w-8">
                            <AvatarImage
                              src={`/abstract-geometric-shapes.png?key=bcn3k&height=32&width=32&query=${record.name}`}
                              alt={record.name}
                            />
                            <AvatarFallback>{getInitials(record.name)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="font-medium">{record.name}</div>
                            <div className="text-xs text-muted-foreground">{record.employeeId}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          {record.department}
                          {record.department === "Transport" && record.vehicle && (
                            <Badge variant="outline" className="ml-2 bg-blue-50 text-blue-700 border-blue-200">
                              <Car className="h-3 w-3 mr-1" />
                              {record.vehicle}
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="hidden md:table-cell">₹{record.basicSalary.toLocaleString()}</TableCell>
                      <TableCell className="hidden md:table-cell">₹{record.allowances.toLocaleString()}</TableCell>
                      <TableCell className="hidden md:table-cell">₹{record.deductions.toLocaleString()}</TableCell>
                      <TableCell>₹{record.netSalary.toLocaleString()}</TableCell>
                      <TableCell>{getStatusBadge(record.status)}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          <FileText className="mr-2 h-4 w-4" />
                          Slip
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="departments">
          <Card>
            <CardHeader>
              <CardTitle>Department Salary Summary</CardTitle>
              <CardDescription>Overview of salary distribution by department</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Department</TableHead>
                    <TableHead>Employees</TableHead>
                    <TableHead>Total Salary</TableHead>
                    <TableHead>Average Salary</TableHead>
                    <TableHead>% of Budget</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {Object.entries(departmentTotals).map(([department, data]) => (
                    <TableRow key={department}>
                      <TableCell className="font-medium">{department}</TableCell>
                      <TableCell>{data.count}</TableCell>
                      <TableCell>₹{data.totalSalary.toLocaleString()}</TableCell>
                      <TableCell>₹{Math.round(data.totalSalary / data.count).toLocaleString()}</TableCell>
                      <TableCell>
                        {Math.round(
                          (data.totalSalary / payrollData.reduce((sum, record) => sum + record.netSalary, 0)) * 100,
                        )}
                        %
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle>Payment History</CardTitle>
              <CardDescription>Record of all salary payments</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-10 text-muted-foreground">
                <p>Payment history will be displayed here</p>
                <p className="text-sm">Select a different month to view historical data</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </PageTemplate>
  )
}
