"use client"

import { useState } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { PlusCircle, Download, FileText, Search, TrendingDown, Building, BookOpen, Utensils } from "lucide-react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

// Sample data for charts
const monthlyExpensesData = [
  { month: "Jan", amount: 320000 },
  { month: "Feb", amount: 380000 },
  { month: "Mar", amount: 350000 },
  { month: "Apr", amount: 410000 },
  { month: "May", amount: 420000 },
  { month: "Jun", amount: 450000 },
]

const expenseCategoryData = [
  { name: "Salaries", value: 250000, color: "#8b5cf6" },
  { name: "Maintenance", value: 80000, color: "#ec4899" },
  { name: "Utilities", value: 45000, color: "#14b8a6" },
  { name: "Academic", value: 35000, color: "#f59e0b" },
  { name: "Administrative", value: 25000, color: "#6366f1" },
  { name: "Others", value: 15000, color: "#8b5cf6" },
]

const COLORS = ["#8b5cf6", "#ec4899", "#14b8a6", "#f59e0b", "#6366f1", "#8b5cf6"]

const expensesData = [
  {
    id: "EXP001",
    date: "2023-05-16",
    description: "Staff Salary - May 2023",
    category: "Salary",
    account: "Salary Account",
    amount: 250000,
    paymentMethod: "Bank Transfer",
    status: "completed",
    reference: "SAL-052023",
  },
  {
    id: "EXP002",
    date: "2023-05-18",
    description: "Library Books Purchase",
    category: "Academic",
    account: "Development Fund",
    amount: 45000,
    paymentMethod: "Cheque",
    status: "completed",
    reference: "PO-LIB-052023",
  },
  {
    id: "EXP003",
    date: "2023-05-22",
    description: "Electricity Bill - May 2023",
    category: "Utility",
    account: "Operating Account",
    amount: 35000,
    paymentMethod: "Online",
    status: "completed",
    reference: "UTIL-EB-052023",
  },
  {
    id: "EXP004",
    date: "2023-05-24",
    description: "Office Supplies",
    category: "Administrative",
    account: "Operating Account",
    amount: 12000,
    paymentMethod: "Cash",
    status: "completed",
    reference: "ADM-OS-052023",
  },
  {
    id: "EXP005",
    date: "2023-05-25",
    description: "Building Repairs",
    category: "Maintenance",
    account: "Operating Account",
    amount: 28000,
    paymentMethod: "Cheque",
    status: "completed",
    reference: "MAINT-BR-052023",
  },
  {
    id: "EXP006",
    date: "2023-05-26",
    description: "Internet Bill - May 2023",
    category: "Utility",
    account: "Operating Account",
    amount: 8000,
    paymentMethod: "Online",
    status: "completed",
    reference: "UTIL-INT-052023",
  },
  {
    id: "EXP007",
    date: "2023-05-28",
    description: "Campus Cleaning Services",
    category: "Maintenance",
    account: "Operating Account",
    amount: 15000,
    paymentMethod: "Bank Transfer",
    status: "completed",
    reference: "MAINT-CL-052023",
  },
]

export default function ExpensesPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [dateRange, setDateRange] = useState("this-month")

  const filteredExpenses = expensesData.filter((expense) => {
    const matchesSearch =
      expense.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      expense.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      expense.reference.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesCategory = categoryFilter === "all" || expense.category === categoryFilter

    return matchesSearch && matchesCategory
  })

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(amount)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-500">Completed</Badge>
      case "pending":
        return <Badge className="bg-yellow-500">Pending</Badge>
      case "cancelled":
        return <Badge className="bg-red-500">Cancelled</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  return (
    <PageTemplate
      title="Expenses"
      description="Track and manage school expenses"
      breadcrumbs={[
        { title: "Dashboard", href: "/dashboard" },
        { title: "General Accounting", href: "/dashboard/accounts" },
        { title: "Expenses", href: "/dashboard/expenses", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Add Expense",
        icon: <PlusCircle className="mr-2 h-4 w-4" />,
        href: "#",
      }}
    >
      <div className="grid gap-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Expenses</CardTitle>
              <TrendingDown className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹4,50,000</div>
              <p className="text-xs text-red-500">+7.1% from last month</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Salary Expenses</CardTitle>
              <Building className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹2,50,000</div>
              <p className="text-xs text-muted-foreground">55.6% of total expenses</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Academic Expenses</CardTitle>
              <BookOpen className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹80,000</div>
              <p className="text-xs text-muted-foreground">17.8% of total expenses</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Maintenance Expenses</CardTitle>
              <Utensils className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹43,000</div>
              <p className="text-xs text-muted-foreground">9.6% of total expenses</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Monthly Expenses</CardTitle>
              <CardDescription>Expense trend for the last 6 months</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={monthlyExpensesData}
                    margin={{
                      top: 20,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip
                      formatter={(value) => formatCurrency(value as number)}
                      labelFormatter={(label) => `Month: ${label}`}
                    />
                    <Legend />
                    <Bar dataKey="amount" name="Expenses" fill="#ec4899" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Expense Categories</CardTitle>
              <CardDescription>Distribution by category</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={expenseCategoryData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {expenseCategoryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => formatCurrency(value as number)} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
              <Button variant="outline" size="sm">
                <FileText className="mr-2 h-4 w-4" />
                Print
              </Button>
            </div>
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search expenses..."
                  className="pl-8 w-full sm:w-[250px]"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-full sm:w-[180px]">
                  <SelectValue placeholder="Filter by category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="Salary">Salary</SelectItem>
                  <SelectItem value="Academic">Academic</SelectItem>
                  <SelectItem value="Utility">Utility</SelectItem>
                  <SelectItem value="Maintenance">Maintenance</SelectItem>
                  <SelectItem value="Administrative">Administrative</SelectItem>
                </SelectContent>
              </Select>
              <Select value={dateRange} onValueChange={setDateRange}>
                <SelectTrigger className="w-full sm:w-[180px]">
                  <SelectValue placeholder="Date range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="this-week">This Week</SelectItem>
                  <SelectItem value="this-month">This Month</SelectItem>
                  <SelectItem value="last-month">Last Month</SelectItem>
                  <SelectItem value="custom">Custom Range</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Account</TableHead>
                    <TableHead>Payment Method</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Amount</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredExpenses.map((expense) => (
                    <TableRow key={expense.id}>
                      <TableCell className="font-medium">{expense.id}</TableCell>
                      <TableCell>{new Date(expense.date).toLocaleDateString()}</TableCell>
                      <TableCell>{expense.description}</TableCell>
                      <TableCell>{expense.category}</TableCell>
                      <TableCell>{expense.account}</TableCell>
                      <TableCell>{expense.paymentMethod}</TableCell>
                      <TableCell>{getStatusBadge(expense.status)}</TableCell>
                      <TableCell className="text-right font-medium text-red-600">
                        -{formatCurrency(expense.amount)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageTemplate>
  )
}
