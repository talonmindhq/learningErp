"use client"

import { useState } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Search,
  Plus,
  Phone,
  Mail,
  Calendar,
  MoreHorizontal,
  Eye,
  Edit,
  Trash2,
  Download,
  MessageSquare,
  AlertTriangle,
  CheckCircle,
  Clock,
  X,
  Save,
} from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { CalendarIcon } from "@radix-ui/react-icons"

export default function EnquiriesPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [selectedEnquiry, setSelectedEnquiry] = useState<any>(null)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isStatusDialogOpen, setIsStatusDialogOpen] = useState(false)
  const [isFollowUpDialogOpen, setIsFollowUpDialogOpen] = useState(false)
  const [followUpDate, setFollowUpDate] = useState<Date | undefined>(new Date())
  const [followUpNotes, setFollowUpNotes] = useState("")
  const [editFormData, setEditFormData] = useState({
    name: "",
    phone: "",
    email: "",
    course: "",
    source: "",
    message: "",
  })
  const { toast } = useToast()

  // Sample data
  const [enquiries, setEnquiries] = useState([
    {
      id: "ENQ001",
      name: "Rahul Sharma",
      phone: "+91 9876543210",
      email: "rahul.s@example.com",
      date: "2023-05-15",
      course: "Class X",
      status: "new",
      source: "Website",
      message:
        "Interested in admission for the next academic year. Would like to know about the fee structure and admission process.",
      followUpDate: "2023-05-20",
      followUps: [],
    },
    {
      id: "ENQ002",
      name: "Priya Patel",
      phone: "+91 8765432109",
      email: "priya.p@example.com",
      date: "2023-05-14",
      course: "Class VIII",
      status: "contacted",
      source: "Phone Call",
      message: "Parent called to inquire about available seats in Class VIII. Wants to schedule a school visit.",
      followUpDate: "2023-05-18",
      followUps: [
        {
          date: "2023-05-16",
          notes: "Called parent to provide information about available seats. They will visit the school on Friday.",
        },
      ],
    },
    {
      id: "ENQ003",
      name: "Amit Kumar",
      phone: "+91 7654321098",
      email: "amit.k@example.com",
      date: "2023-05-12",
      course: "Class VI",
      status: "followup",
      source: "Referral",
      message:
        "Referred by Mr. Verma (parent of a current student). Interested in knowing about the curriculum and extracurricular activities.",
      followUpDate: "2023-05-16",
      followUps: [
        {
          date: "2023-05-14",
          notes: "Sent curriculum details via email. Will follow up in 2 days.",
        },
      ],
    },
    {
      id: "ENQ004",
      name: "Sneha Gupta",
      phone: "+91 6543210987",
      email: "sneha.g@example.com",
      date: "2023-05-10",
      course: "Class XI",
      status: "converted",
      source: "School Visit",
      message: "Visited the school and met with the principal. Very interested in the science program.",
      followUpDate: "2023-05-15",
      followUps: [
        {
          date: "2023-05-12",
          notes: "Provided tour of science labs. Parent was impressed and requested admission forms.",
        },
        {
          date: "2023-05-15",
          notes: "Admission forms submitted. Converting to application.",
        },
      ],
    },
    {
      id: "ENQ005",
      name: "Vikram Singh",
      phone: "+91 5432109876",
      email: "vikram.s@example.com",
      date: "2023-05-08",
      course: "Class IX",
      status: "closed",
      source: "Email",
      message:
        "Sent an email inquiry about transfer admission from another school. Concerned about the transition process.",
      followUpDate: "2023-05-12",
      followUps: [
        {
          date: "2023-05-10",
          notes: "Explained transfer process. Parent decided to continue with current school.",
        },
      ],
    },
  ])

  const filteredEnquiries = enquiries.filter((enquiry) => {
    const matchesSearch =
      enquiry.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      enquiry.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      enquiry.id.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesStatus = statusFilter === "all" || enquiry.status === statusFilter

    return matchesSearch && matchesStatus
  })

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "new":
        return <Badge className="bg-blue-500">New</Badge>
      case "contacted":
        return <Badge className="bg-purple-500">Contacted</Badge>
      case "followup":
        return <Badge className="bg-amber-500">Follow Up</Badge>
      case "converted":
        return <Badge className="bg-green-500">Converted</Badge>
      case "closed":
        return <Badge className="bg-gray-500">Closed</Badge>
      case "cancelled":
        return <Badge className="bg-red-500">Cancelled</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  const handleViewEnquiry = (enquiry: any) => {
    setSelectedEnquiry(enquiry)
    setIsViewDialogOpen(true)
  }

  const handleEditEnquiry = (enquiry: any) => {
    setSelectedEnquiry(enquiry)
    setEditFormData({
      name: enquiry.name,
      phone: enquiry.phone,
      email: enquiry.email,
      course: enquiry.course,
      source: enquiry.source,
      message: enquiry.message,
    })
    setIsEditDialogOpen(true)
  }

  const handleDeleteEnquiry = (enquiry: any) => {
    setSelectedEnquiry(enquiry)
    setIsDeleteDialogOpen(true)
  }

  const handleStatusChange = (enquiry: any) => {
    setSelectedEnquiry(enquiry)
    setIsStatusDialogOpen(true)
  }

  const handleFollowUp = (enquiry: any) => {
    setSelectedEnquiry(enquiry)
    setFollowUpDate(new Date())
    setFollowUpNotes("")
    setIsFollowUpDialogOpen(true)
  }

  const confirmDelete = () => {
    if (selectedEnquiry) {
      const updatedEnquiries = enquiries.filter((enquiry) => enquiry.id !== selectedEnquiry.id)
      setEnquiries(updatedEnquiries)
      setIsDeleteDialogOpen(false)
      toast({
        title: "Enquiry Deleted",
        description: `Enquiry ${selectedEnquiry.id} has been deleted successfully.`,
      })
    }
  }

  const saveEditChanges = () => {
    if (selectedEnquiry) {
      const updatedEnquiries = enquiries.map((enquiry) => {
        if (enquiry.id === selectedEnquiry.id) {
          return {
            ...enquiry,
            name: editFormData.name,
            phone: editFormData.phone,
            email: editFormData.email,
            course: editFormData.course,
            source: editFormData.source,
            message: editFormData.message,
          }
        }
        return enquiry
      })
      setEnquiries(updatedEnquiries)
      setIsEditDialogOpen(false)
      toast({
        title: "Enquiry Updated",
        description: `Enquiry ${selectedEnquiry.id} has been updated successfully.`,
      })
    }
  }

  const updateStatus = (newStatus: string) => {
    if (selectedEnquiry) {
      const updatedEnquiries = enquiries.map((enquiry) => {
        if (enquiry.id === selectedEnquiry.id) {
          return {
            ...enquiry,
            status: newStatus,
          }
        }
        return enquiry
      })
      setEnquiries(updatedEnquiries)
      setIsStatusDialogOpen(false)
      toast({
        title: "Status Updated",
        description: `Enquiry status changed to ${newStatus}.`,
      })
    }
  }

  const addFollowUp = () => {
    if (selectedEnquiry && followUpDate) {
      const newFollowUp = {
        date: format(followUpDate, "yyyy-MM-dd"),
        notes: followUpNotes,
      }

      const updatedEnquiries = enquiries.map((enquiry) => {
        if (enquiry.id === selectedEnquiry.id) {
          return {
            ...enquiry,
            status: "followup",
            followUpDate: format(followUpDate, "yyyy-MM-dd"),
            followUps: [...(enquiry.followUps || []), newFollowUp],
          }
        }
        return enquiry
      })
      setEnquiries(updatedEnquiries)
      setIsFollowUpDialogOpen(false)
      toast({
        title: "Follow-up Added",
        description: `Follow-up scheduled for ${format(followUpDate, "PPP")}.`,
      })
    }
  }

  return (
    <PageTemplate
      title="Enquiries"
      description="Manage student enquiries and follow-ups"
      breadcrumbs={[
        { title: "Enquiry & Admission", href: "/dashboard/enquiries" },
        { title: "Enquiries", href: "/dashboard/enquiries", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Add Enquiry",
        icon: <Plus className="mr-2 h-4 w-4" />,
        href: "/dashboard/enquiries/add",
      }}
    >
      <Card>
        <CardHeader className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
          <CardTitle>All Enquiries</CardTitle>
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search enquiries..."
                className="pl-8 w-full sm:w-[250px]"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-[150px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="new">New</SelectItem>
                <SelectItem value="contacted">Contacted</SelectItem>
                <SelectItem value="followup">Follow Up</SelectItem>
                <SelectItem value="converted">Converted</SelectItem>
                <SelectItem value="closed">Closed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead className="hidden md:table-cell">Contact</TableHead>
                  <TableHead className="hidden md:table-cell">Date</TableHead>
                  <TableHead className="hidden md:table-cell">Course</TableHead>
                  <TableHead className="hidden md:table-cell">Source</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredEnquiries.map((enquiry) => (
                  <TableRow key={enquiry.id}>
                    <TableCell className="font-medium">{enquiry.id}</TableCell>
                    <TableCell>{enquiry.name}</TableCell>
                    <TableCell className="hidden md:table-cell">
                      <div className="flex flex-col">
                        <div className="flex items-center text-xs text-muted-foreground">
                          <Phone className="mr-1 h-3 w-3" />
                          {enquiry.phone}
                        </div>
                        <div className="flex items-center text-xs text-muted-foreground mt-1">
                          <Mail className="mr-1 h-3 w-3" />
                          {enquiry.email}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      <div className="flex items-center">
                        <Calendar className="mr-1 h-3 w-3 text-muted-foreground" />
                        <span className="text-xs text-muted-foreground">
                          {new Date(enquiry.date).toLocaleDateString()}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">{enquiry.course}</TableCell>
                    <TableCell className="hidden md:table-cell">{enquiry.source}</TableCell>
                    <TableCell>{getStatusBadge(enquiry.status)}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <DropdownMenuItem onClick={() => handleViewEnquiry(enquiry)}>
                            <Eye className="mr-2 h-4 w-4" />
                            View Details
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleEditEnquiry(enquiry)}>
                            <Edit className="mr-2 h-4 w-4" />
                            Edit Enquiry
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleFollowUp(enquiry)}>
                            <MessageSquare className="mr-2 h-4 w-4" />
                            Add Follow-up
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => handleStatusChange(enquiry)}>
                            <CheckCircle className="mr-2 h-4 w-4" />
                            Change Status
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>
                            <Download className="mr-2 h-4 w-4" />
                            Export
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-red-600" onClick={() => handleDeleteEnquiry(enquiry)}>
                            <Trash2 className="mr-2 h-4 w-4" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* View Enquiry Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Enquiry Details</DialogTitle>
            <DialogDescription>View complete information about this enquiry</DialogDescription>
          </DialogHeader>
          {selectedEnquiry && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Enquiry ID</h3>
                  <p className="font-medium">{selectedEnquiry.id}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Status</h3>
                  <div>{getStatusBadge(selectedEnquiry.status)}</div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Name</h3>
                  <p>{selectedEnquiry.name}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Course</h3>
                  <p>{selectedEnquiry.course}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Phone</h3>
                  <p>{selectedEnquiry.phone}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Email</h3>
                  <p>{selectedEnquiry.email}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Enquiry Date</h3>
                  <p>{new Date(selectedEnquiry.date).toLocaleDateString()}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Follow-up Date</h3>
                  <p>{new Date(selectedEnquiry.followUpDate).toLocaleDateString()}</p>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Source</h3>
                <p>{selectedEnquiry.source}</p>
              </div>

              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Message</h3>
                <p className="text-sm">{selectedEnquiry.message}</p>
              </div>

              {selectedEnquiry.followUps && selectedEnquiry.followUps.length > 0 && (
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Follow-up History</h3>
                  <div className="space-y-2 mt-2">
                    {selectedEnquiry.followUps.map((followUp: any, index: number) => (
                      <div key={index} className="border rounded-md p-3 text-sm">
                        <div className="flex items-center text-xs text-muted-foreground mb-1">
                          <Calendar className="mr-1 h-3 w-3" />
                          {new Date(followUp.date).toLocaleDateString()}
                        </div>
                        <p>{followUp.notes}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
          <DialogFooter className="flex justify-between">
            <DialogClose asChild>
              <Button variant="outline">Close</Button>
            </DialogClose>
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => {
                  setIsViewDialogOpen(false)
                  handleFollowUp(selectedEnquiry)
                }}
              >
                <MessageSquare className="mr-2 h-4 w-4" />
                Add Follow-up
              </Button>
              <Button
                className="bg-theme-500 hover:bg-theme-600"
                onClick={() => {
                  setIsViewDialogOpen(false)
                  handleEditEnquiry(selectedEnquiry)
                }}
              >
                <Edit className="mr-2 h-4 w-4" />
                Edit
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Enquiry Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Edit Enquiry</DialogTitle>
            <DialogDescription>Update enquiry information</DialogDescription>
          </DialogHeader>
          {selectedEnquiry && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-name">Name</Label>
                  <Input
                    id="edit-name"
                    value={editFormData.name}
                    onChange={(e) => setEditFormData({ ...editFormData, name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-course">Course</Label>
                  <Select
                    value={editFormData.course}
                    onValueChange={(value) => setEditFormData({ ...editFormData, course: value })}
                  >
                    <SelectTrigger id="edit-course">
                      <SelectValue placeholder="Select class" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Class I">Class I</SelectItem>
                      <SelectItem value="Class II">Class II</SelectItem>
                      <SelectItem value="Class III">Class III</SelectItem>
                      <SelectItem value="Class IV">Class IV</SelectItem>
                      <SelectItem value="Class V">Class V</SelectItem>
                      <SelectItem value="Class VI">Class VI</SelectItem>
                      <SelectItem value="Class VII">Class VII</SelectItem>
                      <SelectItem value="Class VIII">Class VIII</SelectItem>
                      <SelectItem value="Class IX">Class IX</SelectItem>
                      <SelectItem value="Class X">Class X</SelectItem>
                      <SelectItem value="Class XI">Class XI</SelectItem>
                      <SelectItem value="Class XII">Class XII</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-phone">Phone</Label>
                  <Input
                    id="edit-phone"
                    value={editFormData.phone}
                    onChange={(e) => setEditFormData({ ...editFormData, phone: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-email">Email</Label>
                  <Input
                    id="edit-email"
                    type="email"
                    value={editFormData.email}
                    onChange={(e) => setEditFormData({ ...editFormData, email: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-source">Source</Label>
                <Select
                  value={editFormData.source}
                  onValueChange={(value) => setEditFormData({ ...editFormData, source: value })}
                >
                  <SelectTrigger id="edit-source">
                    <SelectValue placeholder="Select source" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Website">Website</SelectItem>
                    <SelectItem value="Phone Call">Phone Call</SelectItem>
                    <SelectItem value="Email">Email</SelectItem>
                    <SelectItem value="School Visit">School Visit</SelectItem>
                    <SelectItem value="Referral">Referral</SelectItem>
                    <SelectItem value="Social Media">Social Media</SelectItem>
                    <SelectItem value="Advertisement">Advertisement</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-message">Message/Notes</Label>
                <Textarea
                  id="edit-message"
                  value={editFormData.message}
                  onChange={(e) => setEditFormData({ ...editFormData, message: e.target.value })}
                  className="min-h-[100px]"
                />
              </div>
            </div>
          )}
          <DialogFooter className="flex justify-between">
            <DialogClose asChild>
              <Button variant="outline">Cancel</Button>
            </DialogClose>
            <Button className="bg-theme-500 hover:bg-theme-600" onClick={saveEditChanges}>
              <Save className="mr-2 h-4 w-4" />
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the enquiry. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-red-600 hover:bg-red-700" onClick={confirmDelete}>
              <Trash2 className="mr-2 h-4 w-4" />
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Change Status Dialog */}
      <Dialog open={isStatusDialogOpen} onOpenChange={setIsStatusDialogOpen}>
        <DialogContent className="sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle>Change Enquiry Status</DialogTitle>
            <DialogDescription>Update the status of this enquiry</DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-3 py-4">
            <Button
              variant="outline"
              className="flex flex-col items-center justify-center h-24 p-2"
              onClick={() => updateStatus("contacted")}
            >
              <Phone className="h-8 w-8 mb-2 text-purple-500" />
              <span>Contacted</span>
            </Button>
            <Button
              variant="outline"
              className="flex flex-col items-center justify-center h-24 p-2"
              onClick={() => updateStatus("followup")}
            >
              <Clock className="h-8 w-8 mb-2 text-amber-500" />
              <span>Follow Up</span>
            </Button>
            <Button
              variant="outline"
              className="flex flex-col items-center justify-center h-24 p-2"
              onClick={() => updateStatus("converted")}
            >
              <CheckCircle className="h-8 w-8 mb-2 text-green-500" />
              <span>Converted</span>
            </Button>
            <Button
              variant="outline"
              className="flex flex-col items-center justify-center h-24 p-2"
              onClick={() => updateStatus("closed")}
            >
              <X className="h-8 w-8 mb-2 text-gray-500" />
              <span>Closed</span>
            </Button>
            <Button
              variant="outline"
              className="flex flex-col items-center justify-center h-24 p-2 col-span-2"
              onClick={() => updateStatus("cancelled")}
            >
              <AlertTriangle className="h-8 w-8 mb-2 text-red-500" />
              <span>Cancelled</span>
            </Button>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">Cancel</Button>
            </DialogClose>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Follow-up Dialog */}
      <Dialog open={isFollowUpDialogOpen} onOpenChange={setIsFollowUpDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Add Follow-up</DialogTitle>
            <DialogDescription>Schedule a follow-up for this enquiry</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Follow-up Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant={"outline"} className="w-full justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {followUpDate ? format(followUpDate, "PPP") : "Select date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <CalendarComponent mode="single" selected={followUpDate} onSelect={setFollowUpDate} initialFocus />
                </PopoverContent>
              </Popover>
            </div>
            <div className="space-y-2">
              <Label htmlFor="follow-up-notes">Notes</Label>
              <Textarea
                id="follow-up-notes"
                placeholder="Enter follow-up details or action items"
                value={followUpNotes}
                onChange={(e) => setFollowUpNotes(e.target.value)}
                className="min-h-[100px]"
              />
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">Cancel</Button>
            </DialogClose>
            <Button className="bg-theme-500 hover:bg-theme-600" onClick={addFollowUp}>
              <MessageSquare className="mr-2 h-4 w-4" />
              Add Follow-up
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageTemplate>
  )
}
