"use client"

import { useState } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Plus, Download, Printer, ArrowLeft, ArrowRight } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function TimetablePage() {
  const [selectedClass, setSelectedClass] = useState("Grade 1-A")
  const [currentWeek, setCurrentWeek] = useState("May 6 - May 12, 2024")

  // Sample timetable data
  const timetableData = {
    "Grade 1-A": [
      {
        day: "Monday",
        periods: [
          { time: "8:00 - 8:45", subject: "Mathematics", teacher: "Mrs. Johnson", room: "P-101" },
          { time: "8:50 - 9:35", subject: "English", teacher: "Mr. Smith", room: "P-101" },
          { time: "9:40 - 10:25", subject: "Science", teacher: "Mrs. Davis", room: "P-101" },
          { time: "10:25 - 10:45", subject: "Break", teacher: "", room: "" },
          { time: "10:45 - 11:30", subject: "Social Studies", teacher: "Mr. Wilson", room: "P-101" },
          { time: "11:35 - 12:20", subject: "Art", teacher: "Mrs. Brown", room: "Art Room" },
          { time: "12:20 - 1:00", subject: "Lunch", teacher: "", room: "Cafeteria" },
          { time: "1:00 - 1:45", subject: "Physical Education", teacher: "Mr. Taylor", room: "Playground" },
        ],
      },
      {
        day: "Tuesday",
        periods: [
          { time: "8:00 - 8:45", subject: "English", teacher: "Mr. Smith", room: "P-101" },
          { time: "8:50 - 9:35", subject: "Mathematics", teacher: "Mrs. Johnson", room: "P-101" },
          { time: "9:40 - 10:25", subject: "Science", teacher: "Mrs. Davis", room: "P-101" },
          { time: "10:25 - 10:45", subject: "Break", teacher: "", room: "" },
          { time: "10:45 - 11:30", subject: "Music", teacher: "Ms. Lee", room: "Music Room" },
          { time: "11:35 - 12:20", subject: "Social Studies", teacher: "Mr. Wilson", room: "P-101" },
          { time: "12:20 - 1:00", subject: "Lunch", teacher: "", room: "Cafeteria" },
          { time: "1:00 - 1:45", subject: "Library", teacher: "Mrs. White", room: "Library" },
        ],
      },
      {
        day: "Wednesday",
        periods: [
          { time: "8:00 - 8:45", subject: "Science", teacher: "Mrs. Davis", room: "P-101" },
          { time: "8:50 - 9:35", subject: "Mathematics", teacher: "Mrs. Johnson", room: "P-101" },
          { time: "9:40 - 10:25", subject: "English", teacher: "Mr. Smith", room: "P-101" },
          { time: "10:25 - 10:45", subject: "Break", teacher: "", room: "" },
          { time: "10:45 - 11:30", subject: "Art", teacher: "Mrs. Brown", room: "Art Room" },
          { time: "11:35 - 12:20", subject: "Social Studies", teacher: "Mr. Wilson", room: "P-101" },
          { time: "12:20 - 1:00", subject: "Lunch", teacher: "", room: "Cafeteria" },
          { time: "1:00 - 1:45", subject: "Computer", teacher: "Mr. Johnson", room: "Computer Lab" },
        ],
      },
      {
        day: "Thursday",
        periods: [
          { time: "8:00 - 8:45", subject: "Mathematics", teacher: "Mrs. Johnson", room: "P-101" },
          { time: "8:50 - 9:35", subject: "Science", teacher: "Mrs. Davis", room: "P-101" },
          { time: "9:40 - 10:25", subject: "English", teacher: "Mr. Smith", room: "P-101" },
          { time: "10:25 - 10:45", subject: "Break", teacher: "", room: "" },
          { time: "10:45 - 11:30", subject: "Social Studies", teacher: "Mr. Wilson", room: "P-101" },
          { time: "11:35 - 12:20", subject: "Physical Education", teacher: "Mr. Taylor", room: "Playground" },
          { time: "12:20 - 1:00", subject: "Lunch", teacher: "", room: "Cafeteria" },
          { time: "1:00 - 1:45", subject: "Health", teacher: "Mrs. Davis", room: "P-101" },
        ],
      },
      {
        day: "Friday",
        periods: [
          { time: "8:00 - 8:45", subject: "English", teacher: "Mr. Smith", room: "P-101" },
          { time: "8:50 - 9:35", subject: "Mathematics", teacher: "Mrs. Johnson", room: "P-101" },
          { time: "9:40 - 10:25", subject: "Science", teacher: "Mrs. Davis", room: "P-101" },
          { time: "10:25 - 10:45", subject: "Break", teacher: "", room: "" },
          { time: "10:45 - 11:30", subject: "Social Studies", teacher: "Mr. Wilson", room: "P-101" },
          { time: "11:35 - 12:20", subject: "Art", teacher: "Mrs. Brown", room: "Art Room" },
          { time: "12:20 - 1:00", subject: "Lunch", teacher: "", room: "Cafeteria" },
          { time: "1:00 - 1:45", subject: "Class Meeting", teacher: "Mrs. Johnson", room: "P-101" },
        ],
      },
    ],
    "Grade 10-A": [
      // Similar structure for Grade 10-A
    ],
  }

  // Sample classes
  const classes = ["Grade 1-A", "Grade 1-B", "Grade 2-A", "Grade 8-C", "Grade 10-A", "Grade 12-B"]

  // Sample weeks
  const weeks = ["Apr 29 - May 5, 2024", "May 6 - May 12, 2024", "May 13 - May 19, 2024", "May 20 - May 26, 2024"]

  const handlePreviousWeek = () => {
    const currentIndex = weeks.indexOf(currentWeek)
    if (currentIndex > 0) {
      setCurrentWeek(weeks[currentIndex - 1])
    }
  }

  const handleNextWeek = () => {
    const currentIndex = weeks.indexOf(currentWeek)
    if (currentIndex < weeks.length - 1) {
      setCurrentWeek(weeks[currentIndex + 1])
    }
  }

  return (
    <PageTemplate
      title="Timetable"
      description="View and manage class schedules and timetables."
      breadcrumbs={[
        { title: "Academic Portfolio", href: "#" },
        { title: "Timetable", href: "/dashboard/timetable", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Create Timetable",
        icon: <Plus className="h-4 w-4 mr-2" />,
        href: "/dashboard/timetable/create",
      }}
    >
      <div className="grid gap-4">
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle>Class Timetable</CardTitle>
              <div className="flex items-center gap-2">
                <Select value={selectedClass} onValueChange={setSelectedClass}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Select class" />
                  </SelectTrigger>
                  <SelectContent>
                    {classes.map((cls) => (
                      <SelectItem key={cls} value={cls}>
                        {cls}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="icon" onClick={handlePreviousWeek}>
                    <ArrowLeft className="h-4 w-4" />
                  </Button>
                  <span className="text-sm font-medium">{currentWeek}</span>
                  <Button variant="outline" size="icon" onClick={handleNextWeek}>
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </div>
                <Button variant="outline" size="icon">
                  <Printer className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon">
                  <Download className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="grid" className="w-full">
              <TabsList className="grid w-[200px] grid-cols-2 mb-4">
                <TabsTrigger value="grid">Grid View</TabsTrigger>
                <TabsTrigger value="list">List View</TabsTrigger>
              </TabsList>

              <TabsContent value="grid" className="w-full">
                <div className="overflow-x-auto">
                  <Table className="border">
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[100px]">Time</TableHead>
                        <TableHead>Monday</TableHead>
                        <TableHead>Tuesday</TableHead>
                        <TableHead>Wednesday</TableHead>
                        <TableHead>Thursday</TableHead>
                        <TableHead>Friday</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {timetableData[selectedClass]?.[0]?.periods.map((period, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">{period.time}</TableCell>
                          {timetableData[selectedClass]?.map((day, dayIndex) => (
                            <TableCell
                              key={dayIndex}
                              className={
                                day.periods[index].subject === "Break" || day.periods[index].subject === "Lunch"
                                  ? "bg-gray-100"
                                  : ""
                              }
                            >
                              {day.periods[index].subject === "Break" || day.periods[index].subject === "Lunch" ? (
                                <div className="text-center font-medium text-gray-500">
                                  {day.periods[index].subject}
                                </div>
                              ) : (
                                <div className="space-y-1">
                                  <div className="font-medium">{day.periods[index].subject}</div>
                                  <div className="text-xs text-muted-foreground">{day.periods[index].teacher}</div>
                                  <div className="text-xs text-muted-foreground">{day.periods[index].room}</div>
                                </div>
                              )}
                            </TableCell>
                          ))}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>

              <TabsContent value="list">
                <div className="space-y-6">
                  {timetableData[selectedClass]?.map((day, index) => (
                    <Card key={index} className="overflow-hidden">
                      <CardHeader className="bg-gray-50 py-3">
                        <CardTitle className="text-base">{day.day}</CardTitle>
                      </CardHeader>
                      <CardContent className="p-0">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead className="w-[120px]">Time</TableHead>
                              <TableHead>Subject</TableHead>
                              <TableHead>Teacher</TableHead>
                              <TableHead>Room</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {day.periods.map((period, periodIndex) => (
                              <TableRow
                                key={periodIndex}
                                className={
                                  period.subject === "Break" || period.subject === "Lunch" ? "bg-gray-100" : ""
                                }
                              >
                                <TableCell className="font-medium">{period.time}</TableCell>
                                <TableCell>
                                  {period.subject === "Break" || period.subject === "Lunch" ? (
                                    <Badge variant="outline" className="bg-gray-100 text-gray-700">
                                      {period.subject}
                                    </Badge>
                                  ) : (
                                    period.subject
                                  )}
                                </TableCell>
                                <TableCell>{period.teacher}</TableCell>
                                <TableCell>{period.room}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </PageTemplate>
  )
}
