"use client"

import { useState } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Printer, Download, Eye, MoreHorizontal } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

export default function IDCardsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [classFilter, setClassFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")
  const [selectedStudent, setSelectedStudent] = useState<any>(null)
  const [isPreviewDialogOpen, setIsPreviewDialogOpen] = useState(false)

  // Sample data
  const students = [
    {
      id: "STU001",
      name: "Rahul Sharma",
      class: "Class X",
      section: "A",
      rollNo: "101",
      idCardStatus: "issued",
      issueDate: "2023-04-15",
      admissionNo: "ADM2023101",
      bloodGroup: "B+",
      address: "123, Green Park, New Delhi",
      phone: "+91 9876543210",
      emergencyContact: "+91 9876543211",
      parentName: "Rajesh Sharma",
    },
    {
      id: "STU002",
      name: "Priya Patel",
      class: "Class VIII",
      section: "B",
      rollNo: "102",
      idCardStatus: "issued",
      issueDate: "2023-04-15",
      admissionNo: "ADM2023102",
      bloodGroup: "O+",
      address: "45, Patel Nagar, Mumbai",
      phone: "+91 8765432109",
      emergencyContact: "+91 8765432110",
      parentName: "Suresh Patel",
    },
    {
      id: "STU003",
      name: "Amit Kumar",
      class: "Class VI",
      section: "A",
      rollNo: "103",
      idCardStatus: "pending",
      issueDate: null,
      admissionNo: "ADM2023103",
      bloodGroup: "A+",
      address: "78, Model Town, Delhi",
      phone: "+91 7654321098",
      emergencyContact: "+91 7654321099",
      parentName: "Vijay Kumar",
    },
    {
      id: "STU004",
      name: "Sneha Gupta",
      class: "Class XI",
      section: "C",
      rollNo: "104",
      idCardStatus: "issued",
      issueDate: "2023-04-16",
      admissionNo: "ADM2023104",
      bloodGroup: "AB+",
      address: "34, Civil Lines, Jaipur",
      phone: "+91 6543210987",
      emergencyContact: "+91 6543210988",
      parentName: "Rakesh Gupta",
    },
    {
      id: "STU005",
      name: "Vikram Singh",
      class: "Class IX",
      section: "B",
      rollNo: "105",
      idCardStatus: "pending",
      issueDate: null,
      admissionNo: "ADM2023105",
      bloodGroup: "B-",
      address: "56, Sector 18, Chandigarh",
      phone: "+91 5432109876",
      emergencyContact: "+91 5432109877",
      parentName: "Harpreet Singh",
    },
  ]

  const filteredStudents = students.filter((student) => {
    const matchesSearch =
      student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.rollNo.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesClass = classFilter === "all" || student.class === classFilter
    const matchesStatus = statusFilter === "all" || student.idCardStatus === statusFilter

    return matchesSearch && matchesClass && matchesStatus
  })

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "issued":
        return <Badge className="bg-green-500">Issued</Badge>
      case "pending":
        return <Badge className="bg-amber-500">Pending</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
  }

  const handlePreviewIDCard = (student: any) => {
    setSelectedStudent(student)
    setIsPreviewDialogOpen(true)
  }

  const handlePrintIDCard = (student: any) => {
    // In a real application, this would open a print dialog with formatted ID card
    alert(`Printing ID card for ${student.name}`)
  }

  const handleDownloadIDCard = (student: any) => {
    // In a real application, this would download a PDF of the ID card
    alert(`Downloading ID card for ${student.name}`)
  }

  return (
    <PageTemplate
      title="ID Cards"
      description="Manage student ID cards"
      breadcrumbs={[
        { title: "Student Manager", href: "/dashboard/students" },
        { title: "ID Cards", href: "/dashboard/id-cards", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Generate All",
        icon: <Printer className="mr-2 h-4 w-4" />,
      }}
    >
      <Card>
        <CardHeader className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
          <CardTitle>Student ID Cards</CardTitle>
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search students..."
                className="pl-8 w-full sm:w-[250px]"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select value={classFilter} onValueChange={setClassFilter}>
              <SelectTrigger className="w-full sm:w-[150px]">
                <SelectValue placeholder="Filter by class" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Classes</SelectItem>
                <SelectItem value="Class VI">Class VI</SelectItem>
                <SelectItem value="Class VII">Class VII</SelectItem>
                <SelectItem value="Class VIII">Class VIII</SelectItem>
                <SelectItem value="Class IX">Class IX</SelectItem>
                <SelectItem value="Class X">Class X</SelectItem>
                <SelectItem value="Class XI">Class XI</SelectItem>
                <SelectItem value="Class XII">Class XII</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-[150px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="issued">Issued</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Class</TableHead>
                  <TableHead className="hidden md:table-cell">Section</TableHead>
                  <TableHead className="hidden md:table-cell">Roll No</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="hidden md:table-cell">Issue Date</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredStudents.map((student) => (
                  <TableRow key={student.id}>
                    <TableCell className="font-medium">{student.id}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Avatar className="h-8 w-8">
                          <AvatarImage
                            src={`/abstract-geometric-shapes.png?height=32&width=32&query=${student.name}`}
                            alt={student.name}
                          />
                          <AvatarFallback>{getInitials(student.name)}</AvatarFallback>
                        </Avatar>
                        <span>{student.name}</span>
                      </div>
                    </TableCell>
                    <TableCell>{student.class}</TableCell>
                    <TableCell className="hidden md:table-cell">{student.section}</TableCell>
                    <TableCell className="hidden md:table-cell">{student.rollNo}</TableCell>
                    <TableCell>{getStatusBadge(student.idCardStatus)}</TableCell>
                    <TableCell className="hidden md:table-cell">
                      {student.issueDate ? new Date(student.issueDate).toLocaleDateString() : "-"}
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <DropdownMenuItem onClick={() => handlePreviewIDCard(student)}>
                            <Eye className="mr-2 h-4 w-4" />
                            Preview ID Card
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => handlePrintIDCard(student)}>
                            <Printer className="mr-2 h-4 w-4" />
                            Print ID Card
                          </DropdownMenuItem>
                          {student.idCardStatus === "issued" && (
                            <DropdownMenuItem onClick={() => handleDownloadIDCard(student)}>
                              <Download className="mr-2 h-4 w-4" />
                              Download ID Card
                            </DropdownMenuItem>
                          )}
                          {student.idCardStatus === "pending" && (
                            <DropdownMenuItem>
                              <Printer className="mr-2 h-4 w-4" />
                              Generate ID Card
                            </DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* ID Card Preview Dialog */}
      <Dialog open={isPreviewDialogOpen} onOpenChange={setIsPreviewDialogOpen}>
        <DialogContent className="sm:max-w-[450px]">
          <DialogHeader>
            <DialogTitle>ID Card Preview</DialogTitle>
            <DialogDescription>Student identification card</DialogDescription>
          </DialogHeader>
          {selectedStudent && (
            <div className="flex flex-col items-center">
              <div className="w-full max-w-[350px] border-2 border-theme-500 rounded-lg overflow-hidden">
                {/* ID Card Header */}
                <div className="bg-theme-500 text-white p-3 text-center">
                  <h2 className="text-lg font-bold">NETKAMPUS SCHOOL</h2>
                  <p className="text-xs">Student Identification Card</p>
                </div>

                {/* ID Card Body */}
                <div className="p-4 bg-white">
                  <div className="flex items-center justify-between mb-4">
                    <Avatar className="h-24 w-24 border-2 border-theme-100">
                      <AvatarImage
                        src={`/abstract-geometric-shapes.png?height=96&width=96&query=${selectedStudent.name}`}
                        alt={selectedStudent.name}
                      />
                      <AvatarFallback className="text-xl">{getInitials(selectedStudent.name)}</AvatarFallback>
                    </Avatar>
                    <div className="text-right">
                      <div className="text-xs text-muted-foreground">Admission No</div>
                      <div className="font-bold">{selectedStudent.admissionNo}</div>
                      <div className="text-xs text-muted-foreground mt-1">Valid Till</div>
                      <div className="font-medium">31 March 2024</div>
                    </div>
                  </div>

                  <div className="space-y-2 text-sm">
                    <div>
                      <div className="text-xs text-muted-foreground">Name</div>
                      <div className="font-bold">{selectedStudent.name}</div>
                    </div>
                    <div className="flex justify-between">
                      <div>
                        <div className="text-xs text-muted-foreground">Class</div>
                        <div>{selectedStudent.class}</div>
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground">Section</div>
                        <div>{selectedStudent.section}</div>
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground">Roll No</div>
                        <div>{selectedStudent.rollNo}</div>
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground">Blood Group</div>
                      <div>{selectedStudent.bloodGroup}</div>
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground">Emergency Contact</div>
                      <div>{selectedStudent.emergencyContact}</div>
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground">Address</div>
                      <div className="text-xs">{selectedStudent.address}</div>
                    </div>
                  </div>
                </div>

                {/* ID Card Footer */}
                <div className="bg-theme-100 p-2 text-center text-xs">
                  <p>If found, please return to: NetKampus School, New Delhi</p>
                  <p>Phone: +91 11 2345 6789 | www.netkampus.edu.in</p>
                </div>
              </div>
            </div>
          )}
          <DialogFooter className="flex justify-between">
            <Button variant="outline" onClick={() => setIsPreviewDialogOpen(false)}>
              Close
            </Button>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => selectedStudent && handlePrintIDCard(selectedStudent)}>
                <Printer className="mr-2 h-4 w-4" />
                Print
              </Button>
              <Button
                className="bg-theme-500 hover:bg-theme-600"
                onClick={() => selectedStudent && handleDownloadIDCard(selectedStudent)}
              >
                <Download className="mr-2 h-4 w-4" />
                Download
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageTemplate>
  )
}
