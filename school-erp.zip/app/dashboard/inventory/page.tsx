import type { Metadata } from "next"
import { Package, AlertTriangle, ShoppingCart, TrendingUp, Truck } from "lucide-react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"

export const metadata: Metadata = {
  title: "Inventory Management",
  description: "Manage school inventory and stock levels",
}

export default function InventoryPage() {
  return (
    <div className="flex flex-col gap-4 p-4 md:p-8">
      <div className="flex items-center justify-between">
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/dashboard">Dashboard</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>Inventory Management</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
        <Button>Add New Item</Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Items</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,248</div>
            <p className="text-xs text-muted-foreground">+12% from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Low Stock Items</CardTitle>
            <AlertTriangle className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">24</div>
            <p className="text-xs text-muted-foreground">+2 since last week</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Purchase Orders</CardTitle>
            <ShoppingCart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
            <p className="text-xs text-muted-foreground">3 pending approval</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Stock Value</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹4.2L</div>
            <p className="text-xs text-muted-foreground">+8% from last quarter</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="items" className="w-full">
        <TabsList>
          <TabsTrigger value="items">Items</TabsTrigger>
          <TabsTrigger value="categories">Categories</TabsTrigger>
          <TabsTrigger value="suppliers">Suppliers</TabsTrigger>
          <TabsTrigger value="low-stock">Low Stock</TabsTrigger>
        </TabsList>
        <TabsContent value="items" className="border rounded-md mt-2">
          <div className="flex items-center justify-between p-4">
            <h3 className="text-lg font-medium">Inventory Items</h3>
            <div className="flex gap-2">
              <Input placeholder="Search items..." className="w-64" />
              <Button variant="outline">Filter</Button>
            </div>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Item Code</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Quantity</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Last Updated</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[...Array(5)].map((_, i) => (
                <TableRow key={i}>
                  <TableCell className="font-medium">INV-{1000 + i}</TableCell>
                  <TableCell>{["Notebooks", "Pens", "Chalk", "Whiteboard Markers", "Lab Equipment"][i]}</TableCell>
                  <TableCell>
                    {["Stationery", "Stationery", "Teaching Supplies", "Teaching Supplies", "Science Lab"][i]}
                  </TableCell>
                  <TableCell>{[120, 500, 50, 75, 25][i]}</TableCell>
                  <TableCell>
                    <Badge variant={i === 2 ? "destructive" : i === 4 ? "warning" : "default"}>
                      {i === 2 ? "Low Stock" : i === 4 ? "Low Stock" : "In Stock"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-muted-foreground">
                    {["2 days ago", "1 week ago", "Yesterday", "3 days ago", "Today"][i]}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TabsContent>
        <TabsContent value="categories" className="border rounded-md mt-2 p-4">
          <h3 className="text-lg font-medium mb-4">Item Categories</h3>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[
              "Stationery",
              "Teaching Supplies",
              "Science Lab",
              "Sports Equipment",
              "Office Supplies",
              "IT Equipment",
            ].map((category, i) => (
              <Card key={i}>
                <CardHeader className="pb-2">
                  <CardTitle className="text-md">{category}</CardTitle>
                  <CardDescription>{[42, 28, 35, 20, 15, 30][i]} items</CardDescription>
                </CardHeader>
                <CardContent className="pb-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Total Value:</span>
                    <span className="font-medium">
                      ₹{[25000, 35000, 120000, 80000, 12000, 250000][i].toLocaleString()}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="suppliers" className="border rounded-md mt-2">
          <div className="flex items-center justify-between p-4">
            <h3 className="text-lg font-medium">Suppliers</h3>
            <Button>Add Supplier</Button>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Supplier ID</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Contact Person</TableHead>
                <TableHead>Phone</TableHead>
                <TableHead>Items Supplied</TableHead>
                <TableHead>Last Order</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[...Array(4)].map((_, i) => (
                <TableRow key={i}>
                  <TableCell className="font-medium">SUP-{100 + i}</TableCell>
                  <TableCell>
                    {["Global Stationery", "Tech Solutions", "Lab Supplies Co.", "Sports Equipment Ltd."][i]}
                  </TableCell>
                  <TableCell>{["Rahul Sharma", "Priya Patel", "Amit Kumar", "Neha Singh"][i]}</TableCell>
                  <TableCell>{["9876543210", "8765432109", "7654321098", "6543210987"][i]}</TableCell>
                  <TableCell>{[24, 15, 32, 18][i]}</TableCell>
                  <TableCell className="text-muted-foreground">
                    {["15 May 2023", "2 June 2023", "10 April 2023", "22 May 2023"][i]}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TabsContent>
        <TabsContent value="low-stock" className="border rounded-md mt-2">
          <div className="flex items-center justify-between p-4">
            <h3 className="text-lg font-medium">Low Stock Alert</h3>
            <Button variant="outline" className="gap-2">
              <Truck className="h-4 w-4" />
              Create Purchase Order
            </Button>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Item Code</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Current Stock</TableHead>
                <TableHead>Minimum Level</TableHead>
                <TableHead>Supplier</TableHead>
                <TableHead>Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[...Array(5)].map((_, i) => (
                <TableRow key={i}>
                  <TableCell className="font-medium">INV-{1002 + i}</TableCell>
                  <TableCell>
                    {["Chalk", "Lab Chemicals", "Printer Paper", "Whiteboard Markers", "Science Kits"][i]}
                  </TableCell>
                  <TableCell className="text-red-500 font-medium">{[10, 5, 15, 8, 3][i]}</TableCell>
                  <TableCell>{[50, 20, 50, 30, 10][i]}</TableCell>
                  <TableCell>
                    {
                      [
                        "Global Stationery",
                        "Lab Supplies Co.",
                        "Office Solutions",
                        "Tech Solutions",
                        "Lab Supplies Co.",
                      ][i]
                    }
                  </TableCell>
                  <TableCell>
                    <Button variant="ghost" size="sm">
                      Order
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TabsContent>
      </Tabs>
    </div>
  )
}
