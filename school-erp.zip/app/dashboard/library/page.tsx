import type { Metadata } from "next"
import { BookOpen, Users, BookMarked, AlertTriangle, Search, BookCopy, Bookmark } from "lucide-react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"

export const metadata: Metadata = {
  title: "Library Management",
  description: "Manage school library, books and circulation",
}

export default function LibraryPage() {
  return (
    <div className="flex flex-col gap-4 p-4 md:p-8">
      <div className="flex items-center justify-between">
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/dashboard">Dashboard</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>Library Management</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
        <Button>Add Book</Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Books</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">5,248</div>
            <p className="text-xs text-muted-foreground">+124 from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Books Issued</CardTitle>
            <BookMarked className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">842</div>
            <p className="text-xs text-muted-foreground">Currently in circulation</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Library Members</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,428</div>
            <p className="text-xs text-muted-foreground">Students and staff</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overdue Books</CardTitle>
            <AlertTriangle className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">42</div>
            <p className="text-xs text-muted-foreground">₹4,200 in pending fines</p>
          </CardContent>
        </Card>
      </div>

      <Card className="mb-4">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Book Search</CardTitle>
              <CardDescription>Find books by title, author, or category</CardDescription>
            </div>
            <Button variant="outline" className="gap-2">
              <Search className="h-4 w-4" />
              Advanced Search
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 flex-col sm:flex-row">
            <Input placeholder="Search by title, author or ISBN..." className="flex-1" />
            <div className="flex gap-2">
              <Button className="w-full sm:w-auto">Search</Button>
              <Button variant="outline" className="w-full sm:w-auto">
                Reset
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="books" className="w-full">
        <TabsList>
          <TabsTrigger value="books">Books</TabsTrigger>
          <TabsTrigger value="circulation">Circulation</TabsTrigger>
          <TabsTrigger value="members">Members</TabsTrigger>
          <TabsTrigger value="fines">Fines</TabsTrigger>
        </TabsList>
        <TabsContent value="books" className="border rounded-md mt-2">
          <div className="flex items-center justify-between p-4">
            <h3 className="text-lg font-medium">Book Inventory</h3>
            <div className="flex gap-2">
              <Button variant="outline" className="gap-2">
                <BookCopy className="h-4 w-4" />
                Categories
              </Button>
              <Button variant="outline" className="gap-2">
                <Bookmark className="h-4 w-4" />
                Publishers
              </Button>
            </div>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Book ID</TableHead>
                <TableHead>Title</TableHead>
                <TableHead>Author</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Copies</TableHead>
                <TableHead>Available</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[...Array(5)].map((_, i) => (
                <TableRow key={i}>
                  <TableCell className="font-medium">BK-{10001 + i}</TableCell>
                  <TableCell>
                    {
                      [
                        "The Great Gatsby",
                        "To Kill a Mockingbird",
                        "1984",
                        "Pride and Prejudice",
                        "The Catcher in the Rye",
                      ][i]
                    }
                  </TableCell>
                  <TableCell>
                    {["F. Scott Fitzgerald", "Harper Lee", "George Orwell", "Jane Austen", "J.D. Salinger"][i]}
                  </TableCell>
                  <TableCell>{["Fiction", "Classic", "Dystopian", "Romance", "Coming-of-age"][i]}</TableCell>
                  <TableCell>{[5, 8, 6, 4, 3][i]}</TableCell>
                  <TableCell>{[2, 3, 0, 1, 2][i]}</TableCell>
                  <TableCell>
                    <Badge variant={i === 2 ? "destructive" : i === 3 ? "warning" : "default"}>
                      {i === 2 ? "All Issued" : i === 3 ? "Low Stock" : "Available"}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TabsContent>
        <TabsContent value="circulation" className="border rounded-md mt-2">
          <div className="flex items-center justify-between p-4">
            <h3 className="text-lg font-medium">Book Circulation</h3>
            <div className="flex gap-2">
              <Button>Issue Book</Button>
              <Button variant="outline">Return Book</Button>
            </div>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Issue ID</TableHead>
                <TableHead>Book Title</TableHead>
                <TableHead>Student Name</TableHead>
                <TableHead>Issue Date</TableHead>
                <TableHead>Due Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[...Array(5)].map((_, i) => (
                <TableRow key={i}>
                  <TableCell className="font-medium">ISS-{20001 + i}</TableCell>
                  <TableCell>
                    {
                      [
                        "The Great Gatsby",
                        "To Kill a Mockingbird",
                        "1984",
                        "Pride and Prejudice",
                        "The Catcher in the Rye",
                      ][i]
                    }
                  </TableCell>
                  <TableCell>
                    {["Aarav Sharma", "Diya Patel", "Arjun Singh", "Ananya Gupta", "Vihaan Mehta"][i]}
                  </TableCell>
                  <TableCell>
                    {["10 May 2023", "15 May 2023", "20 May 2023", "25 May 2023", "30 May 2023"][i]}
                  </TableCell>
                  <TableCell>
                    {["24 May 2023", "29 May 2023", "3 June 2023", "8 June 2023", "13 June 2023"][i]}
                  </TableCell>
                  <TableCell>
                    <Badge variant={i === 0 ? "destructive" : i === 1 ? "warning" : "default"}>
                      {i === 0 ? "Overdue" : i === 1 ? "Due Soon" : "Issued"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Button variant="ghost" size="sm">
                      Return
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TabsContent>
        <TabsContent value="members" className="border rounded-md mt-2">
          <div className="flex items-center justify-between p-4">
            <h3 className="text-lg font-medium">Library Members</h3>
            <div className="flex gap-2">
              <Input placeholder="Search members..." className="w-64" />
              <Button variant="outline">Filter</Button>
            </div>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Member ID</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Class/Dept</TableHead>
                <TableHead>Books Issued</TableHead>
                <TableHead>Fine Due</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[...Array(5)].map((_, i) => (
                <TableRow key={i}>
                  <TableCell className="font-medium">MEM-{30001 + i}</TableCell>
                  <TableCell>
                    {["Aarav Sharma", "Diya Patel", "Arjun Singh", "Ananya Gupta", "Rajesh Kumar"][i]}
                  </TableCell>
                  <TableCell>{["Student", "Student", "Student", "Student", "Staff"][i]}</TableCell>
                  <TableCell>{["Class 8A", "Class 5B", "Class 10C", "Class 7A", "Science Dept."][i]}</TableCell>
                  <TableCell>{[2, 1, 3, 0, 2][i]}</TableCell>
                  <TableCell>{["₹100", "₹0", "₹250", "₹0", "₹0"][i]}</TableCell>
                  <TableCell>
                    <Badge variant={i === 0 || i === 2 ? "destructive" : "success"}>
                      {i === 0 || i === 2 ? "Fine Due" : "Active"}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TabsContent>
        <TabsContent value="fines" className="border rounded-md mt-2">
          <div className="flex items-center justify-between p-4">
            <h3 className="text-lg font-medium">Fine Collection</h3>
            <Button>Collect Fine</Button>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Fine ID</TableHead>
                <TableHead>Student Name</TableHead>
                <TableHead>Book Title</TableHead>
                <TableHead>Due Date</TableHead>
                <TableHead>Return Date</TableHead>
                <TableHead>Days Late</TableHead>
                <TableHead>Fine Amount</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[...Array(5)].map((_, i) => (
                <TableRow key={i}>
                  <TableCell className="font-medium">FN-{40001 + i}</TableCell>
                  <TableCell>
                    {["Aarav Sharma", "Diya Patel", "Arjun Singh", "Ananya Gupta", "Vihaan Mehta"][i]}
                  </TableCell>
                  <TableCell>
                    {
                      [
                        "The Great Gatsby",
                        "To Kill a Mockingbird",
                        "1984",
                        "Pride and Prejudice",
                        "The Catcher in the Rye",
                      ][i]
                    }
                  </TableCell>
                  <TableCell>
                    {["24 May 2023", "29 May 2023", "3 June 2023", "8 June 2023", "13 June 2023"][i]}
                  </TableCell>
                  <TableCell>{["4 June 2023", "5 June 2023", "13 June 2023", "18 June 2023", "-"][i]}</TableCell>
                  <TableCell>{[10, 7, 10, 10, 0][i]}</TableCell>
                  <TableCell>{["₹100", "₹70", "₹100", "₹100", "₹0"][i]}</TableCell>
                  <TableCell>
                    <Badge variant={i === 4 ? "outline" : i === 0 || i === 2 ? "destructive" : "success"}>
                      {i === 4 ? "Not Returned" : i === 0 || i === 2 ? "Unpaid" : "Paid"}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TabsContent>
      </Tabs>
    </div>
  )
}
