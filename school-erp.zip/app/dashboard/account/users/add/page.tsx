"use client"

import type React from "react"

import { useState } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Save, ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function AddUserPage() {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    role: "",
    department: "",
    sendInvite: true,
  })

  const handleChange = (field: string, value: string | boolean) => {
    setFormData({
      ...formData,
      [field]: value,
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Add user logic would go here
    alert("User added successfully!")
  }

  return (
    <PageTemplate
      title="Add New User"
      description="Create a new user account"
      breadcrumbs={[
        { title: "Account", href: "/dashboard/account" },
        { title: "Users", href: "/dashboard/account/users" },
        { title: "Add User", href: "/dashboard/account/users/add", isCurrentPage: true },
      ]}
    >
      <Card>
        <CardHeader>
          <CardTitle>User Information</CardTitle>
          <CardDescription>Enter the details for the new user</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">First Name</Label>
                <Input
                  id="firstName"
                  placeholder="Enter first name"
                  value={formData.firstName}
                  onChange={(e) => handleChange("firstName", e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">Last Name</Label>
                <Input
                  id="lastName"
                  placeholder="Enter last name"
                  value={formData.lastName}
                  onChange={(e) => handleChange("lastName", e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email Address</Label>
              <Input
                id="email"
                type="email"
                placeholder="Enter email address"
                value={formData.email}
                onChange={(e) => handleChange("email", e.target.value)}
                required
              />
              <p className="text-xs text-muted-foreground">This email will be used for login and communication</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="role">Role</Label>
                <Select value={formData.role} onValueChange={(value) => handleChange("role", value)} required>
                  <SelectTrigger id="role">
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="admin">Administrator</SelectItem>
                    <SelectItem value="teacher">Teacher</SelectItem>
                    <SelectItem value="accountant">Accountant</SelectItem>
                    <SelectItem value="staff">Staff</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="department">Department</Label>
                <Select
                  value={formData.department}
                  onValueChange={(value) => handleChange("department", value)}
                  required
                >
                  <SelectTrigger id="department">
                    <SelectValue placeholder="Select department" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Administration">Administration</SelectItem>
                    <SelectItem value="Teaching">Teaching</SelectItem>
                    <SelectItem value="Accounts">Accounts</SelectItem>
                    <SelectItem value="IT">IT</SelectItem>
                    <SelectItem value="Physical Education">Physical Education</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="sendInvite"
                checked={formData.sendInvite}
                onCheckedChange={(checked) => handleChange("sendInvite", checked as boolean)}
              />
              <Label htmlFor="sendInvite">Send email invitation to set up password</Label>
            </div>

            <div className="border-t pt-4">
              <h3 className="text-sm font-medium mb-2">Permissions</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Permissions will be assigned based on the selected role
              </p>

              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox id="perm1" defaultChecked disabled />
                  <Label htmlFor="perm1" className="text-sm">
                    View dashboard
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="perm2" defaultChecked disabled />
                  <Label htmlFor="perm2" className="text-sm">
                    Manage own profile
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="perm3" disabled />
                  <Label htmlFor="perm3" className="text-sm">
                    Manage users
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="perm4" disabled />
                  <Label htmlFor="perm4" className="text-sm">
                    Manage system settings
                  </Label>
                </div>
              </div>
            </div>
          </form>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" asChild>
            <Link href="/dashboard/account/users">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Users
            </Link>
          </Button>
          <Button type="submit" className="bg-theme-500 hover:bg-theme-600" onClick={handleSubmit}>
            <Save className="h-4 w-4 mr-2" />
            Create User
          </Button>
        </CardFooter>
      </Card>
    </PageTemplate>
  )
}
