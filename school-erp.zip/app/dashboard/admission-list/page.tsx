"use client"

import { useState } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Download, Eye, FileText, MoreHorizontal } from "lucide-react"

export default function AdmissionListPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [classFilter, setClassFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")

  // Sample data
  const admissions = [
    {
      id: "ADM001",
      name: "Rahul Sharma",
      class: "Class X",
      admissionDate: "2023-04-15",
      feeStatus: "paid",
      status: "active",
    },
    {
      id: "ADM002",
      name: "Priya Patel",
      class: "Class VIII",
      admissionDate: "2023-04-14",
      feeStatus: "pending",
      status: "active",
    },
    {
      id: "ADM003",
      name: "Amit Kumar",
      class: "Class VI",
      admissionDate: "2023-04-12",
      feeStatus: "paid",
      status: "active",
    },
    {
      id: "ADM004",
      name: "Sneha Gupta",
      class: "Class XI",
      admissionDate: "2023-04-10",
      feeStatus: "partial",
      status: "pending",
    },
    {
      id: "ADM005",
      name: "Vikram Singh",
      class: "Class IX",
      admissionDate: "2023-04-08",
      feeStatus: "paid",
      status: "active",
    },
  ]

  const filteredAdmissions = admissions.filter((admission) => {
    const matchesSearch =
      admission.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      admission.id.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesClass = classFilter === "all" || admission.class === classFilter
    const matchesStatus = statusFilter === "all" || admission.status === statusFilter

    return matchesSearch && matchesClass && matchesStatus
  })

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-500">Active</Badge>
      case "pending":
        return <Badge className="bg-amber-500">Pending</Badge>
      case "inactive":
        return <Badge className="bg-gray-500">Inactive</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  const getFeeStatusBadge = (status: string) => {
    switch (status) {
      case "paid":
        return <Badge className="bg-green-500">Paid</Badge>
      case "pending":
        return <Badge className="bg-red-500">Pending</Badge>
      case "partial":
        return <Badge className="bg-amber-500">Partial</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  return (
    <PageTemplate
      title="Admission List"
      description="View and manage student admissions"
      breadcrumbs={[
        { title: "Admission", href: "/dashboard/admission-list" },
        { title: "Admission List", href: "/dashboard/admission-list", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Export List",
        icon: <Download className="mr-2 h-4 w-4" />,
      }}
    >
      <Card>
        <CardHeader className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
          <CardTitle>All Admissions</CardTitle>
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search admissions..."
                className="pl-8 w-full sm:w-[250px]"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select value={classFilter} onValueChange={setClassFilter}>
              <SelectTrigger className="w-full sm:w-[150px]">
                <SelectValue placeholder="Filter by class" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Classes</SelectItem>
                <SelectItem value="Class VI">Class VI</SelectItem>
                <SelectItem value="Class VII">Class VII</SelectItem>
                <SelectItem value="Class VIII">Class VIII</SelectItem>
                <SelectItem value="Class IX">Class IX</SelectItem>
                <SelectItem value="Class X">Class X</SelectItem>
                <SelectItem value="Class XI">Class XI</SelectItem>
                <SelectItem value="Class XII">Class XII</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-[150px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Class</TableHead>
                  <TableHead className="hidden md:table-cell">Admission Date</TableHead>
                  <TableHead>Fee Status</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredAdmissions.map((admission) => (
                  <TableRow key={admission.id}>
                    <TableCell className="font-medium">{admission.id}</TableCell>
                    <TableCell>{admission.name}</TableCell>
                    <TableCell>{admission.class}</TableCell>
                    <TableCell className="hidden md:table-cell">
                      {new Date(admission.admissionDate).toLocaleDateString()}
                    </TableCell>
                    <TableCell>{getFeeStatusBadge(admission.feeStatus)}</TableCell>
                    <TableCell>{getStatusBadge(admission.status)}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="ghost" size="icon" title="View Details">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" title="View Documents">
                          <FileText className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" title="More Options">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </PageTemplate>
  )
}
