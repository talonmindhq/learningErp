"use client"

import { useState } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Calendar, Download, Save, CheckCircle, XCircle, Clock } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"

export default function StaffAttendancePage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [departmentFilter, setDepartmentFilter] = useState("all")
  const [date, setDate] = useState<Date>(new Date())

  // Sample data
  const staff = [
    {
      id: "EMP001",
      name: "Dr. Rajesh Patel",
      department: "Science",
      designation: "Senior Teacher",
      status: "present",
      inTime: "08:45 AM",
      outTime: "04:15 PM",
    },
    {
      id: "EMP002",
      name: "Mrs. Sunita Sharma",
      department: "Mathematics",
      designation: "HOD",
      status: "present",
      inTime: "08:30 AM",
      outTime: "04:30 PM",
    },
    {
      id: "EMP003",
      name: "Mr. Amit Verma",
      department: "English",
      designation: "Teacher",
      status: "late",
      inTime: "09:15 AM",
      outTime: "04:00 PM",
    },
    {
      id: "EMP004",
      name: "Mrs. Priya Gupta",
      department: "Social Studies",
      designation: "Teacher",
      status: "absent",
      inTime: "-",
      outTime: "-",
    },
    {
      id: "EMP005",
      name: "Mr. Vikram Singh",
      department: "Physical Education",
      designation: "Sports Coach",
      status: "present",
      inTime: "08:40 AM",
      outTime: "04:20 PM",
    },
  ]

  const filteredStaff = staff.filter((employee) => {
    const matchesSearch =
      employee.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      employee.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      employee.designation.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesDepartment = departmentFilter === "all" || employee.department === departmentFilter

    return matchesSearch && matchesDepartment
  })

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "present":
        return <Badge className="bg-green-500">Present</Badge>
      case "absent":
        return <Badge className="bg-red-500">Absent</Badge>
      case "late":
        return <Badge className="bg-amber-500">Late</Badge>
      case "half_day":
        return <Badge className="bg-blue-500">Half Day</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
  }

  return (
    <PageTemplate
      title="Staff Attendance"
      description="Manage and track staff attendance"
      breadcrumbs={[
        { title: "Employee Module", href: "/dashboard/staff" },
        { title: "Staff Attendance", href: "/dashboard/staff-attendance", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Export Report",
        icon: <Download className="mr-2 h-4 w-4" />,
      }}
    >
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
        <Card>
          <CardContent className="p-4 flex flex-col items-center justify-center">
            <div className="text-4xl font-bold text-green-500 mb-2">18</div>
            <p className="text-sm text-muted-foreground">Present</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex flex-col items-center justify-center">
            <div className="text-4xl font-bold text-red-500 mb-2">2</div>
            <p className="text-sm text-muted-foreground">Absent</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex flex-col items-center justify-center">
            <div className="text-4xl font-bold text-amber-500 mb-2">3</div>
            <p className="text-sm text-muted-foreground">Late</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex flex-col items-center justify-center">
            <div className="text-4xl font-bold text-blue-500 mb-2">1</div>
            <p className="text-sm text-muted-foreground">Half Day</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
          <div>
            <CardTitle>Staff Attendance</CardTitle>
            <CardDescription>Date: {format(date, "EEEE, MMMM d, yyyy")}</CardDescription>
          </div>
          <div className="flex flex-col sm:flex-row gap-2">
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full sm:w-[180px] justify-start text-left font-normal">
                  <Calendar className="mr-2 h-4 w-4" />
                  {format(date, "PPP")}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                {/* Calendar component would go here */}
                <div className="p-4">
                  <p>Calendar placeholder</p>
                </div>
              </PopoverContent>
            </Popover>
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search staff..."
                className="pl-8 w-full"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="Filter by department" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Departments</SelectItem>
                <SelectItem value="Science">Science</SelectItem>
                <SelectItem value="Mathematics">Mathematics</SelectItem>
                <SelectItem value="English">English</SelectItem>
                <SelectItem value="Social Studies">Social Studies</SelectItem>
                <SelectItem value="Physical Education">Physical Education</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead className="hidden md:table-cell">Department</TableHead>
                  <TableHead className="hidden md:table-cell">Designation</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="hidden md:table-cell">In Time</TableHead>
                  <TableHead className="hidden md:table-cell">Out Time</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredStaff.map((employee) => (
                  <TableRow key={employee.id}>
                    <TableCell className="font-medium">{employee.id}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Avatar className="h-8 w-8">
                          <AvatarImage
                            src={`/abstract-geometric-shapes.png?height=32&width=32&query=${employee.name}`}
                            alt={employee.name}
                          />
                          <AvatarFallback>{getInitials(employee.name)}</AvatarFallback>
                        </Avatar>
                        <span>{employee.name}</span>
                      </div>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">{employee.department}</TableCell>
                    <TableCell className="hidden md:table-cell">{employee.designation}</TableCell>
                    <TableCell>{getStatusBadge(employee.status)}</TableCell>
                    <TableCell className="hidden md:table-cell">
                      {employee.inTime !== "-" ? (
                        <div className="flex items-center">
                          <Clock className="mr-1 h-3 w-3 text-muted-foreground" />
                          <span>{employee.inTime}</span>
                        </div>
                      ) : (
                        "-"
                      )}
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      {employee.outTime !== "-" ? (
                        <div className="flex items-center">
                          <Clock className="mr-1 h-3 w-3 text-muted-foreground" />
                          <span>{employee.outTime}</span>
                        </div>
                      ) : (
                        "-"
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="outline" size="sm" className="h-8 px-2 text-xs">
                          <CheckCircle className="h-3.5 w-3.5 mr-1 text-green-500" />
                          Present
                        </Button>
                        <Button variant="outline" size="sm" className="h-8 px-2 text-xs">
                          <XCircle className="h-3.5 w-3.5 mr-1 text-red-500" />
                          Absent
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          <div className="flex justify-end mt-4">
            <Button className="bg-theme-500 hover:bg-theme-600">
              <Save className="mr-2 h-4 w-4" />
              Save Attendance
            </Button>
          </div>
        </CardContent>
      </Card>
    </PageTemplate>
  )
}
