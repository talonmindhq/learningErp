"use client"

import { useState } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { PlusCircle, Download, FileText, Search, TrendingUp, GraduationCap, BookOpen, Gift } from "lucide-react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

// Sample data for charts
const monthlyIncomeData = [
  { month: "Jan", amount: 450000 },
  { month: "Feb", amount: 520000 },
  { month: "Mar", amount: 480000 },
  { month: "Apr", amount: 540000 },
  { month: "May", amount: 580000 },
  { month: "Jun", amount: 620000 },
]

const incomeCategoryData = [
  { name: "Tuition Fees", value: 450000, color: "#8b5cf6" },
  { name: "Admission Fees", value: 80000, color: "#ec4899" },
  { name: "Donations", value: 45000, color: "#14b8a6" },
  { name: "Canteen", value: 25000, color: "#f59e0b" },
  { name: "Events", value: 15000, color: "#6366f1" },
  { name: "Others", value: 5000, color: "#8b5cf6" },
]

const COLORS = ["#8b5cf6", "#ec4899", "#14b8a6", "#f59e0b", "#6366f1", "#8b5cf6"]

const incomeData = [
  {
    id: "INC001",
    date: "2023-05-15",
    description: "Fee Collection - Grade 10",
    category: "Tuition Fees",
    account: "Operating Account",
    amount: 125000,
    paymentMethod: "Online",
    status: "completed",
    reference: "FC-G10-052023",
  },
  {
    id: "INC002",
    date: "2023-05-20",
    description: "Donation - Alumni Association",
    category: "Donations",
    account: "Development Fund",
    amount: 75000,
    paymentMethod: "Bank Transfer",
    status: "completed",
    reference: "DON-AA-052023",
  },
  {
    id: "INC003",
    date: "2023-05-22",
    description: "New Admissions - Grade 1",
    category: "Admission Fees",
    account: "Operating Account",
    amount: 80000,
    paymentMethod: "Cheque",
    status: "completed",
    reference: "ADM-G1-052023",
  },
  {
    id: "INC004",
    date: "2023-05-23",
    description: "Canteen Revenue - Week 3",
    category: "Canteen",
    account: "Operating Account",
    amount: 25000,
    paymentMethod: "Cash",
    status: "completed",
    reference: "CAN-W3-052023",
  },
  {
    id: "INC005",
    date: "2023-05-25",
    description: "Fee Collection - Grade 11",
    category: "Tuition Fees",
    account: "Operating Account",
    amount: 130000,
    paymentMethod: "Online",
    status: "completed",
    reference: "FC-G11-052023",
  },
  {
    id: "INC006",
    date: "2023-05-26",
    description: "Annual Day Ticket Sales",
    category: "Events",
    account: "Operating Account",
    amount: 15000,
    paymentMethod: "Cash",
    status: "completed",
    reference: "EVT-AD-052023",
  },
  {
    id: "INC007",
    date: "2023-05-28",
    description: "Fee Collection - Grade 12",
    category: "Tuition Fees",
    account: "Operating Account",
    amount: 120000,
    paymentMethod: "Online",
    status: "completed",
    reference: "FC-G12-052023",
  },
]

export default function IncomePage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [dateRange, setDateRange] = useState("this-month")

  const filteredIncome = incomeData.filter((income) => {
    const matchesSearch =
      income.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      income.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      income.reference.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesCategory = categoryFilter === "all" || income.category === categoryFilter

    return matchesSearch && matchesCategory
  })

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(amount)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-500">Completed</Badge>
      case "pending":
        return <Badge className="bg-yellow-500">Pending</Badge>
      case "cancelled":
        return <Badge className="bg-red-500">Cancelled</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  return (
    <PageTemplate
      title="Income"
      description="Track and manage school income sources"
      breadcrumbs={[
        { title: "Dashboard", href: "/dashboard" },
        { title: "General Accounting", href: "/dashboard/accounts" },
        { title: "Income", href: "/dashboard/income", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Add Income",
        icon: <PlusCircle className="mr-2 h-4 w-4" />,
        href: "#",
      }}
    >
      <div className="grid gap-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Income</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹6,20,000</div>
              <p className="text-xs text-green-500">+6.8% from last month</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Tuition Fees</CardTitle>
              <GraduationCap className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹4,50,000</div>
              <p className="text-xs text-muted-foreground">72.6% of total income</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Admission Fees</CardTitle>
              <BookOpen className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹80,000</div>
              <p className="text-xs text-muted-foreground">12.9% of total income</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Donations</CardTitle>
              <Gift className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹45,000</div>
              <p className="text-xs text-muted-foreground">7.3% of total income</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Monthly Income</CardTitle>
              <CardDescription>Income trend for the last 6 months</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={monthlyIncomeData}
                    margin={{
                      top: 20,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip
                      formatter={(value) => formatCurrency(value as number)}
                      labelFormatter={(label) => `Month: ${label}`}
                    />
                    <Legend />
                    <Bar dataKey="amount" name="Income" fill="#8b5cf6" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Income Categories</CardTitle>
              <CardDescription>Distribution by category</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={incomeCategoryData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {incomeCategoryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => formatCurrency(value as number)} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
              <Button variant="outline" size="sm">
                <FileText className="mr-2 h-4 w-4" />
                Print
              </Button>
            </div>
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search income..."
                  className="pl-8 w-full sm:w-[250px]"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-full sm:w-[180px]">
                  <SelectValue placeholder="Filter by category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="Tuition Fees">Tuition Fees</SelectItem>
                  <SelectItem value="Admission Fees">Admission Fees</SelectItem>
                  <SelectItem value="Donations">Donations</SelectItem>
                  <SelectItem value="Canteen">Canteen</SelectItem>
                  <SelectItem value="Events">Events</SelectItem>
                </SelectContent>
              </Select>
              <Select value={dateRange} onValueChange={setDateRange}>
                <SelectTrigger className="w-full sm:w-[180px]">
                  <SelectValue placeholder="Date range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="this-week">This Week</SelectItem>
                  <SelectItem value="this-month">This Month</SelectItem>
                  <SelectItem value="last-month">Last Month</SelectItem>
                  <SelectItem value="custom">Custom Range</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Account</TableHead>
                    <TableHead>Payment Method</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Amount</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredIncome.map((income) => (
                    <TableRow key={income.id}>
                      <TableCell className="font-medium">{income.id}</TableCell>
                      <TableCell>{new Date(income.date).toLocaleDateString()}</TableCell>
                      <TableCell>{income.description}</TableCell>
                      <TableCell>{income.category}</TableCell>
                      <TableCell>{income.account}</TableCell>
                      <TableCell>{income.paymentMethod}</TableCell>
                      <TableCell>{getStatusBadge(income.status)}</TableCell>
                      <TableCell className="text-right font-medium text-green-600">
                        +{formatCurrency(income.amount)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageTemplate>
  )
}
