"use client"

import { useState, useEffect } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Skeleton } from "@/components/ui/skeleton"
import { BarChart, LineChart, Download, FileText } from "lucide-react"

export default function AcademicReportsPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [selectedYear, setSelectedYear] = useState("2023-24")
  const [selectedClass, setSelectedClass] = useState("all")

  // Simulate data loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1000)
    return () => clearTimeout(timer)
  }, [])

  // Sample academic data
  const academicData = {
    averageScore: "78%",
    topPerformers: 125,
    needsImprovement: 85,
    totalStudents: 1250,
    subjectWiseData: [
      { subject: "Mathematics", average: 76, highest: 98, lowest: 45 },
      { subject: "Science", average: 82, highest: 99, lowest: 52 },
      { subject: "English", average: 80, highest: 95, lowest: 55 },
      { subject: "Social Studies", average: 75, highest: 94, lowest: 48 },
      { subject: "Languages", average: 84, highest: 97, lowest: 60 },
    ],
    classWiseData: [
      { class: "Grade 1-5", average: 85, topPerformers: 45, needsImprovement: 15 },
      { class: "Grade 6-8", average: 78, topPerformers: 32, needsImprovement: 22 },
      { class: "Grade 9-10", average: 75, topPerformers: 28, needsImprovement: 25 },
      { class: "Grade 11-12", average: 72, topPerformers: 20, needsImprovement: 23 },
    ],
    examWiseData: [
      { exam: "First Term", average: 76, highest: 98, lowest: 45 },
      { exam: "Mid Term", average: 79, highest: 99, lowest: 48 },
      { exam: "Final Term", average: 81, highest: 97, lowest: 52 },
    ],
  }

  if (isLoading) {
    return (
      <PageTemplate
        title="Academic Reports"
        description="View and analyze academic performance data"
        breadcrumbs={[
          { title: "Dashboard", href: "/dashboard" },
          { title: "Reports", href: "/dashboard/reports" },
          { title: "Academic", href: "/dashboard/reports/academic", isCurrentPage: true },
        ]}
      >
        <div className="space-y-6">
          <Skeleton className="h-10 w-96" />

          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-48 mb-2" />
              <Skeleton className="h-4 w-64" />
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Array(5)
                  .fill(null)
                  .map((_, i) => (
                    <Skeleton key={i} className="h-16 w-full" />
                  ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </PageTemplate>
    )
  }

  return (
    <PageTemplate
      title="Academic Reports"
      description="View and analyze academic performance data"
      breadcrumbs={[
        { title: "Dashboard", href: "/dashboard" },
        { title: "Reports", href: "/dashboard/reports" },
        { title: "Academic", href: "/dashboard/reports/academic", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Generate Report",
        icon: <FileText className="h-4 w-4 mr-2" />,
        onClick: () => alert("Generate custom academic report clicked"),
      }}
    >
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Select value={selectedYear} onValueChange={setSelectedYear}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Academic Year" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2023-24">2023-24</SelectItem>
              <SelectItem value="2022-23">2022-23</SelectItem>
              <SelectItem value="2021-22">2021-22</SelectItem>
            </SelectContent>
          </Select>

          <Select value={selectedClass} onValueChange={setSelectedClass}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Select Class" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Classes</SelectItem>
              <SelectItem value="primary">Primary (1-5)</SelectItem>
              <SelectItem value="middle">Middle (6-8)</SelectItem>
              <SelectItem value="secondary">Secondary (9-10)</SelectItem>
              <SelectItem value="higher">Higher Secondary (11-12)</SelectItem>
            </SelectContent>
          </Select>

          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Average Score</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{academicData.averageScore}</div>
            <p className="text-xs text-muted-foreground">Academic Year {selectedYear}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Top Performers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{academicData.topPerformers}</div>
            <p className="text-xs text-muted-foreground">
              {Math.round((academicData.topPerformers / academicData.totalStudents) * 100)}% of total students
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Needs Improvement</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{academicData.needsImprovement}</div>
            <p className="text-xs text-muted-foreground">
              {Math.round((academicData.needsImprovement / academicData.totalStudents) * 100)}% of total students
            </p>
          </CardContent>
        </Card>
      </div>

      <Card className="mb-6">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <div>
            <CardTitle>Subject-wise Performance</CardTitle>
            <CardDescription>Average scores by subject</CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Subject</TableHead>
                <TableHead>Average Score</TableHead>
                <TableHead>Highest Score</TableHead>
                <TableHead>Lowest Score</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {academicData.subjectWiseData.map((row, index) => (
                <TableRow key={index}>
                  <TableCell className="font-medium">{row.subject}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <div className="w-full max-w-24 h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${
                            row.average >= 80 ? "bg-green-500" : row.average >= 60 ? "bg-yellow-500" : "bg-red-500"
                          }`}
                          style={{ width: `${row.average}%` }}
                        />
                      </div>
                      <span>{row.average}%</span>
                    </div>
                  </TableCell>
                  <TableCell>{row.highest}%</TableCell>
                  <TableCell>{row.lowest}%</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm">
                      View Details
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Class-wise Performance</CardTitle>
            <CardDescription>Academic performance by class groups</CardDescription>
          </CardHeader>
          <CardContent className="h-80 flex items-center justify-center">
            <BarChart className="h-60 w-full text-gray-300" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Exam-wise Performance</CardTitle>
            <CardDescription>Performance trend across different exams</CardDescription>
          </CardHeader>
          <CardContent className="h-80 flex items-center justify-center">
            <LineChart className="h-60 w-full text-gray-300" />
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <div>
            <CardTitle>Class-wise Performance Details</CardTitle>
            <CardDescription>Academic performance metrics by class groups</CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Class Group</TableHead>
                <TableHead>Average Score</TableHead>
                <TableHead>Top Performers</TableHead>
                <TableHead>Needs Improvement</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {academicData.classWiseData.map((row, index) => (
                <TableRow key={index}>
                  <TableCell className="font-medium">{row.class}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <div className="w-full max-w-24 h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${
                            row.average >= 80 ? "bg-green-500" : row.average >= 60 ? "bg-yellow-500" : "bg-red-500"
                          }`}
                          style={{ width: `${row.average}%` }}
                        />
                      </div>
                      <span>{row.average}%</span>
                    </div>
                  </TableCell>
                  <TableCell>{row.topPerformers}</TableCell>
                  <TableCell>{row.needsImprovement}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm">
                      View Details
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </PageTemplate>
  )
}
