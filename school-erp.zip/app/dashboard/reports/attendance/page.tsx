"use client"

import { useState, useEffect } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Skeleton } from "@/components/ui/skeleton"
import { BarChart, LineChart, Download, Calendar } from "lucide-react"

export default function AttendanceReportsPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [selectedYear, setSelectedYear] = useState("2023-24")
  const [selectedMonth, setSelectedMonth] = useState("all")
  const [selectedClass, setSelectedClass] = useState("all")

  // Simulate data loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1000)
    return () => clearTimeout(timer)
  }, [])

  // Sample attendance data
  const attendanceData = {
    overallAttendance: "92%",
    totalStudents: 1250,
    presentToday: 1150,
    absentToday: 100,
    leaveToday: 25,
    classWiseData: [
      { class: "Grade 1-A", strength: 45, present: 42, percentage: 93 },
      { class: "Grade 2-B", strength: 48, present: 45, percentage: 94 },
      { class: "Grade 5-C", strength: 50, present: 48, percentage: 96 },
      { class: "Grade 8-A", strength: 52, present: 46, percentage: 88 },
      { class: "Grade 10-B", strength: 55, present: 48, percentage: 87 },
      { class: "Grade 12-A", strength: 50, present: 44, percentage: 88 },
    ],
    monthlyTrend: [
      { month: "Apr", percentage: 94 },
      { month: "May", percentage: 93 },
      { month: "Jun", percentage: 95 },
      { month: "Jul", percentage: 92 },
      { month: "Aug", percentage: 91 },
      { month: "Sep", percentage: 93 },
      { month: "Oct", percentage: 92 },
      { month: "Nov", percentage: 90 },
      { month: "Dec", percentage: 89 },
      { month: "Jan", percentage: 91 },
      { month: "Feb", percentage: 92 },
      { month: "Mar", percentage: 93 },
    ],
    weekdayData: [
      { day: "Monday", percentage: 94 },
      { day: "Tuesday", percentage: 95 },
      { day: "Wednesday", percentage: 93 },
      { day: "Thursday", percentage: 92 },
      { day: "Friday", percentage: 90 },
      { day: "Saturday", percentage: 88 },
    ],
  }

  if (isLoading) {
    return (
      <PageTemplate
        title="Attendance Reports"
        description="View and analyze attendance data"
        breadcrumbs={[
          { title: "Dashboard", href: "/dashboard" },
          { title: "Reports", href: "/dashboard/reports" },
          { title: "Attendance", href: "/dashboard/reports/attendance", isCurrentPage: true },
        ]}
      >
        <div className="space-y-6">
          <Skeleton className="h-10 w-96" />

          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-48 mb-2" />
              <Skeleton className="h-4 w-64" />
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Array(5)
                  .fill(null)
                  .map((_, i) => (
                    <Skeleton key={i} className="h-16 w-full" />
                  ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </PageTemplate>
    )
  }

  return (
    <PageTemplate
      title="Attendance Reports"
      description="View and analyze attendance data"
      breadcrumbs={[
        { title: "Dashboard", href: "/dashboard" },
        { title: "Reports", href: "/dashboard/reports" },
        { title: "Attendance", href: "/dashboard/reports/attendance", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Generate Report",
        icon: <Calendar className="h-4 w-4 mr-2" />,
        onClick: () => alert("Generate custom attendance report clicked"),
      }}
    >
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Select value={selectedYear} onValueChange={setSelectedYear}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Academic Year" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2023-24">2023-24</SelectItem>
              <SelectItem value="2022-23">2022-23</SelectItem>
              <SelectItem value="2021-22">2021-22</SelectItem>
            </SelectContent>
          </Select>

          <Select value={selectedMonth} onValueChange={setSelectedMonth}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Select Month" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Months</SelectItem>
              <SelectItem value="apr">April</SelectItem>
              <SelectItem value="may">May</SelectItem>
              <SelectItem value="jun">June</SelectItem>
              <SelectItem value="jul">July</SelectItem>
              <SelectItem value="aug">August</SelectItem>
              <SelectItem value="sep">September</SelectItem>
              <SelectItem value="oct">October</SelectItem>
              <SelectItem value="nov">November</SelectItem>
              <SelectItem value="dec">December</SelectItem>
              <SelectItem value="jan">January</SelectItem>
              <SelectItem value="feb">February</SelectItem>
              <SelectItem value="mar">March</SelectItem>
            </SelectContent>
          </Select>

          <Select value={selectedClass} onValueChange={setSelectedClass}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Select Class" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Classes</SelectItem>
              <SelectItem value="primary">Primary (1-5)</SelectItem>
              <SelectItem value="middle">Middle (6-8)</SelectItem>
              <SelectItem value="secondary">Secondary (9-10)</SelectItem>
              <SelectItem value="higher">Higher Secondary (11-12)</SelectItem>
            </SelectContent>
          </Select>

          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Overall Attendance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{attendanceData.overallAttendance}</div>
            <p className="text-xs text-muted-foreground">Academic Year {selectedYear}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Students</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{attendanceData.totalStudents}</div>
            <p className="text-xs text-muted-foreground">Enrolled students</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Present Today</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{attendanceData.presentToday}</div>
            <p className="text-xs text-muted-foreground">
              {Math.round((attendanceData.presentToday / attendanceData.totalStudents) * 100)}% of total
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Absent Today</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{attendanceData.absentToday}</div>
            <p className="text-xs text-muted-foreground">{attendanceData.leaveToday} on leave</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Monthly Attendance Trend</CardTitle>
            <CardDescription>Attendance percentage trend for academic year {selectedYear}</CardDescription>
          </CardHeader>
          <CardContent className="h-80 flex items-center justify-center">
            <LineChart className="h-60 w-full text-gray-300" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Attendance by Day of Week</CardTitle>
            <CardDescription>Average attendance percentage by weekday</CardDescription>
          </CardHeader>
          <CardContent className="h-80 flex items-center justify-center">
            <BarChart className="h-60 w-full text-gray-300" />
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <div>
            <CardTitle>Class-wise Attendance</CardTitle>
            <CardDescription>Attendance statistics by class</CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <Calendar className="h-4 w-4 mr-2" />
              Select Date
            </Button>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Class</TableHead>
                <TableHead>Total Students</TableHead>
                <TableHead>Present</TableHead>
                <TableHead>Attendance %</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {attendanceData.classWiseData.map((row, index) => (
                <TableRow key={index}>
                  <TableCell className="font-medium">{row.class}</TableCell>
                  <TableCell>{row.strength}</TableCell>
                  <TableCell>{row.present}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <div className="w-full max-w-24 h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${
                            row.percentage >= 90
                              ? "bg-green-500"
                              : row.percentage >= 75
                                ? "bg-yellow-500"
                                : "bg-red-500"
                          }`}
                          style={{ width: `${row.percentage}%` }}
                        />
                      </div>
                      <span>{row.percentage}%</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm">
                      View Details
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </PageTemplate>
  )
}
