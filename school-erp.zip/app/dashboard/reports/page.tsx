"use client"

import { useState, useEffect } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Skeleton } from "@/components/ui/skeleton"
import { BarChart, PieChart, LineChart, Download, FileText, Printer, Mail, Calendar, ArrowUpRight } from "lucide-react"

export default function ReportsPage() {
  const [activeTab, setActiveTab] = useState("fee")
  const [isLoading, setIsLoading] = useState(true)
  const [selectedYear, setSelectedYear] = useState("2023-24")
  const [selectedMonth, setSelectedMonth] = useState("all")

  // Simulate data loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1000)
    return () => clearTimeout(timer)
  }, [])

  // Sample fee collection data
  const feeCollectionData = {
    totalCollected: "₹42,75,000",
    pendingAmount: "₹8,25,000",
    collectionRate: "84%",
    monthlyData: [
      { month: "Apr", amount: 450000 },
      { month: "May", amount: 380000 },
      { month: "Jun", amount: 420000 },
      { month: "Jul", amount: 390000 },
      { month: "Aug", amount: 410000 },
      { month: "Sep", amount: 430000 },
      { month: "Oct", amount: 450000 },
      { month: "Nov", amount: 420000 },
      { month: "Dec", amount: 380000 },
      { month: "Jan", amount: 410000 },
      { month: "Feb", amount: 430000 },
      { month: "Mar", amount: 450000 },
    ],
    classWiseData: [
      { class: "Grade 1-5", collected: 1250000, pending: 180000, rate: 87 },
      { class: "Grade 6-8", collected: 980000, pending: 150000, rate: 87 },
      { class: "Grade 9-10", collected: 850000, pending: 220000, rate: 79 },
      { class: "Grade 11-12", collected: 1195000, pending: 275000, rate: 81 },
    ],
    feeTypeData: [
      { type: "Tuition Fee", collected: 2800000, percentage: 65 },
      { type: "Transport Fee", collected: 650000, percentage: 15 },
      { type: "Exam Fee", collected: 430000, percentage: 10 },
      { type: "Library Fee", collected: 215000, percentage: 5 },
      { type: "Other Fees", collected: 215000, percentage: 5 },
    ],
  }

  // Sample attendance data
  const attendanceData = {
    overallAttendance: "92%",
    totalStudents: 1250,
    presentToday: 1150,
    absentToday: 100,
    leaveToday: 25,
    classWiseData: [
      { class: "Grade 1-A", strength: 45, present: 42, percentage: 93 },
      { class: "Grade 2-B", strength: 48, present: 45, percentage: 94 },
      { class: "Grade 5-C", strength: 50, present: 48, percentage: 96 },
      { class: "Grade 8-A", strength: 52, present: 46, percentage: 88 },
      { class: "Grade 10-B", strength: 55, present: 48, percentage: 87 },
      { class: "Grade 12-A", strength: 50, present: 44, percentage: 88 },
    ],
    monthlyTrend: [
      { month: "Apr", percentage: 94 },
      { month: "May", percentage: 93 },
      { month: "Jun", percentage: 95 },
      { month: "Jul", percentage: 92 },
      { month: "Aug", percentage: 91 },
      { month: "Sep", percentage: 93 },
      { month: "Oct", percentage: 92 },
      { month: "Nov", percentage: 90 },
      { month: "Dec", percentage: 89 },
      { month: "Jan", percentage: 91 },
      { month: "Feb", percentage: 92 },
      { month: "Mar", percentage: 93 },
    ],
  }

  // Sample academic data
  const academicData = {
    averageScore: "78%",
    topPerformers: 125,
    needsImprovement: 85,
    subjectWiseData: [
      { subject: "Mathematics", average: 76, highest: 98, lowest: 45 },
      { subject: "Science", average: 82, highest: 99, lowest: 52 },
      { subject: "English", average: 80, highest: 95, lowest: 55 },
      { subject: "Social Studies", average: 75, highest: 94, lowest: 48 },
      { subject: "Languages", average: 84, highest: 97, lowest: 60 },
    ],
    classWiseData: [
      { class: "Grade 1-5", average: 85, topPerformers: 45, needsImprovement: 15 },
      { class: "Grade 6-8", average: 78, topPerformers: 32, needsImprovement: 22 },
      { class: "Grade 9-10", average: 75, topPerformers: 28, needsImprovement: 25 },
      { class: "Grade 11-12", average: 72, topPerformers: 20, needsImprovement: 23 },
    ],
  }

  if (isLoading) {
    return (
      <PageTemplate
        title="Reports"
        description="View and generate comprehensive reports"
        breadcrumbs={[
          { title: "Dashboard", href: "/dashboard" },
          { title: "Reports", href: "/dashboard/reports", isCurrentPage: true },
        ]}
      >
        <div className="space-y-6">
          <Skeleton className="h-10 w-96" />

          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-48 mb-2" />
              <Skeleton className="h-4 w-64" />
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Array(5)
                  .fill(null)
                  .map((_, i) => (
                    <Skeleton key={i} className="h-16 w-full" />
                  ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </PageTemplate>
    )
  }

  return (
    <PageTemplate
      title="Reports"
      description="View and generate comprehensive reports"
      breadcrumbs={[
        { title: "Dashboard", href: "/dashboard" },
        { title: "Reports", href: "/dashboard/reports", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Generate Report",
        icon: <FileText className="h-4 w-4 mr-2" />,
        onClick: () => alert("Generate custom report clicked"),
      }}
    >
      <div className="flex items-center justify-between mb-6">
        <Tabs defaultValue="fee" value={activeTab} onValueChange={setActiveTab} className="w-[500px]">
          <TabsList className="grid grid-cols-3">
            <TabsTrigger value="fee">Fee Reports</TabsTrigger>
            <TabsTrigger value="attendance">Attendance</TabsTrigger>
            <TabsTrigger value="academic">Academic</TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="flex items-center gap-2">
          <Select value={selectedYear} onValueChange={setSelectedYear}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Academic Year" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2023-24">2023-24</SelectItem>
              <SelectItem value="2022-23">2022-23</SelectItem>
              <SelectItem value="2021-22">2021-22</SelectItem>
            </SelectContent>
          </Select>

          <Select value={selectedMonth} onValueChange={setSelectedMonth}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Select Month" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Months</SelectItem>
              <SelectItem value="apr">April</SelectItem>
              <SelectItem value="may">May</SelectItem>
              <SelectItem value="jun">June</SelectItem>
              <SelectItem value="jul">July</SelectItem>
              <SelectItem value="aug">August</SelectItem>
              <SelectItem value="sep">September</SelectItem>
              <SelectItem value="oct">October</SelectItem>
              <SelectItem value="nov">November</SelectItem>
              <SelectItem value="dec">December</SelectItem>
              <SelectItem value="jan">January</SelectItem>
              <SelectItem value="feb">February</SelectItem>
              <SelectItem value="mar">March</SelectItem>
            </SelectContent>
          </Select>

          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Fee Reports Tab */}
      <TabsContent value="fee" className="space-y-6 mt-0">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Collection</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{feeCollectionData.totalCollected}</div>
              <p className="text-xs text-muted-foreground">Academic Year {selectedYear}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Pending Amount</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{feeCollectionData.pendingAmount}</div>
              <p className="text-xs text-muted-foreground">To be collected</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Collection Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{feeCollectionData.collectionRate}</div>
              <p className="text-xs text-muted-foreground">+2.5% from last year</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Monthly Collection Trend</CardTitle>
              <CardDescription>Fee collection trend for academic year {selectedYear}</CardDescription>
            </CardHeader>
            <CardContent className="h-80 flex items-center justify-center">
              <LineChart className="h-60 w-full text-gray-300" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Fee Collection by Type</CardTitle>
              <CardDescription>Distribution of fees collected by fee type</CardDescription>
            </CardHeader>
            <CardContent className="h-80">
              <div className="flex items-center justify-center h-48">
                <PieChart className="h-40 w-40 text-gray-300" />
              </div>
              <div className="space-y-2 mt-4">
                {feeCollectionData.feeTypeData.map((item, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div
                        className={`w-3 h-3 rounded-full ${
                          index === 0
                            ? "bg-blue-500"
                            : index === 1
                              ? "bg-green-500"
                              : index === 2
                                ? "bg-yellow-500"
                                : index === 3
                                  ? "bg-purple-500"
                                  : "bg-red-500"
                        }`}
                      />
                      <span className="text-sm">{item.type}</span>
                    </div>
                    <div className="flex gap-4">
                      <span className="text-sm">₹{(item.collected / 100000).toFixed(1)}L</span>
                      <span className="text-sm text-muted-foreground">{item.percentage}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <div>
              <CardTitle>Class-wise Fee Collection</CardTitle>
              <CardDescription>Fee collection status by class groups</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <Printer className="h-4 w-4 mr-2" />
                Print
              </Button>
              <Button variant="outline" size="sm">
                <Mail className="h-4 w-4 mr-2" />
                Email
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Class Group</TableHead>
                  <TableHead>Collected Amount</TableHead>
                  <TableHead>Pending Amount</TableHead>
                  <TableHead>Collection Rate</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {feeCollectionData.classWiseData.map((row, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-medium">{row.class}</TableCell>
                    <TableCell>₹{(row.collected / 100000).toFixed(2)}L</TableCell>
                    <TableCell>₹{(row.pending / 100000).toFixed(2)}L</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="w-full max-w-24 h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              row.rate >= 90 ? "bg-green-500" : row.rate >= 75 ? "bg-yellow-500" : "bg-red-500"
                            }`}
                            style={{ width: `${row.rate}%` }}
                          />
                        </div>
                        <span>{row.rate}%</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm">
                        View Details
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            {
              title: "Fee Defaulters Report",
              description: "Students with outstanding fee payments",
              icon: <FileText className="h-12 w-12 text-amber-300" />,
              link: "/dashboard/fees/defaulters",
            },
            {
              title: "Fee Collection Register",
              description: "Detailed record of all fee transactions",
              icon: <FileText className="h-12 w-12 text-blue-300" />,
              link: "/dashboard/fees/collect",
            },
            {
              title: "Fee Concession Report",
              description: "Details of fee discounts and concessions",
              icon: <FileText className="h-12 w-12 text-green-300" />,
              link: "/dashboard/fees/advanced",
            },
          ].map((report, i) => (
            <Card key={i} className="hover:bg-gray-50 transition-colors cursor-pointer">
              <CardContent className="p-6 flex flex-col items-center text-center">
                <div className="mb-4">{report.icon}</div>
                <h3 className="font-medium mb-1">{report.title}</h3>
                <p className="text-sm text-muted-foreground mb-4">{report.description}</p>
                <Button variant="outline" size="sm" asChild>
                  <a href={report.link}>
                    <span>View Report</span>
                    <ArrowUpRight className="ml-2 h-4 w-4" />
                  </a>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </TabsContent>

      {/* Attendance Reports Tab */}
      <TabsContent value="attendance" className="space-y-6 mt-0">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Overall Attendance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{attendanceData.overallAttendance}</div>
              <p className="text-xs text-muted-foreground">Academic Year {selectedYear}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Students</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{attendanceData.totalStudents}</div>
              <p className="text-xs text-muted-foreground">Enrolled students</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Present Today</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{attendanceData.presentToday}</div>
              <p className="text-xs text-muted-foreground">
                {Math.round((attendanceData.presentToday / attendanceData.totalStudents) * 100)}% of total
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Absent Today</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{attendanceData.absentToday}</div>
              <p className="text-xs text-muted-foreground">{attendanceData.leaveToday} on leave</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Monthly Attendance Trend</CardTitle>
              <CardDescription>Attendance percentage trend for academic year {selectedYear}</CardDescription>
            </CardHeader>
            <CardContent className="h-80 flex items-center justify-center">
              <LineChart className="h-60 w-full text-gray-300" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Attendance by Day of Week</CardTitle>
              <CardDescription>Average attendance percentage by weekday</CardDescription>
            </CardHeader>
            <CardContent className="h-80 flex items-center justify-center">
              <BarChart className="h-60 w-full text-gray-300" />
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <div>
              <CardTitle>Class-wise Attendance</CardTitle>
              <CardDescription>Attendance statistics by class</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <Calendar className="h-4 w-4 mr-2" />
                Select Date
              </Button>
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Class</TableHead>
                  <TableHead>Total Students</TableHead>
                  <TableHead>Present</TableHead>
                  <TableHead>Attendance %</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {attendanceData.classWiseData.map((row, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-medium">{row.class}</TableCell>
                    <TableCell>{row.strength}</TableCell>
                    <TableCell>{row.present}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="w-full max-w-24 h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              row.percentage >= 90
                                ? "bg-green-500"
                                : row.percentage >= 75
                                  ? "bg-yellow-500"
                                  : "bg-red-500"
                            }`}
                            style={{ width: `${row.percentage}%` }}
                          />
                        </div>
                        <span>{row.percentage}%</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm">
                        View Details
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </TabsContent>

      {/* Academic Reports Tab */}
      <TabsContent value="academic" className="space-y-6 mt-0">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Average Score</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{academicData.averageScore}</div>
              <p className="text-xs text-muted-foreground">Academic Year {selectedYear}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Top Performers</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{academicData.topPerformers}</div>
              <p className="text-xs text-muted-foreground">
                {Math.round((academicData.topPerformers / attendanceData.totalStudents) * 100)}% of total students
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Needs Improvement</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{academicData.needsImprovement}</div>
              <p className="text-xs text-muted-foreground">
                {Math.round((academicData.needsImprovement / attendanceData.totalStudents) * 100)}% of total students
              </p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <div>
              <CardTitle>Subject-wise Performance</CardTitle>
              <CardDescription>Average scores by subject</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Select defaultValue="all">
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="Select Class" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Classes</SelectItem>
                  <SelectItem value="primary">Primary (1-5)</SelectItem>
                  <SelectItem value="middle">Middle (6-8)</SelectItem>
                  <SelectItem value="secondary">Secondary (9-10)</SelectItem>
                  <SelectItem value="higher">Higher Secondary (11-12)</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Subject</TableHead>
                  <TableHead>Average Score</TableHead>
                  <TableHead>Highest Score</TableHead>
                  <TableHead>Lowest Score</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {academicData.subjectWiseData.map((row, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-medium">{row.subject}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="w-full max-w-24 h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              row.average >= 80 ? "bg-green-500" : row.average >= 60 ? "bg-yellow-500" : "bg-red-500"
                            }`}
                            style={{ width: `${row.average}%` }}
                          />
                        </div>
                        <span>{row.average}%</span>
                      </div>
                    </TableCell>
                    <TableCell>{row.highest}%</TableCell>
                    <TableCell>{row.lowest}%</TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm">
                        View Details
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <div>
              <CardTitle>Class-wise Performance</CardTitle>
              <CardDescription>Academic performance by class groups</CardDescription>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex items-center justify-center h-80">
                <BarChart className="h-60 w-full text-gray-300" />
              </div>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Class Group</TableHead>
                    <TableHead>Average Score</TableHead>
                    <TableHead>Top Performers</TableHead>
                    <TableHead>Needs Improvement</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {academicData.classWiseData.map((row, index) => (
                    <TableRow key={index}>
                      <TableCell className="font-medium">{row.class}</TableCell>
                      <TableCell>{row.average}%</TableCell>
                      <TableCell>{row.topPerformers}</TableCell>
                      <TableCell>{row.needsImprovement}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            {
              title: "Exam Results Report",
              description: "Detailed analysis of examination results",
              icon: <FileText className="h-12 w-12 text-purple-300" />,
              link: "/dashboard/exams/results",
            },
            {
              title: "Student Progress Report",
              description: "Individual student progress tracking",
              icon: <FileText className="h-12 w-12 text-green-300" />,
              link: "/dashboard/report-cards",
            },
            {
              title: "Class Comparison Report",
              description: "Compare performance across classes",
              icon: <FileText className="h-12 w-12 text-blue-300" />,
              link: "/dashboard/exams",
            },
          ].map((report, i) => (
            <Card key={i} className="hover:bg-gray-50 transition-colors cursor-pointer">
              <CardContent className="p-6 flex flex-col items-center text-center">
                <div className="mb-4">{report.icon}</div>
                <h3 className="font-medium mb-1">{report.title}</h3>
                <p className="text-sm text-muted-foreground mb-4">{report.description}</p>
                <Button variant="outline" size="sm" asChild>
                  <a href={report.link}>
                    <span>View Report</span>
                    <ArrowUpRight className="ml-2 h-4 w-4" />
                  </a>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </TabsContent>
    </PageTemplate>
  )
}
