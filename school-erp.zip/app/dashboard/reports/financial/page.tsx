"use client"

import { useState, useEffect } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Skeleton } from "@/components/ui/skeleton"
import { BarChart, PieChart, LineChart, Download, FileText, Printer, Mail } from "lucide-react"

export default function FinancialReportsPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [selectedYear, setSelectedYear] = useState("2023-24")
  const [selectedMonth, setSelectedMonth] = useState("all")

  // Simulate data loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1000)
    return () => clearTimeout(timer)
  }, [])

  // Sample financial data
  const financialData = {
    totalIncome: "₹58,75,000",
    totalExpenses: "₹42,50,000",
    netBalance: "₹16,25,000",
    monthlyData: [
      { month: "Apr", income: 450000, expenses: 380000 },
      { month: "May", income: 480000, expenses: 350000 },
      { month: "Jun", income: 520000, expenses: 420000 },
      { month: "Jul", income: 490000, expenses: 390000 },
      { month: "Aug", income: 510000, expenses: 410000 },
      { month: "Sep", income: 530000, expenses: 430000 },
      { month: "Oct", income: 550000, expenses: 450000 },
      { month: "Nov", income: 520000, expenses: 420000 },
      { month: "Dec", income: 480000, expenses: 380000 },
      { month: "Jan", income: 510000, expenses: 410000 },
      { month: "Feb", income: 530000, expenses: 430000 },
      { month: "Mar", income: 550000, expenses: 450000 },
    ],
    incomeSourceData: [
      { source: "Fee Collection", amount: 4275000, percentage: 73 },
      { source: "Donations", amount: 850000, percentage: 14 },
      { source: "Government Grants", amount: 450000, percentage: 8 },
      { source: "Other Income", amount: 300000, percentage: 5 },
    ],
    expenseTypeData: [
      { type: "Salaries", amount: 2550000, percentage: 60 },
      { type: "Infrastructure", amount: 850000, percentage: 20 },
      { type: "Utilities", amount: 425000, percentage: 10 },
      { type: "Educational Materials", amount: 255000, percentage: 6 },
      { type: "Other Expenses", amount: 170000, percentage: 4 },
    ],
  }

  if (isLoading) {
    return (
      <PageTemplate
        title="Financial Reports"
        description="View and analyze financial data"
        breadcrumbs={[
          { title: "Dashboard", href: "/dashboard" },
          { title: "Reports", href: "/dashboard/reports" },
          { title: "Financial", href: "/dashboard/reports/financial", isCurrentPage: true },
        ]}
      >
        <div className="space-y-6">
          <Skeleton className="h-10 w-96" />

          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-48 mb-2" />
              <Skeleton className="h-4 w-64" />
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Array(5)
                  .fill(null)
                  .map((_, i) => (
                    <Skeleton key={i} className="h-16 w-full" />
                  ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </PageTemplate>
    )
  }

  return (
    <PageTemplate
      title="Financial Reports"
      description="View and analyze financial data"
      breadcrumbs={[
        { title: "Dashboard", href: "/dashboard" },
        { title: "Reports", href: "/dashboard/reports" },
        { title: "Financial", href: "/dashboard/reports/financial", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Generate Report",
        icon: <FileText className="h-4 w-4 mr-2" />,
        onClick: () => alert("Generate custom financial report clicked"),
      }}
    >
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Select value={selectedYear} onValueChange={setSelectedYear}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Academic Year" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2023-24">2023-24</SelectItem>
              <SelectItem value="2022-23">2022-23</SelectItem>
              <SelectItem value="2021-22">2021-22</SelectItem>
            </SelectContent>
          </Select>

          <Select value={selectedMonth} onValueChange={setSelectedMonth}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Select Month" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Months</SelectItem>
              <SelectItem value="apr">April</SelectItem>
              <SelectItem value="may">May</SelectItem>
              <SelectItem value="jun">June</SelectItem>
              <SelectItem value="jul">July</SelectItem>
              <SelectItem value="aug">August</SelectItem>
              <SelectItem value="sep">September</SelectItem>
              <SelectItem value="oct">October</SelectItem>
              <SelectItem value="nov">November</SelectItem>
              <SelectItem value="dec">December</SelectItem>
              <SelectItem value="jan">January</SelectItem>
              <SelectItem value="feb">February</SelectItem>
              <SelectItem value="mar">March</SelectItem>
            </SelectContent>
          </Select>

          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Income</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{financialData.totalIncome}</div>
            <p className="text-xs text-muted-foreground">Academic Year {selectedYear}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Expenses</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{financialData.totalExpenses}</div>
            <p className="text-xs text-muted-foreground">Academic Year {selectedYear}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Net Balance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{financialData.netBalance}</div>
            <p className="text-xs text-muted-foreground">+8.5% from last year</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Monthly Income vs Expenses</CardTitle>
            <CardDescription>Financial trend for academic year {selectedYear}</CardDescription>
          </CardHeader>
          <CardContent className="h-80 flex items-center justify-center">
            <LineChart className="h-60 w-full text-gray-300" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Income Sources</CardTitle>
            <CardDescription>Distribution of income by source</CardDescription>
          </CardHeader>
          <CardContent className="h-80">
            <div className="flex items-center justify-center h-48">
              <PieChart className="h-40 w-40 text-gray-300" />
            </div>
            <div className="space-y-2 mt-4">
              {financialData.incomeSourceData.map((item, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-3 h-3 rounded-full ${
                        index === 0
                          ? "bg-blue-500"
                          : index === 1
                            ? "bg-green-500"
                            : index === 2
                              ? "bg-yellow-500"
                              : "bg-purple-500"
                      }`}
                    />
                    <span className="text-sm">{item.source}</span>
                  </div>
                  <div className="flex gap-4">
                    <span className="text-sm">₹{(item.amount / 100000).toFixed(1)}L</span>
                    <span className="text-sm text-muted-foreground">{item.percentage}%</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="mb-6">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <div>
            <CardTitle>Expense Breakdown</CardTitle>
            <CardDescription>Distribution of expenses by category</CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <Printer className="h-4 w-4 mr-2" />
              Print
            </Button>
            <Button variant="outline" size="sm">
              <Mail className="h-4 w-4 mr-2" />
              Email
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex items-center justify-center h-80">
              <BarChart className="h-60 w-full text-gray-300" />
            </div>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Expense Type</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Percentage</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {financialData.expenseTypeData.map((row, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-medium">{row.type}</TableCell>
                    <TableCell>₹{(row.amount / 100000).toFixed(2)}L</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="w-full max-w-24 h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              index === 0
                                ? "bg-blue-500"
                                : index === 1
                                  ? "bg-green-500"
                                  : index === 2
                                    ? "bg-yellow-500"
                                    : index === 3
                                      ? "bg-purple-500"
                                      : "bg-red-500"
                            }`}
                            style={{ width: `${row.percentage}%` }}
                          />
                        </div>
                        <span>{row.percentage}%</span>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <div>
            <CardTitle>Monthly Financial Summary</CardTitle>
            <CardDescription>Detailed monthly income and expenses</CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Month</TableHead>
                <TableHead>Income</TableHead>
                <TableHead>Expenses</TableHead>
                <TableHead>Net Balance</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {financialData.monthlyData.map((row, index) => (
                <TableRow key={index}>
                  <TableCell className="font-medium">{row.month}</TableCell>
                  <TableCell>₹{(row.income / 100000).toFixed(2)}L</TableCell>
                  <TableCell>₹{(row.expenses / 100000).toFixed(2)}L</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <span className={row.income - row.expenses > 0 ? "text-green-600" : "text-red-600"}>
                        ₹{((row.income - row.expenses) / 100000).toFixed(2)}L
                      </span>
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm">
                      View Details
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </PageTemplate>
  )
}
