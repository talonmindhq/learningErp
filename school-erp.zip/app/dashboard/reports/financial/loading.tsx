import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"

export default function FinancialReportsLoading() {
  return (
    <PageTemplate
      title="Financial Reports"
      description="View and analyze financial data"
      breadcrumbs={[
        { title: "Dashboard", href: "/dashboard" },
        { title: "Reports", href: "/dashboard/reports" },
        { title: "Financial", href: "/dashboard/reports/financial", isCurrentPage: true },
      ]}
    >
      <div className="space-y-6">
        <Skeleton className="h-10 w-96" />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {Array(3)
            .fill(null)
            .map((_, i) => (
              <Card key={i}>
                <CardHeader className="pb-2">
                  <Skeleton className="h-4 w-24 mb-1" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-8 w-20 mb-1" />
                  <Skeleton className="h-3 w-32" />
                </CardContent>
              </Card>
            ))}
        </div>

        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-48 mb-2" />
            <Skeleton className="h-4 w-64" />
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Array(5)
                .fill(null)
                .map((_, i) => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </PageTemplate>
  )
}
