"use client"

import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Progress } from "@/components/ui/progress"
import {
  Calendar,
  Mail,
  Phone,
  MapPin,
  Download,
  Edit,
  Printer,
  User,
  BookOpen,
  CreditCard,
  Clock,
  FileText,
} from "lucide-react"

export default function StudentProfilePage() {
  // Sample student data
  const student = {
    id: "STU001",
    name: "Rahul Sharma",
    class: "Class X",
    section: "A",
    rollNo: "101",
    admissionNo: "ADM2023101",
    gender: "Male",
    dob: "2008-05-15",
    bloodGroup: "B+",
    address: "123, Green Park, New Delhi",
    city: "New Delhi",
    state: "Delhi",
    pincode: "110016",
    phone: "+91 9876543210",
    email: "rahul.s@example.com",
    fatherName: "Rajesh Sharma",
    fatherOccupation: "Business",
    fatherPhone: "+91 9876543211",
    fatherEmail: "rajesh.s@example.com",
    motherName: "Sunita Sharma",
    motherOccupation: "Teacher",
    motherPhone: "+91 9876543212",
    motherEmail: "sunita.s@example.com",
    joinDate: "2020-04-01",
    status: "active",
  }

  // Sample attendance data
  const attendanceData = [
    { month: "April", present: 22, total: 24, percentage: 91.67 },
    { month: "May", present: 20, total: 22, percentage: 90.91 },
    { month: "June", present: 18, total: 20, percentage: 90.0 },
    { month: "July", present: 23, total: 26, percentage: 88.46 },
    { month: "August", present: 21, total: 22, percentage: 95.45 },
  ]

  // Sample fee data
  const feeData = [
    { term: "Term 1", amount: "₹25,000", dueDate: "2023-04-15", status: "paid", paidDate: "2023-04-10" },
    { term: "Term 2", amount: "₹25,000", dueDate: "2023-07-15", status: "paid", paidDate: "2023-07-12" },
    { term: "Term 3", amount: "₹25,000", dueDate: "2023-10-15", status: "pending", paidDate: "-" },
    { term: "Term 4", amount: "₹25,000", dueDate: "2024-01-15", status: "pending", paidDate: "-" },
  ]

  // Sample exam results
  const examResults = [
    {
      exam: "First Term",
      subjects: [
        { name: "Mathematics", marks: 85, maxMarks: 100, grade: "A" },
        { name: "Science", marks: 78, maxMarks: 100, grade: "B" },
        { name: "English", marks: 92, maxMarks: 100, grade: "A+" },
        { name: "Social Studies", marks: 75, maxMarks: 100, grade: "B" },
        { name: "Hindi", marks: 88, maxMarks: 100, grade: "A" },
      ],
      total: 418,
      maxTotal: 500,
      percentage: 83.6,
      grade: "A",
      rank: 5,
    },
    {
      exam: "Mid Term",
      subjects: [
        { name: "Mathematics", marks: 90, maxMarks: 100, grade: "A+" },
        { name: "Science", marks: 82, maxMarks: 100, grade: "A" },
        { name: "English", marks: 88, maxMarks: 100, grade: "A" },
        { name: "Social Studies", marks: 79, maxMarks: 100, grade: "B" },
        { name: "Hindi", marks: 85, maxMarks: 100, grade: "A" },
      ],
      total: 424,
      maxTotal: 500,
      percentage: 84.8,
      grade: "A",
      rank: 3,
    },
  ]

  return (
    <PageTemplate
      title="Student Profile"
      description="View and manage student information"
      breadcrumbs={[
        { title: "Student Manager", href: "/dashboard/students" },
        { title: "Student Profile", href: "/dashboard/student-profile", isCurrentPage: true },
      ]}
    >
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="md:col-span-1">
          <CardContent className="p-6">
            <div className="flex flex-col items-center text-center">
              <Avatar className="h-24 w-24 mb-4">
                <AvatarImage
                  src={`/abstract-geometric-shapes.png?height=96&width=96&query=${student.name}`}
                  alt={student.name}
                />
                <AvatarFallback className="text-xl">
                  {student.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>
              <h2 className="text-xl font-bold">{student.name}</h2>
              <p className="text-sm text-muted-foreground mb-2">
                {student.class} - {student.section}
              </p>
              <Badge className="bg-green-500 mb-4">Active</Badge>

              <div className="grid grid-cols-2 gap-2 w-full text-sm mb-4">
                <div className="text-left text-muted-foreground">Roll No:</div>
                <div className="text-right font-medium">{student.rollNo}</div>

                <div className="text-left text-muted-foreground">Admission No:</div>
                <div className="text-right font-medium">{student.admissionNo}</div>

                <div className="text-left text-muted-foreground">Join Date:</div>
                <div className="text-right font-medium">{new Date(student.joinDate).toLocaleDateString()}</div>
              </div>

              <div className="flex gap-2 mt-2">
                <Button variant="outline" size="sm">
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </Button>
                <Button variant="outline" size="sm">
                  <Printer className="h-4 w-4 mr-2" />
                  Print
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Personal Information</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Full Name</h3>
                  <p>{student.name}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Date of Birth</h3>
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
                    <p>{new Date(student.dob).toLocaleDateString()}</p>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Gender</h3>
                  <div className="flex items-center">
                    <User className="h-4 w-4 mr-2 text-muted-foreground" />
                    <p>{student.gender}</p>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Blood Group</h3>
                  <p>{student.bloodGroup}</p>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Email</h3>
                  <div className="flex items-center">
                    <Mail className="h-4 w-4 mr-2 text-muted-foreground" />
                    <p>{student.email}</p>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Phone</h3>
                  <div className="flex items-center">
                    <Phone className="h-4 w-4 mr-2 text-muted-foreground" />
                    <p>{student.phone}</p>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Address</h3>
                  <div className="flex items-start">
                    <MapPin className="h-4 w-4 mr-2 text-muted-foreground mt-1" />
                    <p>
                      {student.address}, {student.city}, {student.state} - {student.pincode}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="parents" className="mt-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="parents">Parents Info</TabsTrigger>
          <TabsTrigger value="attendance">Attendance</TabsTrigger>
          <TabsTrigger value="fees">Fees</TabsTrigger>
          <TabsTrigger value="results">Results</TabsTrigger>
        </TabsList>

        <TabsContent value="parents">
          <Card>
            <CardHeader>
              <CardTitle>Parents Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <h3 className="font-medium border-b pb-2">Father's Details</h3>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Name</h4>
                    <p>{student.fatherName}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Occupation</h4>
                    <p>{student.fatherOccupation}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Phone</h4>
                    <div className="flex items-center">
                      <Phone className="h-4 w-4 mr-2 text-muted-foreground" />
                      <p>{student.fatherPhone}</p>
                    </div>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Email</h4>
                    <div className="flex items-center">
                      <Mail className="h-4 w-4 mr-2 text-muted-foreground" />
                      <p>{student.fatherEmail}</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="font-medium border-b pb-2">Mother's Details</h3>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Name</h4>
                    <p>{student.motherName}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Occupation</h4>
                    <p>{student.motherOccupation}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Phone</h4>
                    <div className="flex items-center">
                      <Phone className="h-4 w-4 mr-2 text-muted-foreground" />
                      <p>{student.motherPhone}</p>
                    </div>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Email</h4>
                    <div className="flex items-center">
                      <Mail className="h-4 w-4 mr-2 text-muted-foreground" />
                      <p>{student.motherEmail}</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="attendance">
          <Card>
            <CardHeader>
              <CardTitle>Attendance Record</CardTitle>
              <CardDescription>Academic Year 2023-2024</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Month</TableHead>
                      <TableHead>Present</TableHead>
                      <TableHead>Total Days</TableHead>
                      <TableHead>Percentage</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {attendanceData.map((record) => (
                      <TableRow key={record.month}>
                        <TableCell className="font-medium">{record.month}</TableCell>
                        <TableCell>{record.present}</TableCell>
                        <TableCell>{record.total}</TableCell>
                        <TableCell>{record.percentage.toFixed(2)}%</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Progress value={record.percentage} className="h-2 w-20" />
                            <Badge
                              className={
                                record.percentage >= 90
                                  ? "bg-green-500"
                                  : record.percentage >= 75
                                    ? "bg-amber-500"
                                    : "bg-red-500"
                              }
                            >
                              {record.percentage >= 90 ? "Excellent" : record.percentage >= 75 ? "Good" : "Poor"}
                            </Badge>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="fees">
          <Card>
            <CardHeader>
              <CardTitle>Fee Details</CardTitle>
              <CardDescription>Academic Year 2023-2024</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Term</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Due Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Paid Date</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {feeData.map((fee) => (
                      <TableRow key={fee.term}>
                        <TableCell className="font-medium">{fee.term}</TableCell>
                        <TableCell>{fee.amount}</TableCell>
                        <TableCell>{new Date(fee.dueDate).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <Badge className={fee.status === "paid" ? "bg-green-500" : "bg-amber-500"}>
                            {fee.status === "paid" ? "Paid" : "Pending"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {fee.paidDate !== "-" ? new Date(fee.paidDate).toLocaleDateString() : "-"}
                        </TableCell>
                        <TableCell className="text-right">
                          {fee.status === "paid" ? (
                            <Button variant="outline" size="sm">
                              <Download className="h-4 w-4 mr-2" />
                              Receipt
                            </Button>
                          ) : (
                            <Button size="sm" className="bg-theme-500 hover:bg-theme-600">
                              <CreditCard className="h-4 w-4 mr-2" />
                              Pay Now
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="results">
          <Card>
            <CardHeader>
              <CardTitle>Examination Results</CardTitle>
              <CardDescription>Academic Year 2023-2024</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {examResults.map((result, index) => (
                  <div key={index} className="border rounded-md p-4">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                      <div>
                        <h3 className="text-lg font-medium">{result.exam}</h3>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <BookOpen className="h-4 w-4 mr-1" />
                          <span>Class {student.class}</span>
                          <span className="mx-2">•</span>
                          <Clock className="h-4 w-4 mr-1" />
                          <span>2023-2024</span>
                        </div>
                      </div>
                      <div className="mt-2 md:mt-0 flex flex-col items-start md:items-end">
                        <div className="flex items-center">
                          <span className="text-sm text-muted-foreground mr-2">Percentage:</span>
                          <span className="font-medium">{result.percentage}%</span>
                        </div>
                        <div className="flex items-center">
                          <span className="text-sm text-muted-foreground mr-2">Grade:</span>
                          <Badge className="bg-theme-500">{result.grade}</Badge>
                        </div>
                        <div className="flex items-center">
                          <span className="text-sm text-muted-foreground mr-2">Rank:</span>
                          <span className="font-medium">{result.rank}</span>
                        </div>
                      </div>
                    </div>

                    <div className="rounded-md border">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Subject</TableHead>
                            <TableHead className="text-right">Marks</TableHead>
                            <TableHead className="text-right">Max Marks</TableHead>
                            <TableHead className="text-right">Grade</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {result.subjects.map((subject, subIndex) => (
                            <TableRow key={subIndex}>
                              <TableCell className="font-medium">{subject.name}</TableCell>
                              <TableCell className="text-right">{subject.marks}</TableCell>
                              <TableCell className="text-right">{subject.maxMarks}</TableCell>
                              <TableCell className="text-right">
                                <Badge
                                  className={
                                    subject.grade === "A+"
                                      ? "bg-green-500"
                                      : subject.grade === "A"
                                        ? "bg-green-400"
                                        : subject.grade === "B+"
                                          ? "bg-blue-500"
                                          : subject.grade === "B"
                                            ? "bg-blue-400"
                                            : subject.grade === "C"
                                              ? "bg-amber-500"
                                              : "bg-red-500"
                                  }
                                >
                                  {subject.grade}
                                </Badge>
                              </TableCell>
                            </TableRow>
                          ))}
                          <TableRow>
                            <TableCell className="font-bold">Total</TableCell>
                            <TableCell className="text-right font-bold">{result.total}</TableCell>
                            <TableCell className="text-right font-bold">{result.maxTotal}</TableCell>
                            <TableCell className="text-right font-bold">{result.percentage}%</TableCell>
                          </TableRow>
                        </TableBody>
                      </Table>
                    </div>

                    <div className="flex justify-end mt-4">
                      <Button variant="outline" size="sm">
                        <FileText className="h-4 w-4 mr-2" />
                        Download Report Card
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </PageTemplate>
  )
}
