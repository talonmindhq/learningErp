"use client"

import { useState } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { PlusCircle, Download, FileText, Search, CreditCard, IndianRupee, Building, Landmark } from "lucide-react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Line,
} from "recharts"

// Sample data for charts
const monthlyBalanceData = [
  { month: "Jan", income: 450000, expenses: 320000, balance: 130000 },
  { month: "Feb", income: 520000, expenses: 380000, balance: 140000 },
  { month: "Mar", income: 480000, expenses: 350000, balance: 130000 },
  { month: "Apr", income: 540000, expenses: 410000, balance: 130000 },
  { month: "May", income: 580000, expenses: 420000, balance: 160000 },
  { month: "Jun", income: 620000, expenses: 450000, balance: 170000 },
]

const accountDistributionData = [
  { name: "Operating Account", value: 650000, color: "#8b5cf6" },
  { name: "Salary Account", value: 450000, color: "#ec4899" },
  { name: "Development Fund", value: 350000, color: "#14b8a6" },
  { name: "Emergency Fund", value: 200000, color: "#f59e0b" },
  { name: "Scholarship Fund", value: 150000, color: "#6366f1" },
]

const COLORS = ["#8b5cf6", "#ec4899", "#14b8a6", "#f59e0b", "#6366f1"]

const transactionData = [
  {
    id: "TRX001",
    date: "2023-05-15",
    description: "Fee Collection - Grade 10",
    type: "income",
    account: "Operating Account",
    amount: 125000,
    category: "Fee",
    reference: "FC-G10-052023",
  },
  {
    id: "TRX002",
    date: "2023-05-16",
    description: "Staff Salary - May 2023",
    type: "expense",
    account: "Salary Account",
    amount: 350000,
    category: "Salary",
    reference: "SAL-052023",
  },
  {
    id: "TRX003",
    date: "2023-05-18",
    description: "Library Books Purchase",
    type: "expense",
    account: "Development Fund",
    amount: 45000,
    category: "Academic",
    reference: "PO-LIB-052023",
  },
  {
    id: "TRX004",
    date: "2023-05-20",
    description: "Donation - Alumni Association",
    type: "income",
    account: "Development Fund",
    amount: 75000,
    category: "Donation",
    reference: "DON-AA-052023",
  },
  {
    id: "TRX005",
    date: "2023-05-22",
    description: "Electricity Bill - May 2023",
    type: "expense",
    account: "Operating Account",
    amount: 35000,
    category: "Utility",
    reference: "UTIL-EB-052023",
  },
  {
    id: "TRX006",
    date: "2023-05-25",
    description: "Fee Collection - Grade 11",
    type: "income",
    account: "Operating Account",
    amount: 130000,
    category: "Fee",
    reference: "FC-G11-052023",
  },
  {
    id: "TRX007",
    date: "2023-05-28",
    description: "Campus Maintenance",
    type: "expense",
    account: "Operating Account",
    amount: 28000,
    category: "Maintenance",
    reference: "MAINT-052023",
  },
]

const accountsData = [
  {
    id: "ACC001",
    name: "Operating Account",
    type: "Current",
    bank: "State Bank of India",
    accountNumber: "XXXXXXXX1234",
    balance: 650000,
    lastUpdated: "2023-05-28",
  },
  {
    id: "ACC002",
    name: "Salary Account",
    type: "Current",
    bank: "HDFC Bank",
    accountNumber: "XXXXXXXX5678",
    balance: 450000,
    lastUpdated: "2023-05-28",
  },
  {
    id: "ACC003",
    name: "Development Fund",
    type: "Savings",
    bank: "ICICI Bank",
    accountNumber: "XXXXXXXX9012",
    balance: 350000,
    lastUpdated: "2023-05-28",
  },
  {
    id: "ACC004",
    name: "Emergency Fund",
    type: "Fixed Deposit",
    bank: "Axis Bank",
    accountNumber: "XXXXXXXX3456",
    balance: 200000,
    lastUpdated: "2023-05-28",
  },
  {
    id: "ACC005",
    name: "Scholarship Fund",
    type: "Savings",
    bank: "Punjab National Bank",
    accountNumber: "XXXXXXXX7890",
    balance: 150000,
    lastUpdated: "2023-05-28",
  },
]

export default function AccountsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [accountFilter, setAccountFilter] = useState("all")
  const [dateRange, setDateRange] = useState("this-month")

  const filteredTransactions = transactionData.filter((transaction) => {
    const matchesSearch =
      transaction.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      transaction.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      transaction.reference.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesAccount = accountFilter === "all" || transaction.account === accountFilter

    return matchesSearch && matchesAccount
  })

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(amount)
  }

  const getTransactionBadge = (type: string) => {
    switch (type) {
      case "income":
        return <Badge className="bg-green-500">Income</Badge>
      case "expense":
        return <Badge className="bg-red-500">Expense</Badge>
      default:
        return <Badge>{type}</Badge>
    }
  }

  return (
    <PageTemplate
      title="Accounts"
      description="Manage school accounts and financial transactions"
      breadcrumbs={[
        { title: "Dashboard", href: "/dashboard" },
        { title: "General Accounting", href: "/dashboard/accounts" },
        { title: "Accounts", href: "/dashboard/accounts", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Add Account",
        icon: <PlusCircle className="mr-2 h-4 w-4" />,
        href: "#",
      }}
    >
      <div className="grid gap-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Balance</CardTitle>
              <IndianRupee className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹18,00,000</div>
              <p className="text-xs text-muted-foreground">+₹2,50,000 from last month</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Accounts</CardTitle>
              <Building className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">5</div>
              <p className="text-xs text-muted-foreground">Across 4 banks</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Monthly Income</CardTitle>
              <CreditCard className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹6,20,000</div>
              <p className="text-xs text-green-500">+6.8% from last month</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Monthly Expenses</CardTitle>
              <Landmark className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹4,50,000</div>
              <p className="text-xs text-red-500">+7.1% from last month</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Monthly Balance Overview</CardTitle>
              <CardDescription>Income vs Expenses for the last 6 months</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={monthlyBalanceData}
                    margin={{
                      top: 20,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip
                      formatter={(value) => formatCurrency(value as number)}
                      labelFormatter={(label) => `Month: ${label}`}
                    />
                    <Legend />
                    <Bar dataKey="income" name="Income" fill="#8b5cf6" />
                    <Bar dataKey="expenses" name="Expenses" fill="#ec4899" />
                    <Line type="monotone" dataKey="balance" name="Balance" stroke="#14b8a6" strokeWidth={2} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Account Distribution</CardTitle>
              <CardDescription>Balance distribution across accounts</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={accountDistributionData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {accountDistributionData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => formatCurrency(value as number)} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="accounts" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="accounts">Accounts</TabsTrigger>
            <TabsTrigger value="transactions">Transactions</TabsTrigger>
          </TabsList>

          <TabsContent value="accounts" className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" />
                  Export
                </Button>
                <Button variant="outline" size="sm">
                  <FileText className="mr-2 h-4 w-4" />
                  Print
                </Button>
              </div>
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search accounts..."
                  className="pl-8 w-full sm:w-[250px]"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>

            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Account Name</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Bank</TableHead>
                      <TableHead>Account Number</TableHead>
                      <TableHead className="text-right">Balance</TableHead>
                      <TableHead>Last Updated</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {accountsData.map((account) => (
                      <TableRow key={account.id}>
                        <TableCell className="font-medium">{account.name}</TableCell>
                        <TableCell>{account.type}</TableCell>
                        <TableCell>{account.bank}</TableCell>
                        <TableCell>{account.accountNumber}</TableCell>
                        <TableCell className="text-right font-medium">{formatCurrency(account.balance)}</TableCell>
                        <TableCell>{new Date(account.lastUpdated).toLocaleDateString()}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="transactions" className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" />
                  Export
                </Button>
                <Button variant="outline" size="sm">
                  <FileText className="mr-2 h-4 w-4" />
                  Print
                </Button>
              </div>
              <div className="flex flex-col sm:flex-row gap-2">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Search transactions..."
                    className="pl-8 w-full sm:w-[250px]"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <Select value={accountFilter} onValueChange={setAccountFilter}>
                  <SelectTrigger className="w-full sm:w-[180px]">
                    <SelectValue placeholder="Filter by account" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Accounts</SelectItem>
                    {accountsData.map((account) => (
                      <SelectItem key={account.id} value={account.name}>
                        {account.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={dateRange} onValueChange={setDateRange}>
                  <SelectTrigger className="w-full sm:w-[180px]">
                    <SelectValue placeholder="Date range" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="today">Today</SelectItem>
                    <SelectItem value="this-week">This Week</SelectItem>
                    <SelectItem value="this-month">This Month</SelectItem>
                    <SelectItem value="last-month">Last Month</SelectItem>
                    <SelectItem value="custom">Custom Range</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Account</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                      <TableHead>Reference</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredTransactions.map((transaction) => (
                      <TableRow key={transaction.id}>
                        <TableCell className="font-medium">{transaction.id}</TableCell>
                        <TableCell>{new Date(transaction.date).toLocaleDateString()}</TableCell>
                        <TableCell>{transaction.description}</TableCell>
                        <TableCell>{getTransactionBadge(transaction.type)}</TableCell>
                        <TableCell>{transaction.account}</TableCell>
                        <TableCell>{transaction.category}</TableCell>
                        <TableCell
                          className={`text-right font-medium ${
                            transaction.type === "income" ? "text-green-600" : "text-red-600"
                          }`}
                        >
                          {transaction.type === "income" ? "+" : "-"}
                          {formatCurrency(transaction.amount)}
                        </TableCell>
                        <TableCell>{transaction.reference}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PageTemplate>
  )
}
