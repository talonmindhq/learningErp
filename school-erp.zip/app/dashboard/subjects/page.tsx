"use client"

import { useState } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { MoreHorizontal, Search, Plus, Edit, Trash2, Users, BookOpen, FileText, Eye } from "lucide-react"

export default function SubjectsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedSubject, setSelectedSubject] = useState(null)
  const [isPreviewOpen, setIsPreviewOpen] = useState(false)

  // Sample data for subjects
  const subjects = [
    {
      id: 1,
      name: "Mathematics",
      code: "MATH101",
      department: "Science",
      classes: ["Grade 1-A", "Grade 1-B", "Grade 2-A"],
      teachers: ["Mrs. Johnson", "Mr. Smith"],
      totalStudents: 90,
      weeklyHours: 5,
    },
    {
      id: 2,
      name: "English",
      code: "ENG101",
      department: "Languages",
      classes: ["Grade 1-A", "Grade 1-B", "Grade 2-A"],
      teachers: ["Mrs. Davis", "Mr. Wilson"],
      totalStudents: 90,
      weeklyHours: 5,
    },
    {
      id: 3,
      name: "Science",
      code: "SCI101",
      department: "Science",
      classes: ["Grade 1-A", "Grade 1-B", "Grade 2-A"],
      teachers: ["Mrs. Brown", "Mr. Taylor"],
      totalStudents: 90,
      weeklyHours: 4,
    },
    {
      id: 4,
      name: "History",
      code: "HIS101",
      department: "Humanities",
      classes: ["Grade 8-C", "Grade 10-A"],
      teachers: ["Mr. Anderson"],
      totalStudents: 65,
      weeklyHours: 3,
    },
    {
      id: 5,
      name: "Physics",
      code: "PHY101",
      department: "Science",
      classes: ["Grade 10-A", "Grade 12-B"],
      teachers: ["Dr. Roberts"],
      totalStudents: 55,
      weeklyHours: 4,
    },
    {
      id: 6,
      name: "Computer Science",
      code: "CS101",
      department: "Technology",
      classes: ["Grade 10-A", "Grade 12-B"],
      teachers: ["Mr. Johnson"],
      totalStudents: 55,
      weeklyHours: 3,
    },
  ]

  // Sample data for classes taking this subject
  const subjectClasses = [
    { id: 1, name: "Grade 1-A", students: 32, teacher: "Mrs. Johnson", weeklyHours: 5 },
    { id: 2, name: "Grade 1-B", students: 30, teacher: "Mr. Smith", weeklyHours: 5 },
    { id: 3, name: "Grade 2-A", students: 28, teacher: "Mrs. Johnson", weeklyHours: 5 },
  ]

  // Sample data for syllabus
  const subjectSyllabus = [
    { unit: "Unit 1", title: "Numbers and Operations", duration: "4 weeks", status: "Completed" },
    { unit: "Unit 2", title: "Fractions and Decimals", duration: "5 weeks", status: "In Progress" },
    { unit: "Unit 3", title: "Geometry", duration: "4 weeks", status: "Pending" },
    { unit: "Unit 4", title: "Measurement", duration: "3 weeks", status: "Pending" },
    { unit: "Unit 5", title: "Data and Statistics", duration: "2 weeks", status: "Pending" },
  ]

  const filteredSubjects = subjects.filter(
    (subject) =>
      subject.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      subject.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      subject.department.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handlePreview = (subject) => {
    setSelectedSubject(subject)
    setIsPreviewOpen(true)
  }

  return (
    <PageTemplate
      title="Subjects"
      description="Manage academic subjects, curriculum, and teaching assignments."
      breadcrumbs={[
        { title: "Academic Portfolio", href: "#" },
        { title: "Subjects", href: "/dashboard/subjects", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Add Subject",
        icon: <Plus className="h-4 w-4 mr-2" />,
        href: "/dashboard/subjects/add",
      }}
    >
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle>All Subjects</CardTitle>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search subjects..."
                  className="w-64 pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Select defaultValue="all">
                <SelectTrigger className="w-36">
                  <SelectValue placeholder="Filter by dept" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Departments</SelectItem>
                  <SelectItem value="science">Science</SelectItem>
                  <SelectItem value="languages">Languages</SelectItem>
                  <SelectItem value="humanities">Humanities</SelectItem>
                  <SelectItem value="technology">Technology</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Subject Name</TableHead>
                <TableHead>Code</TableHead>
                <TableHead>Department</TableHead>
                <TableHead>Classes</TableHead>
                <TableHead>Teachers</TableHead>
                <TableHead>Weekly Hours</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredSubjects.map((subject) => (
                <TableRow key={subject.id}>
                  <TableCell className="font-medium">{subject.name}</TableCell>
                  <TableCell>{subject.code}</TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={
                        subject.department === "Science"
                          ? "bg-green-50 text-green-700 hover:bg-green-50"
                          : subject.department === "Languages"
                            ? "bg-blue-50 text-blue-700 hover:bg-blue-50"
                            : subject.department === "Humanities"
                              ? "bg-purple-50 text-purple-700 hover:bg-purple-50"
                              : "bg-orange-50 text-orange-700 hover:bg-orange-50"
                      }
                    >
                      {subject.department}
                    </Badge>
                  </TableCell>
                  <TableCell>{subject.classes.length}</TableCell>
                  <TableCell>{subject.teachers.length}</TableCell>
                  <TableCell>{subject.weeklyHours}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <span className="sr-only">Open menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuItem onClick={() => handlePreview(subject)}>
                          <Eye className="mr-2 h-4 w-4" />
                          <span>Preview</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Users className="mr-2 h-4 w-4" />
                          <span>View Classes</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <BookOpen className="mr-2 h-4 w-4" />
                          <span>View Syllabus</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <FileText className="mr-2 h-4 w-4" />
                          <span>View Resources</span>
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem>
                          <Edit className="mr-2 h-4 w-4" />
                          <span>Edit</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600">
                          <Trash2 className="mr-2 h-4 w-4" />
                          <span>Delete</span>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Subject Preview Dialog */}
      <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Subject Details: {selectedSubject?.name}</DialogTitle>
            <DialogDescription>Comprehensive information about the subject, classes, and syllabus.</DialogDescription>
          </DialogHeader>

          <Tabs defaultValue="details">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="classes">Classes</TabsTrigger>
              <TabsTrigger value="syllabus">Syllabus</TabsTrigger>
            </TabsList>

            <TabsContent value="details" className="space-y-4 pt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Subject Name</p>
                  <p>{selectedSubject?.name}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Subject Code</p>
                  <p>{selectedSubject?.code}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Department</p>
                  <p>{selectedSubject?.department}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Weekly Hours</p>
                  <p>{selectedSubject?.weeklyHours}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Total Students</p>
                  <p>{selectedSubject?.totalStudents}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Teachers</p>
                  <p>{selectedSubject?.teachers.join(", ")}</p>
                </div>
                <div className="space-y-1 col-span-2">
                  <p className="text-sm font-medium text-muted-foreground">Classes</p>
                  <p>{selectedSubject?.classes.join(", ")}</p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="classes" className="pt-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Class Name</TableHead>
                    <TableHead>Students</TableHead>
                    <TableHead>Teacher</TableHead>
                    <TableHead>Weekly Hours</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {subjectClasses.map((cls) => (
                    <TableRow key={cls.id}>
                      <TableCell>{cls.name}</TableCell>
                      <TableCell>{cls.students}</TableCell>
                      <TableCell>{cls.teacher}</TableCell>
                      <TableCell>{cls.weeklyHours}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TabsContent>

            <TabsContent value="syllabus" className="pt-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Unit</TableHead>
                    <TableHead>Title</TableHead>
                    <TableHead>Duration</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {subjectSyllabus.map((unit, index) => (
                    <TableRow key={index}>
                      <TableCell>{unit.unit}</TableCell>
                      <TableCell>{unit.title}</TableCell>
                      <TableCell>{unit.duration}</TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            unit.status === "Completed"
                              ? "bg-green-50 text-green-700 hover:bg-green-50"
                              : unit.status === "In Progress"
                                ? "bg-blue-50 text-blue-700 hover:bg-blue-50"
                                : "bg-gray-50 text-gray-700 hover:bg-gray-50"
                          }
                        >
                          {unit.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </PageTemplate>
  )
}
