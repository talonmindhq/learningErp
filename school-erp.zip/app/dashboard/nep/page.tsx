import type { Metadata } from "next"
import { ClipboardCheck, Hammer, CheckCircle, GraduationCap } from "lucide-react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"

export const metadata: Metadata = {
  title: "NEP Implementation",
  description: "National Education Policy implementation tracking",
}

export default function NEPPage() {
  return (
    <div className="flex flex-col gap-4 p-4 md:p-8">
      <div className="flex items-center justify-between">
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/dashboard">Dashboard</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>NEP Implementation</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
        <Button>Generate Report</Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Implementation Progress</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">78%</div>
            <Progress value={78} className="mt-2" />
            <p className="text-xs text-muted-foreground mt-2">+12% from last quarter</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Competency Areas</CardTitle>
            <ClipboardCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">24/30</div>
            <p className="text-xs text-muted-foreground">Areas implemented</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Vocational Courses</CardTitle>
            <Hammer className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
            <p className="text-xs text-muted-foreground">Active courses</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Teacher Training</CardTitle>
            <GraduationCap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">92%</div>
            <Progress value={92} className="mt-2" />
            <p className="text-xs text-muted-foreground mt-2">Staff trained on NEP</p>
          </CardContent>
        </Card>
      </div>

      <Card className="mb-4">
        <CardHeader>
          <CardTitle>NEP Implementation Roadmap</CardTitle>
          <CardDescription>Progress tracking across key NEP focus areas</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium">Foundational Literacy & Numeracy</span>
                <span className="text-sm font-medium">90%</span>
              </div>
              <Progress value={90} className="h-2" />
            </div>
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium">Multilingual Education</span>
                <span className="text-sm font-medium">85%</span>
              </div>
              <Progress value={85} className="h-2" />
            </div>
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium">Competency-based Learning</span>
                <span className="text-sm font-medium">75%</span>
              </div>
              <Progress value={75} className="h-2" />
            </div>
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium">Vocational Education Integration</span>
                <span className="text-sm font-medium">65%</span>
              </div>
              <Progress value={65} className="h-2" />
            </div>
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium">Holistic Progress Card</span>
                <span className="text-sm font-medium">80%</span>
              </div>
              <Progress value={80} className="h-2" />
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="curriculum" className="w-full">
        <TabsList>
          <TabsTrigger value="curriculum">Curriculum</TabsTrigger>
          <TabsTrigger value="assessments">Assessments</TabsTrigger>
          <TabsTrigger value="skills">Skill Development</TabsTrigger>
          <TabsTrigger value="vocational">Vocational Training</TabsTrigger>
        </TabsList>
        <TabsContent value="curriculum" className="border rounded-md mt-2">
          <div className="flex items-center justify-between p-4">
            <h3 className="text-lg font-medium">NEP Aligned Curriculum</h3>
            <Button variant="outline">Update Curriculum</Button>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Subject</TableHead>
                <TableHead>Grade Level</TableHead>
                <TableHead>NEP Alignment</TableHead>
                <TableHead>Key Competencies</TableHead>
                <TableHead>Last Updated</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[...Array(5)].map((_, i) => (
                <TableRow key={i}>
                  <TableCell className="font-medium">
                    {["Mathematics", "Science", "Language", "Social Studies", "Arts & Crafts"][i]}
                  </TableCell>
                  <TableCell>{["Grades 1-3", "Grades 4-5", "Grades 6-8", "Grades 9-10", "Grades 1-5"][i]}</TableCell>
                  <TableCell>{["95%", "85%", "90%", "75%", "80%"][i]}</TableCell>
                  <TableCell>
                    {
                      [
                        "Numeracy, Problem Solving",
                        "Scientific Inquiry, Critical Thinking",
                        "Multilingual Proficiency",
                        "Analytical Skills, Civic Sense",
                        "Creativity, Cultural Awareness",
                      ][i]
                    }
                  </TableCell>
                  <TableCell>
                    {["15 May 2023", "2 June 2023", "10 April 2023", "22 May 2023", "5 June 2023"][i]}
                  </TableCell>
                  <TableCell>
                    <Badge variant={i === 3 ? "outline" : "default"}>{i === 3 ? "In Review" : "Implemented"}</Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TabsContent>
        <TabsContent value="assessments" className="border rounded-md mt-2">
          <div className="flex items-center justify-between p-4">
            <h3 className="text-lg font-medium">Competency-Based Assessments</h3>
            <Button>Create Assessment</Button>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Assessment Name</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Grade Level</TableHead>
                <TableHead>Competencies Measured</TableHead>
                <TableHead>Frequency</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[...Array(5)].map((_, i) => (
                <TableRow key={i}>
                  <TableCell className="font-medium">
                    {
                      [
                        "Foundational Literacy",
                        "Mathematical Proficiency",
                        "Scientific Inquiry",
                        "Critical Thinking",
                        "Digital Literacy",
                      ][i]
                    }
                  </TableCell>
                  <TableCell>{["Formative", "Summative", "Project-based", "Continuous", "Diagnostic"][i]}</TableCell>
                  <TableCell>{["Grades 1-2", "Grades 3-5", "Grades 6-8", "Grades 9-10", "All Grades"][i]}</TableCell>
                  <TableCell>
                    {
                      [
                        "Reading, Writing",
                        "Problem Solving, Numeracy",
                        "Observation, Experimentation",
                        "Analysis, Evaluation",
                        "Technology Use, Information Literacy",
                      ][i]
                    }
                  </TableCell>
                  <TableCell>{["Monthly", "Quarterly", "Bi-monthly", "Weekly", "Semester"][i]}</TableCell>
                  <TableCell>
                    <Badge variant={i === 2 ? "outline" : i === 4 ? "secondary" : "default"}>
                      {i === 2 ? "In Development" : i === 4 ? "Piloting" : "Active"}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TabsContent>
        <TabsContent value="skills" className="border rounded-md mt-2">
          <div className="flex items-center justify-between p-4">
            <h3 className="text-lg font-medium">21st Century Skills Development</h3>
            <Button variant="outline">Add Skill Program</Button>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Skill Area</TableHead>
                <TableHead>Integration Method</TableHead>
                <TableHead>Target Grades</TableHead>
                <TableHead>Activities</TableHead>
                <TableHead>Implementation</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[...Array(5)].map((_, i) => (
                <TableRow key={i}>
                  <TableCell className="font-medium">
                    {["Critical Thinking", "Collaboration", "Creativity", "Communication", "Digital Literacy"][i]}
                  </TableCell>
                  <TableCell>
                    {
                      [
                        "Cross-curricular",
                        "Project-based Learning",
                        "Dedicated Sessions",
                        "Integrated Curriculum",
                        "Tech Lab Sessions",
                      ][i]
                    }
                  </TableCell>
                  <TableCell>{["All Grades", "Grades 3-8", "Grades 1-5", "Grades 6-10", "Grades 4-10"][i]}</TableCell>
                  <TableCell>
                    {
                      [
                        "Problem Solving Challenges",
                        "Group Projects",
                        "Design Thinking Workshops",
                        "Debate & Discussion",
                        "Digital Content Creation",
                      ][i]
                    }
                  </TableCell>
                  <TableCell>{["90%", "85%", "75%", "80%", "70%"][i]}</TableCell>
                  <TableCell>
                    <Badge variant={i === 2 || i === 4 ? "outline" : "default"}>
                      {i === 2 || i === 4 ? "Expanding" : "Implemented"}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TabsContent>
        <TabsContent value="vocational" className="border rounded-md mt-2">
          <div className="flex items-center justify-between p-4">
            <h3 className="text-lg font-medium">Vocational Education Programs</h3>
            <Button>Add Program</Button>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Program Name</TableHead>
                <TableHead>Sector</TableHead>
                <TableHead>Grade Level</TableHead>
                <TableHead>Duration</TableHead>
                <TableHead>Enrollment</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[...Array(5)].map((_, i) => (
                <TableRow key={i}>
                  <TableCell className="font-medium">
                    {
                      [
                        "Basic Coding",
                        "Financial Literacy",
                        "Digital Media",
                        "Healthcare Basics",
                        "Sustainable Agriculture",
                      ][i]
                    }
                  </TableCell>
                  <TableCell>{["IT", "Finance", "Media", "Healthcare", "Agriculture"][i]}</TableCell>
                  <TableCell>{["Grades 6-8", "Grades 9-10", "Grades 8-10", "Grades 9-12", "Grades 6-10"][i]}</TableCell>
                  <TableCell>{["1 Semester", "1 Year", "6 Months", "1 Year", "1 Semester"][i]}</TableCell>
                  <TableCell>{[45, 32, 28, 15, 20][i]} students</TableCell>
                  <TableCell>
                    <Badge variant={i === 3 ? "secondary" : i === 4 ? "outline" : "default"}>
                      {i === 3 ? "New" : i === 4 ? "Planned" : "Active"}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TabsContent>
      </Tabs>
    </div>
  )
}
