"use client"

import type React from "react"

import { useState } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { CalendarIcon, Save, ArrowLeft, Check } from "lucide-react"
import { Calendar } from "@/components/ui/calendar"
import { format } from "date-fns"
import Link from "next/link"
import { useToast } from "@/components/ui/use-toast"
import { useRouter } from "next/navigation"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Textarea } from "@/components/ui/textarea"

export default function ScheduleInterviewPage() {
  const [date, setDate] = useState<Date>(new Date())
  const [formData, setFormData] = useState({
    applicantId: "",
    applicantName: "",
    interviewTime: "10:00 AM",
    interviewer: "",
    location: "Main Campus",
    notes: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [isSuccess, setIsSuccess] = useState(false)
  const { toast } = useToast()
  const router = useRouter()

  // Sample applications for dropdown
  const applications = [
    { id: "APP006", name: "Ananya Reddy" },
    { id: "APP007", name: "Rohan Joshi" },
    { id: "APP008", name: "Neha Kapoor" },
    { id: "APP009", name: "Arjun Malhotra" },
    { id: "APP010", name: "Kavita Sharma" },
  ]

  // Sample interviewers for dropdown
  const interviewers = [
    "Dr. Patel",
    "Mrs. Sharma",
    "Mr. Verma",
    "Dr. Singh",
    "Mrs. Gupta",
    "Mr. Khanna",
    "Dr. Reddy",
    "Mrs. Iyer",
  ]

  const handleChange = (field: string, value: string) => {
    setFormData({
      ...formData,
      [field]: value,
    })
    // Clear error for this field if it exists
    if (errors[field]) {
      setErrors({
        ...errors,
        [field]: "",
      })
    }

    // If applicant ID is selected, set the name automatically
    if (field === "applicantId") {
      const selectedApplication = applications.find((app) => app.id === value)
      if (selectedApplication) {
        setFormData({
          ...formData,
          applicantId: value,
          applicantName: selectedApplication.name,
        })
      }
    }
  }

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.applicantId) {
      newErrors.applicantId = "Applicant is required"
    }

    if (!date) {
      newErrors.date = "Interview date is required"
    }

    if (!formData.interviewTime) {
      newErrors.interviewTime = "Interview time is required"
    }

    if (!formData.interviewer) {
      newErrors.interviewer = "Interviewer is required"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      toast({
        title: "Validation Error",
        description: "Please check the form for errors",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Show success message
      setIsSuccess(true)
      toast({
        title: "Interview Scheduled",
        description: `Interview for ${formData.applicantName} has been scheduled successfully`,
      })

      // Reset form after 2 seconds and redirect
      setTimeout(() => {
        router.push("/dashboard/interviews")
      }, 2000)
    } catch (error) {
      toast({
        title: "Error",
        description: "There was an error scheduling the interview. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <PageTemplate
      title="Schedule Interview"
      description="Schedule a new admission interview"
      breadcrumbs={[
        { title: "Enquiry & Admission", href: "/dashboard/interviews" },
        { title: "Interviews", href: "/dashboard/interviews" },
        { title: "Schedule Interview", href: "/dashboard/interviews/schedule", isCurrentPage: true },
      ]}
    >
      <Card>
        <CardHeader>
          <CardTitle>Interview Details</CardTitle>
          <CardDescription>Enter the details for the new interview</CardDescription>
        </CardHeader>
        <CardContent>
          {isSuccess ? (
            <Alert className="bg-green-50 border-green-200">
              <Check className="h-4 w-4 text-green-600" />
              <AlertTitle>Success!</AlertTitle>
              <AlertDescription>
                Interview has been scheduled successfully. Redirecting to interviews list...
              </AlertDescription>
            </Alert>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="applicantId">
                  Select Applicant <span className="text-red-500">*</span>
                </Label>
                <Select value={formData.applicantId} onValueChange={(value) => handleChange("applicantId", value)}>
                  <SelectTrigger id="applicantId" className={errors.applicantId ? "border-red-500" : ""}>
                    <SelectValue placeholder="Select applicant" />
                  </SelectTrigger>
                  <SelectContent>
                    {applications.map((app) => (
                      <SelectItem key={app.id} value={app.id}>
                        {app.name} ({app.id})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.applicantId && <p className="text-red-500 text-xs mt-1">{errors.applicantId}</p>}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>
                    Interview Date <span className="text-red-500">*</span>
                  </Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant={"outline"}
                        className={`w-full justify-start text-left font-normal ${errors.date ? "border-red-500" : ""}`}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {format(date, "PPP")}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={date}
                        onSelect={(date) => date && setDate(date)}
                        initialFocus
                        disabled={(date) => date < new Date()}
                      />
                    </PopoverContent>
                  </Popover>
                  {errors.date && <p className="text-red-500 text-xs mt-1">{errors.date}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="interviewTime">
                    Interview Time <span className="text-red-500">*</span>
                  </Label>
                  <Select
                    value={formData.interviewTime}
                    onValueChange={(value) => handleChange("interviewTime", value)}
                  >
                    <SelectTrigger id="interviewTime" className={errors.interviewTime ? "border-red-500" : ""}>
                      <SelectValue placeholder="Select time" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="09:00 AM">09:00 AM</SelectItem>
                      <SelectItem value="09:30 AM">09:30 AM</SelectItem>
                      <SelectItem value="10:00 AM">10:00 AM</SelectItem>
                      <SelectItem value="10:30 AM">10:30 AM</SelectItem>
                      <SelectItem value="11:00 AM">11:00 AM</SelectItem>
                      <SelectItem value="11:30 AM">11:30 AM</SelectItem>
                      <SelectItem value="12:00 PM">12:00 PM</SelectItem>
                      <SelectItem value="12:30 PM">12:30 PM</SelectItem>
                      <SelectItem value="01:00 PM">01:00 PM</SelectItem>
                      <SelectItem value="01:30 PM">01:30 PM</SelectItem>
                      <SelectItem value="02:00 PM">02:00 PM</SelectItem>
                      <SelectItem value="02:30 PM">02:30 PM</SelectItem>
                      <SelectItem value="03:00 PM">03:00 PM</SelectItem>
                      <SelectItem value="03:30 PM">03:30 PM</SelectItem>
                      <SelectItem value="04:00 PM">04:00 PM</SelectItem>
                      <SelectItem value="04:30 PM">04:30 PM</SelectItem>
                    </SelectContent>
                  </Select>
                  {errors.interviewTime && <p className="text-red-500 text-xs mt-1">{errors.interviewTime}</p>}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="interviewer">
                    Interviewer <span className="text-red-500">*</span>
                  </Label>
                  <Select value={formData.interviewer} onValueChange={(value) => handleChange("interviewer", value)}>
                    <SelectTrigger id="interviewer" className={errors.interviewer ? "border-red-500" : ""}>
                      <SelectValue placeholder="Select interviewer" />
                    </SelectTrigger>
                    <SelectContent>
                      {interviewers.map((interviewer) => (
                        <SelectItem key={interviewer} value={interviewer}>
                          {interviewer}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.interviewer && <p className="text-red-500 text-xs mt-1">{errors.interviewer}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="location">Location</Label>
                  <Select value={formData.location} onValueChange={(value) => handleChange("location", value)}>
                    <SelectTrigger id="location">
                      <SelectValue placeholder="Select location" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Main Campus">Main Campus</SelectItem>
                      <SelectItem value="Admin Block">Admin Block</SelectItem>
                      <SelectItem value="Principal's Office">Principal's Office</SelectItem>
                      <SelectItem value="Conference Room">Conference Room</SelectItem>
                      <SelectItem value="Virtual">Virtual (Online)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Notes/Instructions</Label>
                <Textarea
                  id="notes"
                  placeholder="Enter any additional notes or instructions for the interview"
                  className="min-h-[100px]"
                  value={formData.notes}
                  onChange={(e) => handleChange("notes", e.target.value)}
                />
              </div>
            </form>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" asChild>
            <Link href="/dashboard/interviews">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Interviews
            </Link>
          </Button>
          {!isSuccess && (
            <Button
              type="submit"
              className="bg-theme-500 hover:bg-theme-600"
              onClick={handleSubmit}
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <svg
                    className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    ></circle>
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    ></path>
                  </svg>
                  Processing...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Schedule Interview
                </>
              )}
            </Button>
          )}
        </CardFooter>
      </Card>
    </PageTemplate>
  )
}
