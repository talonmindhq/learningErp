import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function ScheduleInterviewLoading() {
  return (
    <PageTemplate
      title="Schedule Interview"
      description="Schedule a new admission interview"
      breadcrumbs={[
        { title: "Enquiry & Admission", href: "/dashboard/interviews" },
        { title: "Interviews", href: "/dashboard/interviews" },
        { title: "Schedule Interview", href: "/dashboard/interviews/schedule", isCurrentPage: true },
      ]}
    >
      <Card>
        <CardHeader>
          <CardTitle>Interview Details</CardTitle>
          <CardDescription>Enter the details for the new interview</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="space-y-2">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-10 w-full" />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-10 w-full" />
              </div>
              <div className="space-y-2">
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-10 w-full" />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-10 w-full" />
              </div>
              <div className="space-y-2">
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-10 w-full" />
              </div>
            </div>

            <div className="space-y-2">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-24 w-full" />
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" asChild>
            <Link href="/dashboard/interviews">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Interviews
            </Link>
          </Button>
          <Skeleton className="h-10 w-32" />
        </CardFooter>
      </Card>
    </PageTemplate>
  )
}
