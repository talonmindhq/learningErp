"use client"

import { useState } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Plus, CalendarIcon, Clock, User, MoreHorizontal, Edit, Trash2, CheckCircle } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useToast } from "@/components/ui/use-toast"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

export default function InterviewsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [selectedInterview, setSelectedInterview] = useState<any>(null)
  const [isScheduleDialogOpen, setIsScheduleDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isCompleteDialogOpen, setIsCompleteDialogOpen] = useState(false)
  const [interviewDate, setInterviewDate] = useState<Date | undefined>(new Date())
  const [interviewTime, setInterviewTime] = useState("10:00 AM")
  const [interviewerName, setInterviewerName] = useState("")
  const [applicantName, setApplicantName] = useState("")
  const [applicationId, setApplicationId] = useState("")
  const [interviewNotes, setInterviewNotes] = useState("")
  const { toast } = useToast()

  // Sample data
  const [interviews, setInterviews] = useState([
    {
      id: "INT001",
      applicantName: "Rahul Sharma",
      applicationId: "APP001",
      date: "2023-06-15",
      time: "10:00 AM",
      interviewer: "Dr. Patel",
      status: "scheduled",
      notes: "",
    },
    {
      id: "INT002",
      applicantName: "Priya Patel",
      applicationId: "APP002",
      date: "2023-06-14",
      time: "11:30 AM",
      interviewer: "Mrs. Sharma",
      status: "completed",
      notes: "Candidate performed well in the interview. Recommended for admission.",
    },
    {
      id: "INT003",
      applicantName: "Amit Kumar",
      applicationId: "APP003",
      date: "2023-06-16",
      time: "09:15 AM",
      interviewer: "Mr. Verma",
      status: "scheduled",
      notes: "",
    },
    {
      id: "INT004",
      applicantName: "Sneha Gupta",
      applicationId: "APP004",
      date: "2023-06-13",
      time: "02:00 PM",
      interviewer: "Dr. Singh",
      status: "cancelled",
      notes: "Candidate requested to reschedule due to personal reasons.",
    },
    {
      id: "INT005",
      applicantName: "Vikram Singh",
      applicationId: "APP005",
      date: "2023-06-12",
      time: "03:30 PM",
      interviewer: "Mrs. Gupta",
      status: "completed",
      notes: "Candidate has good academic record but needs improvement in communication skills.",
    },
  ])

  // Sample applications for dropdown
  const applications = [
    { id: "APP006", name: "Ananya Reddy" },
    { id: "APP007", name: "Rohan Joshi" },
    { id: "APP008", name: "Neha Kapoor" },
    { id: "APP009", name: "Arjun Malhotra" },
    { id: "APP010", name: "Kavita Sharma" },
  ]

  // Sample interviewers for dropdown
  const interviewers = [
    "Dr. Patel",
    "Mrs. Sharma",
    "Mr. Verma",
    "Dr. Singh",
    "Mrs. Gupta",
    "Mr. Khanna",
    "Dr. Reddy",
    "Mrs. Iyer",
  ]

  const filteredInterviews = interviews.filter((interview) => {
    const matchesSearch =
      interview.applicantName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      interview.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      interview.applicationId.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesStatus = statusFilter === "all" || interview.status === statusFilter

    return matchesSearch && matchesStatus
  })

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "scheduled":
        return <Badge className="bg-blue-500">Scheduled</Badge>
      case "completed":
        return <Badge className="bg-green-500">Completed</Badge>
      case "cancelled":
        return <Badge className="bg-red-500">Cancelled</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  const handleScheduleInterview = () => {
    setSelectedInterview(null)
    setInterviewDate(new Date())
    setInterviewTime("10:00 AM")
    setInterviewerName("")
    setApplicantName("")
    setApplicationId("")
    setIsScheduleDialogOpen(true)
  }

  const handleEditInterview = (interview: any) => {
    setSelectedInterview(interview)
    setInterviewDate(new Date(interview.date))
    setInterviewTime(interview.time)
    setInterviewerName(interview.interviewer)
    setIsEditDialogOpen(true)
  }

  const handleDeleteInterview = (interview: any) => {
    setSelectedInterview(interview)
    setIsDeleteDialogOpen(true)
  }

  const handleCompleteInterview = (interview: any) => {
    setSelectedInterview(interview)
    setInterviewNotes("")
    setIsCompleteDialogOpen(true)
  }

  const saveNewInterview = () => {
    if (!interviewDate || !interviewTime || !interviewerName || !applicationId) {
      toast({
        title: "Validation Error",
        description: "Please fill all required fields",
        variant: "destructive",
      })
      return
    }

    const selectedApplication = applications.find((app) => app.id === applicationId)

    const newInterview = {
      id: `INT${String(interviews.length + 1).padStart(3, "0")}`,
      applicantName: selectedApplication?.name || "",
      applicationId: applicationId,
      date: format(interviewDate, "yyyy-MM-dd"),
      time: interviewTime,
      interviewer: interviewerName,
      status: "scheduled",
      notes: "",
    }

    setInterviews([...interviews, newInterview])
    setIsScheduleDialogOpen(false)
    toast({
      title: "Interview Scheduled",
      description: `Interview scheduled for ${selectedApplication?.name} on ${format(interviewDate, "PPP")} at ${interviewTime}`,
    })
  }

  const saveEditedInterview = () => {
    if (!selectedInterview || !interviewDate || !interviewTime || !interviewerName) {
      toast({
        title: "Validation Error",
        description: "Please fill all required fields",
        variant: "destructive",
      })
      return
    }

    const updatedInterviews = interviews.map((interview) => {
      if (interview.id === selectedInterview.id) {
        return {
          ...interview,
          date: format(interviewDate, "yyyy-MM-dd"),
          time: interviewTime,
          interviewer: interviewerName,
        }
      }
      return interview
    })

    setInterviews(updatedInterviews)
    setIsEditDialogOpen(false)
    toast({
      title: "Interview Updated",
      description: `Interview details for ${selectedInterview.applicantName} have been updated`,
    })
  }

  const confirmDeleteInterview = () => {
    if (selectedInterview) {
      const updatedInterviews = interviews.filter((interview) => interview.id !== selectedInterview.id)
      setInterviews(updatedInterviews)
      setIsDeleteDialogOpen(false)
      toast({
        title: "Interview Deleted",
        description: `Interview for ${selectedInterview.applicantName} has been deleted`,
      })
    }
  }

  const completeInterview = () => {
    if (selectedInterview) {
      const updatedInterviews = interviews.map((interview) => {
        if (interview.id === selectedInterview.id) {
          return {
            ...interview,
            status: "completed",
            notes: interviewNotes,
          }
        }
        return interview
      })
      setInterviews(updatedInterviews)
      setIsCompleteDialogOpen(false)
      toast({
        title: "Interview Completed",
        description: `Interview for ${selectedInterview.applicantName} has been marked as completed`,
      })
    }
  }

  return (
    <PageTemplate
      title="Interviews"
      description="Schedule and manage admission interviews"
      breadcrumbs={[
        { title: "Enquiry & Admission", href: "/dashboard/interviews" },
        { title: "Interviews", href: "/dashboard/interviews", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Schedule Interview",
        icon: <Plus className="mr-2 h-4 w-4" />,
        onClick: handleScheduleInterview,
      }}
    >
      <Card>
        <CardHeader className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
          <CardTitle>All Interviews</CardTitle>
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search interviews..."
                className="pl-8 w-full sm:w-[250px]"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-[150px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="scheduled">Scheduled</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Applicant</TableHead>
                  <TableHead className="hidden md:table-cell">Application ID</TableHead>
                  <TableHead>Date & Time</TableHead>
                  <TableHead className="hidden md:table-cell">Interviewer</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredInterviews.map((interview) => (
                  <TableRow key={interview.id}>
                    <TableCell className="font-medium">{interview.id}</TableCell>
                    <TableCell>{interview.applicantName}</TableCell>
                    <TableCell className="hidden md:table-cell">{interview.applicationId}</TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <div className="flex items-center text-xs">
                          <CalendarIcon className="mr-1 h-3 w-3 text-muted-foreground" />
                          {new Date(interview.date).toLocaleDateString()}
                        </div>
                        <div className="flex items-center text-xs mt-1">
                          <Clock className="mr-1 h-3 w-3 text-muted-foreground" />
                          {interview.time}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      <div className="flex items-center">
                        <User className="mr-1 h-3 w-3 text-muted-foreground" />
                        {interview.interviewer}
                      </div>
                    </TableCell>
                    <TableCell>{getStatusBadge(interview.status)}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          {interview.status === "scheduled" && (
                            <>
                              <DropdownMenuItem onClick={() => handleCompleteInterview(interview)}>
                                <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                                Mark as Completed
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                            </>
                          )}
                          <DropdownMenuItem onClick={() => handleEditInterview(interview)}>
                            <Edit className="mr-2 h-4 w-4" />
                            Edit Interview
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-red-600" onClick={() => handleDeleteInterview(interview)}>
                            <Trash2 className="mr-2 h-4 w-4" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Schedule Interview Dialog */}
      <Dialog open={isScheduleDialogOpen} onOpenChange={setIsScheduleDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Schedule New Interview</DialogTitle>
            <DialogDescription>Schedule an interview for an applicant</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="applicationId">
                Select Applicant <span className="text-red-500">*</span>
              </Label>
              <Select value={applicationId} onValueChange={setApplicationId}>
                <SelectTrigger id="applicationId">
                  <SelectValue placeholder="Select applicant" />
                </SelectTrigger>
                <SelectContent>
                  {applications.map((app) => (
                    <SelectItem key={app.id} value={app.id}>
                      {app.name} ({app.id})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>
                Interview Date <span className="text-red-500">*</span>
              </Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant={"outline"} className="w-full justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {interviewDate ? format(interviewDate, "PPP") : "Select date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <CalendarComponent
                    mode="single"
                    selected={interviewDate}
                    onSelect={setInterviewDate}
                    initialFocus
                    disabled={(date) => date < new Date()}
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label htmlFor="interviewTime">
                Interview Time <span className="text-red-500">*</span>
              </Label>
              <Select value={interviewTime} onValueChange={setInterviewTime}>
                <SelectTrigger id="interviewTime">
                  <SelectValue placeholder="Select time" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="09:00 AM">09:00 AM</SelectItem>
                  <SelectItem value="09:30 AM">09:30 AM</SelectItem>
                  <SelectItem value="10:00 AM">10:00 AM</SelectItem>
                  <SelectItem value="10:30 AM">10:30 AM</SelectItem>
                  <SelectItem value="11:00 AM">11:00 AM</SelectItem>
                  <SelectItem value="11:30 AM">11:30 AM</SelectItem>
                  <SelectItem value="12:00 PM">12:00 PM</SelectItem>
                  <SelectItem value="12:30 PM">12:30 PM</SelectItem>
                  <SelectItem value="01:00 PM">01:00 PM</SelectItem>
                  <SelectItem value="01:30 PM">01:30 PM</SelectItem>
                  <SelectItem value="02:00 PM">02:00 PM</SelectItem>
                  <SelectItem value="02:30 PM">02:30 PM</SelectItem>
                  <SelectItem value="03:00 PM">03:00 PM</SelectItem>
                  <SelectItem value="03:30 PM">03:30 PM</SelectItem>
                  <SelectItem value="04:00 PM">04:00 PM</SelectItem>
                  <SelectItem value="04:30 PM">04:30 PM</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="interviewerName">
                Interviewer <span className="text-red-500">*</span>
              </Label>
              <Select value={interviewerName} onValueChange={setInterviewerName}>
                <SelectTrigger id="interviewerName">
                  <SelectValue placeholder="Select interviewer" />
                </SelectTrigger>
                <SelectContent>
                  {interviewers.map((interviewer) => (
                    <SelectItem key={interviewer} value={interviewer}>
                      {interviewer}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">Cancel</Button>
            </DialogClose>
            <Button className="bg-theme-500 hover:bg-theme-600" onClick={saveNewInterview}>
              Schedule Interview
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Interview Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Edit Interview</DialogTitle>
            <DialogDescription>Update interview details for {selectedInterview?.applicantName}</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Interview Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant={"outline"} className="w-full justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {interviewDate ? format(interviewDate, "PPP") : "Select date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <CalendarComponent
                    mode="single"
                    selected={interviewDate}
                    onSelect={setInterviewDate}
                    initialFocus
                    disabled={(date) => date < new Date()}
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label htmlFor="editInterviewTime">Interview Time</Label>
              <Select value={interviewTime} onValueChange={setInterviewTime}>
                <SelectTrigger id="editInterviewTime">
                  <SelectValue placeholder="Select time" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="09:00 AM">09:00 AM</SelectItem>
                  <SelectItem value="09:30 AM">09:30 AM</SelectItem>
                  <SelectItem value="10:00 AM">10:00 AM</SelectItem>
                  <SelectItem value="10:30 AM">10:30 AM</SelectItem>
                  <SelectItem value="11:00 AM">11:00 AM</SelectItem>
                  <SelectItem value="11:30 AM">11:30 AM</SelectItem>
                  <SelectItem value="12:00 PM">12:00 PM</SelectItem>
                  <SelectItem value="12:30 PM">12:30 PM</SelectItem>
                  <SelectItem value="01:00 PM">01:00 PM</SelectItem>
                  <SelectItem value="01:30 PM">01:30 PM</SelectItem>
                  <SelectItem value="02:00 PM">02:00 PM</SelectItem>
                  <SelectItem value="02:30 PM">02:30 PM</SelectItem>
                  <SelectItem value="03:00 PM">03:00 PM</SelectItem>
                  <SelectItem value="03:30 PM">03:30 PM</SelectItem>
                  <SelectItem value="04:00 PM">04:00 PM</SelectItem>
                  <SelectItem value="04:30 PM">04:30 PM</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="editInterviewerName">Interviewer</Label>
              <Select value={interviewerName} onValueChange={setInterviewerName}>
                <SelectTrigger id="editInterviewerName">
                  <SelectValue placeholder="Select interviewer" />
                </SelectTrigger>
                <SelectContent>
                  {interviewers.map((interviewer) => (
                    <SelectItem key={interviewer} value={interviewer}>
                      {interviewer}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">Cancel</Button>
            </DialogClose>
            <Button className="bg-theme-500 hover:bg-theme-600" onClick={saveEditedInterview}>
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the interview. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-red-600 hover:bg-red-700" onClick={confirmDeleteInterview}>
              <Trash2 className="mr-2 h-4 w-4" />
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Complete Interview Dialog */}
      <Dialog open={isCompleteDialogOpen} onOpenChange={setIsCompleteDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Complete Interview</DialogTitle>
            <DialogDescription>
              Mark the interview for {selectedInterview?.applicantName} as completed
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="interviewNotes">Interview Notes</Label>
              <Textarea
                id="interviewNotes"
                placeholder="Enter notes, feedback, or observations from the interview"
                value={interviewNotes}
                onChange={(e) => setInterviewNotes(e.target.value)}
                className="min-h-[120px]"
              />
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">Cancel</Button>
            </DialogClose>
            <Button className="bg-green-600 hover:bg-green-700" onClick={completeInterview}>
              <CheckCircle className="mr-2 h-4 w-4" />
              Mark as Completed
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageTemplate>
  )
}
