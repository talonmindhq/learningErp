"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Users,
  Bell,
  Download,
  Filter,
  CreditCard,
  ArrowUpRight,
  ArrowDownRight,
  CheckCircle2,
  Clock,
  UserPlus,
} from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RecentNotices } from "@/components/recent-notices"
import { StudentDistribution } from "@/components/student-distribution"
import { QuickActions } from "@/components/quick-actions"
import { Progress } from "@/components/ui/progress"
import { EnrollmentTrend } from "@/components/enrollment-trend"
import { AcademicPerformance } from "@/components/academic-performance"
import { RecentActivity } from "@/components/recent-activity"

export default function DashboardPage() {
  const [academicYear, setAcademicYear] = useState("2023-2024")
  const [user, setUser] = useState<{ username: string; role: string } | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Get user from localStorage
    const storedUser = localStorage.getItem("user")
    if (storedUser) {
      setUser(JSON.parse(storedUser))
    }

    // Simulate loading
    const timer = setTimeout(() => {
      setLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  return (
    <div className="flex-1 space-y-4 p-4 md:p-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-2 md:space-y-0">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-gray-900">Welcome, {user?.username || "Admin"}</h2>
          <p className="text-muted-foreground">Here's what's happening with your school today.</p>
        </div>
        <div className="flex flex-col sm:flex-row items-center gap-2">
          <Select value={academicYear} onValueChange={setAcademicYear}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Academic Year" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2023-2024">2023-2024</SelectItem>
              <SelectItem value="2022-2023">2022-2023</SelectItem>
              <SelectItem value="2021-2022">2021-2022</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
          <Button className="bg-theme-500 hover:bg-theme-600 text-white">
            <Bell className="mr-2 h-4 w-4" />
            Notifications
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-l-4 border-l-theme-500 hover:shadow-md transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Students</CardTitle>
            <div className="rounded-full bg-theme-100 p-2 text-theme-500">
              <Users className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,248</div>
            <div className="flex items-center pt-1">
              <span className="text-xs text-theme-500 flex items-center font-medium">
                <ArrowUpRight className="mr-1 h-3 w-3" />
                12%
              </span>
              <span className="text-xs text-muted-foreground ml-1">from last month</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-accent2-500 hover:shadow-md transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Attendance Rate</CardTitle>
            <div className="rounded-full bg-accent2-100 p-2 text-accent2-500">
              <CheckCircle2 className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">92.4%</div>
            <div className="flex items-center pt-1">
              <span className="text-xs text-accent2-500 flex items-center font-medium">
                <ArrowUpRight className="mr-1 h-3 w-3" />
                1.2%
              </span>
              <span className="text-xs text-muted-foreground ml-1">from last week</span>
            </div>
            <Progress value={92.4} className="h-1 mt-2 bg-accent2-100" indicatorClassName="bg-accent2-500" />
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-accent1-500 hover:shadow-md transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Fee Collection</CardTitle>
            <div className="rounded-full bg-accent1-100 p-2 text-accent1-500">
              <CreditCard className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹8.2L</div>
            <div className="flex items-center pt-1">
              <span className="text-xs text-red-600 flex items-center font-medium">
                <ArrowDownRight className="mr-1 h-3 w-3" />
                3.2%
              </span>
              <span className="text-xs text-muted-foreground ml-1">pending collection</span>
            </div>
            <Progress value={86} className="h-1 mt-2 bg-accent1-100" indicatorClassName="bg-accent1-500" />
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-theme-400 hover:shadow-md transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">New Admissions</CardTitle>
            <div className="rounded-full bg-theme-100 p-2 text-theme-400">
              <UserPlus className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">48</div>
            <div className="flex items-center pt-1">
              <span className="text-xs text-theme-500 flex items-center font-medium">
                <ArrowUpRight className="mr-1 h-3 w-3" />
                24%
              </span>
              <span className="text-xs text-muted-foreground ml-1">from last month</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-6">
        <Card className="col-span-6 md:col-span-4 hover:shadow-md transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Enrollment Trend</CardTitle>
              <CardDescription>Student enrollment over the academic year</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Select defaultValue="year">
                <SelectTrigger className="w-[120px] h-8">
                  <SelectValue placeholder="Period" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="year">Year</SelectItem>
                  <SelectItem value="quarter">Quarter</SelectItem>
                  <SelectItem value="month">Month</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" size="sm">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
            </div>
          </CardHeader>
          <CardContent className="pl-2">
            <EnrollmentTrend />
          </CardContent>
        </Card>

        <Card className="col-span-6 md:col-span-2 hover:shadow-md transition-all duration-300">
          <CardHeader>
            <CardTitle>Upcoming Events</CardTitle>
            <CardDescription>Next 7 days</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start space-x-4">
                <div className="bg-theme-500 text-white rounded-md p-2 flex flex-col items-center justify-center min-w-[48px]">
                  <span className="text-xs font-semibold">MAY</span>
                  <span className="text-lg font-bold">25</span>
                </div>
                <div>
                  <h4 className="text-sm font-semibold">Annual Sports Day</h4>
                  <p className="text-xs text-muted-foreground">9:00 AM - 4:00 PM</p>
                  <div className="flex items-center mt-1">
                    <Clock className="h-3 w-3 text-muted-foreground mr-1" />
                    <span className="text-xs text-muted-foreground">In 3 days</span>
                  </div>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-accent2-500 text-white rounded-md p-2 flex flex-col items-center justify-center min-w-[48px]">
                  <span className="text-xs font-semibold">JUN</span>
                  <span className="text-lg font-bold">05</span>
                </div>
                <div>
                  <h4 className="text-sm font-semibold">Science Exhibition</h4>
                  <p className="text-xs text-muted-foreground">10:00 AM - 2:00 PM</p>
                  <div className="flex items-center mt-1">
                    <Clock className="h-3 w-3 text-muted-foreground mr-1" />
                    <span className="text-xs text-muted-foreground">In 2 weeks</span>
                  </div>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-accent1-500 text-white rounded-md p-2 flex flex-col items-center justify-center min-w-[48px]">
                  <span className="text-xs font-semibold">JUN</span>
                  <span className="text-lg font-bold">15</span>
                </div>
                <div>
                  <h4 className="text-sm font-semibold">Cultural Program</h4>
                  <p className="text-xs text-muted-foreground">5:00 PM - 8:00 PM</p>
                  <div className="flex items-center mt-1">
                    <Clock className="h-3 w-3 text-muted-foreground mr-1" />
                    <span className="text-xs text-muted-foreground">In 3 weeks</span>
                  </div>
                </div>
              </div>
            </div>

            <Button variant="ghost" className="w-full mt-4 text-xs h-8 text-theme-500 hover:bg-theme-50">
              View All Events
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-6">
        <Card className="col-span-6 md:col-span-3 hover:shadow-md transition-all duration-300">
          <CardHeader>
            <CardTitle>Academic Performance</CardTitle>
            <CardDescription>Average scores by subject</CardDescription>
          </CardHeader>
          <CardContent>
            <AcademicPerformance />
          </CardContent>
        </Card>

        <Card className="col-span-6 md:col-span-3 hover:shadow-md transition-all duration-300">
          <CardHeader>
            <CardTitle>Student Distribution</CardTitle>
            <CardDescription>By class and gender</CardDescription>
          </CardHeader>
          <CardContent>
            <StudentDistribution />
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-6">
        <Card className="col-span-6 md:col-span-2 hover:shadow-md transition-all duration-300">
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest updates</CardDescription>
          </CardHeader>
          <CardContent>
            <RecentActivity />
          </CardContent>
        </Card>

        <Card className="col-span-6 md:col-span-2 hover:shadow-md transition-all duration-300">
          <CardHeader>
            <CardTitle>Recent Notices</CardTitle>
            <CardDescription>Latest announcements</CardDescription>
          </CardHeader>
          <CardContent>
            <RecentNotices />
          </CardContent>
        </Card>

        <Card className="col-span-6 md:col-span-2 hover:shadow-md transition-all duration-300">
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Frequently used functions</CardDescription>
          </CardHeader>
          <CardContent>
            <QuickActions />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
