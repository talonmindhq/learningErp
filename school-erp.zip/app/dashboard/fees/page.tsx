"use client"

import { useState, useEffect } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart,
  LineChart,
  PieChart,
  DollarSign,
  Users,
  CreditCard,
  AlertTriangle,
  ArrowUpRight,
  CalendarDays,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Skeleton } from "@/components/ui/skeleton"

export default function FeeDashboardPage() {
  const [activeTab, setActiveTab] = useState("overview")
  const [isLoading, setIsLoading] = useState(true)

  // Sample data for the fee dashboard
  const feeStats = {
    totalCollected: "₹12,45,000",
    totalOutstanding: "₹3,85,000",
    totalStudents: 1250,
    paidStudents: 950,
    defaulters: 300,
    collectionRate: 76,
    monthlyCollection: [
      { month: "Jan", amount: 125000 },
      { month: "Feb", amount: 110000 },
      { month: "Mar", amount: 135000 },
      { month: "Apr", amount: 150000 },
      { month: "May", amount: 110000 },
      { month: "Jun", amount: 90000 },
      { month: "Jul", amount: 105000 },
      { month: "Aug", amount: 125000 },
      { month: "Sep", amount: 140000 },
      { month: "Oct", amount: 155000 },
      { month: "Nov", amount: 0 },
      { month: "Dec", amount: 0 },
    ],
    feeTypes: [
      { type: "Tuition Fee", amount: 850000, percentage: 68 },
      { type: "Transport Fee", amount: 180000, percentage: 14 },
      { type: "Examination Fee", amount: 125000, percentage: 10 },
      { type: "Miscellaneous", amount: 90000, percentage: 8 },
    ],
  }

  // Simulate data loading on component mount
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1000)
    return () => clearTimeout(timer)
  }, [])

  // Calculate today's date for the due date notification
  const today = new Date()
  const dueDate = new Date(today.getFullYear(), today.getMonth(), 15)
  const formattedDueDate = dueDate.toLocaleDateString("en-US", {
    day: "numeric",
    month: "long",
  })

  const dueDatePassed = today > dueDate

  if (isLoading) {
    return (
      <PageTemplate
        title="Fee Management"
        description="Manage school fee structure, collection, and reports"
        breadcrumbs={[
          { title: "Dashboard", href: "/dashboard" },
          { title: "Fee Management", href: "/dashboard/fees", isCurrentPage: true },
        ]}
        actionButton={{
          label: "Collect Fee",
          icon: <DollarSign className="h-4 w-4 mr-2" />,
          href: "/dashboard/fees/collect",
        }}
      >
        <div className="space-y-4">
          {/* Fee Due Notification Skeleton */}
          <Card>
            <CardContent className="flex items-center justify-between p-6">
              <div className="flex items-center">
                <Skeleton className="h-5 w-5 mr-2" />
                <Skeleton className="h-5 w-64" />
              </div>
              <Skeleton className="h-9 w-32" />
            </CardContent>
          </Card>

          {/* Fee Statistics Cards Skeleton */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {Array(4)
              .fill(null)
              .map((_, i) => (
                <Card key={i}>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <Skeleton className="h-5 w-32" />
                    <Skeleton className="h-4 w-4" />
                  </CardHeader>
                  <CardContent>
                    <Skeleton className="h-8 w-24 mb-1" />
                    <Skeleton className="h-4 w-32" />
                  </CardContent>
                </Card>
              ))}
          </div>

          {/* Tabs Skeleton */}
          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-48 mb-2" />
              <Skeleton className="h-4 w-64" />
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Array(3)
                  .fill(null)
                  .map((_, i) => (
                    <Skeleton key={i} className="h-16 w-full" />
                  ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </PageTemplate>
    )
  }

  return (
    <PageTemplate
      title="Fee Management"
      description="Manage school fee structure, collection, and reports"
      breadcrumbs={[
        { title: "Dashboard", href: "/dashboard" },
        { title: "Fee Management", href: "/dashboard/fees", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Collect Fee",
        icon: <DollarSign className="h-4 w-4 mr-2" />,
        href: "/dashboard/fees/collect",
      }}
    >
      <div className="space-y-4">
        {/* Fee Due Notification */}
        <Card className={dueDatePassed ? "bg-red-50 border-red-200" : "bg-blue-50 border-blue-200"}>
          <CardContent className="flex items-center justify-between p-6">
            <div className="flex items-center">
              {dueDatePassed ? (
                <AlertTriangle className="h-5 w-5 mr-2 text-red-500" />
              ) : (
                <CalendarDays className="h-5 w-5 mr-2 text-blue-500" />
              )}
              <p className={dueDatePassed ? "text-red-700" : "text-blue-700"}>
                {dueDatePassed
                  ? `Fee due date (${formattedDueDate}) has passed. ${feeStats.defaulters} students have not paid.`
                  : `Monthly fee due date is ${formattedDueDate}. Send reminders to parents.`}
              </p>
            </div>
            <Button variant={dueDatePassed ? "destructive" : "outline"} size="sm">
              {dueDatePassed ? "Notify Defaulters" : "Send Reminders"}
            </Button>
          </CardContent>
        </Card>

        {/* Fee Statistics Cards */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Collected</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{feeStats.totalCollected}</div>
              <p className="text-xs text-muted-foreground">Academic Year 2023-24</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Outstanding Amount</CardTitle>
              <AlertTriangle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{feeStats.totalOutstanding}</div>
              <p className="text-xs text-muted-foreground">+5.1% from last month</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Fee Defaulters</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{feeStats.defaulters}</div>
              <p className="text-xs text-muted-foreground">
                {((feeStats.defaulters / feeStats.totalStudents) * 100).toFixed(1)}% of total students
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Collection Rate</CardTitle>
              <CreditCard className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{feeStats.collectionRate}%</div>
              <Progress value={feeStats.collectionRate} className="h-2" />
            </CardContent>
          </Card>
        </div>

        {/* Fee Dashboard Tabs */}
        <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="monthly">Monthly Collection</TabsTrigger>
            <TabsTrigger value="structure">Fee Structure</TabsTrigger>
            <TabsTrigger value="defaulters">Defaulters</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Fee Collection by Type</CardTitle>
                  <CardDescription>Distribution of fees collected for current academic year</CardDescription>
                </CardHeader>
                <CardContent className="pl-2">
                  <div className="flex items-center justify-center h-60">
                    <PieChart className="h-40 w-40 text-gray-300" />
                  </div>
                  <div className="space-y-2 mt-4">
                    {feeStats.feeTypes.map((type, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div
                            className={`w-3 h-3 rounded-full ${
                              index === 0
                                ? "bg-blue-500"
                                : index === 1
                                  ? "bg-green-500"
                                  : index === 2
                                    ? "bg-yellow-500"
                                    : "bg-purple-500"
                            }`}
                          />
                          <span className="text-sm">{type.type}</span>
                        </div>
                        <div className="flex gap-4">
                          <span className="text-sm">₹{(type.amount / 1000).toFixed(0)}K</span>
                          <span className="text-sm text-muted-foreground">{type.percentage}%</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Fee Payment Analytics</CardTitle>
                  <CardDescription>Student payment status and mode</CardDescription>
                </CardHeader>
                <CardContent className="space-y-8">
                  <div>
                    <h4 className="text-sm font-medium mb-3">Payment Status</h4>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-green-500" />
                          <span className="text-sm">Paid</span>
                        </div>
                        <div className="flex gap-2">
                          <span className="text-sm">{feeStats.paidStudents}</span>
                          <span className="text-sm text-muted-foreground">
                            ({((feeStats.paidStudents / feeStats.totalStudents) * 100).toFixed(0)}%)
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-red-500" />
                          <span className="text-sm">Unpaid</span>
                        </div>
                        <div className="flex gap-2">
                          <span className="text-sm">{feeStats.defaulters}</span>
                          <span className="text-sm text-muted-foreground">
                            ({((feeStats.defaulters / feeStats.totalStudents) * 100).toFixed(0)}%)
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="mt-3 h-2 w-full bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-green-500 rounded-full"
                        style={{ width: `${(feeStats.paidStudents / feeStats.totalStudents) * 100}%` }}
                      />
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium mb-3">Payment Mode</h4>
                    <div className="flex items-center justify-center h-32">
                      <BarChart className="h-32 w-32 text-gray-300" />
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-center mt-2">
                      <div className="space-y-1">
                        <div className="text-xl font-semibold">45%</div>
                        <div className="text-xs text-muted-foreground">Online Banking</div>
                      </div>
                      <div className="space-y-1">
                        <div className="text-xl font-semibold">32%</div>
                        <div className="text-xs text-muted-foreground">UPI</div>
                      </div>
                      <div className="space-y-1">
                        <div className="text-xl font-semibold">23%</div>
                        <div className="text-xs text-muted-foreground">Cash/Cheque</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Recent Transactions</CardTitle>
                <CardDescription>Last 5 fee transactions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
                          <DollarSign className="h-5 w-5 text-gray-500" />
                        </div>
                        <div>
                          <div className="font-medium">Student {5 - i}</div>
                          <div className="text-sm text-muted-foreground">
                            Receipt #{1000 + i} •{" "}
                            {["Tuition Fee", "Transport Fee", "Tuition Fee", "Misc Fee", "Annual Fee"][i]}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium">₹{[12500, 8000, 15000, 2500, 20000][i].toLocaleString()}</div>
                        <div className="text-xs text-muted-foreground">
                          {new Date(2023, 9, 10 - i).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-4 text-center">
                  <Button variant="link" className="text-sm" asChild>
                    <a href="/dashboard/fees/collect">View all transactions</a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="monthly" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Monthly Fee Collection Trend</CardTitle>
                <CardDescription>Fee collection trend for the academic year 2023-24</CardDescription>
              </CardHeader>
              <CardContent className="pl-2">
                <div className="flex items-center justify-center h-80">
                  <LineChart className="h-60 w-full text-gray-300" />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="structure" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              {[
                {
                  title: "Fee Structure",
                  description: "View and manage fee structure for various classes",
                  link: "/dashboard/fees/structure",
                },
                {
                  title: "Fee Types",
                  description: "Configure different types of fees applicable",
                  link: "/dashboard/fees/types",
                },
                {
                  title: "Payment Schedule",
                  description: "Set up fee payment schedules and due dates",
                  link: "/dashboard/fees/schedule",
                },
                {
                  title: "Discounts & Concessions",
                  description: "Manage fee discounts and scholarship schemes",
                  link: "/dashboard/fees/discounts",
                },
                {
                  title: "Advanced Settings",
                  description: "Configure discounts, schedules, and receipt templates",
                  link: "/dashboard/fees/advanced",
                },
              ].map((item, i) => (
                <Card key={i} className="hover:bg-gray-50 transition-colors cursor-pointer">
                  <CardHeader>
                    <CardTitle>{item.title}</CardTitle>
                    <CardDescription>{item.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="flex justify-end">
                    <Button variant="ghost" size="sm" asChild>
                      <a href={item.link}>
                        <span>View Details</span>
                        <ArrowUpRight className="ml-2 h-4 w-4" />
                      </a>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="defaulters" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Fee Defaulters Summary</CardTitle>
                <CardDescription>Students with outstanding fee payments</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-3">
                  <Card>
                    <CardContent className="p-6">
                      <div className="text-center">
                        <Users className="h-8 w-8 mx-auto mb-2 text-amber-500" />
                        <div className="text-2xl font-bold">{feeStats.defaulters}</div>
                        <p className="text-sm text-muted-foreground">Total Defaulters</p>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-6">
                      <div className="text-center">
                        <DollarSign className="h-8 w-8 mx-auto mb-2 text-red-500" />
                        <div className="text-2xl font-bold">{feeStats.totalOutstanding}</div>
                        <p className="text-sm text-muted-foreground">Outstanding Amount</p>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-6">
                      <div className="text-center">
                        <AlertTriangle className="h-8 w-8 mx-auto mb-2 text-yellow-500" />
                        <div className="text-2xl font-bold">45</div>
                        <p className="text-sm text-muted-foreground">Critical ({">"}60 days)</p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
                <div className="text-center">
                  <Button asChild>
                    <a href="/dashboard/fees/defaulters">View All Defaulters</a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PageTemplate>
  )
}
