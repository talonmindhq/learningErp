"use client"

import React from "react"

import { useState } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PlusCircle, Edit, Trash2, MoreHorizontal, Download, Search } from "lucide-react"

export default function FeeStructurePage() {
  const [selectedClass, setSelectedClass] = useState("all")
  const [openDialog, setOpenDialog] = useState(false)
  const [activeTab, setActiveTab] = useState("primary")
  const [searchTerm, setSearchTerm] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  // Sample fee structure data
  const feeData = {
    primary: [
      {
        class: "Grade 1",
        tuitionFee: 25000,
        admissionFee: 5000,
        sportsFee: 2000,
        libraryFee: 1500,
        transportFee: 8000,
        examFee: 1200,
        totalAnnual: 42700,
        installments: [14300, 14200, 14200],
      },
      {
        class: "Grade 2",
        tuitionFee: 26000,
        admissionFee: 5000,
        sportsFee: 2000,
        libraryFee: 1500,
        transportFee: 8000,
        examFee: 1200,
        totalAnnual: 43700,
        installments: [14600, 14550, 14550],
      },
      {
        class: "Grade 3",
        tuitionFee: 27000,
        admissionFee: 5000,
        sportsFee: 2000,
        libraryFee: 1500,
        transportFee: 8000,
        examFee: 1200,
        totalAnnual: 44700,
        installments: [14900, 14900, 14900],
      },
      {
        class: "Grade 4",
        tuitionFee: 28000,
        admissionFee: 5000,
        sportsFee: 2500,
        libraryFee: 1500,
        transportFee: 8000,
        examFee: 1200,
        totalAnnual: 46200,
        installments: [15400, 15400, 15400],
      },
      {
        class: "Grade 5",
        tuitionFee: 30000,
        admissionFee: 5000,
        sportsFee: 2500,
        libraryFee: 2000,
        transportFee: 8000,
        examFee: 1500,
        totalAnnual: 49000,
        installments: [16350, 16325, 16325],
      },
    ],
    middle: [
      {
        class: "Grade 6",
        tuitionFee: 32000,
        admissionFee: 6000,
        sportsFee: 3000,
        libraryFee: 2000,
        transportFee: 8000,
        examFee: 1500,
        totalAnnual: 52500,
        installments: [17500, 17500, 17500],
      },
      {
        class: "Grade 7",
        tuitionFee: 34000,
        admissionFee: 6000,
        sportsFee: 3000,
        libraryFee: 2000,
        transportFee: 8000,
        examFee: 1500,
        totalAnnual: 54500,
        installments: [18200, 18150, 18150],
      },
      {
        class: "Grade 8",
        tuitionFee: 36000,
        admissionFee: 6000,
        sportsFee: 3000,
        libraryFee: 2500,
        transportFee: 8000,
        examFee: 1800,
        totalAnnual: 57300,
        installments: [19100, 19100, 19100],
      },
    ],
    secondary: [
      {
        class: "Grade 9",
        tuitionFee: 38000,
        admissionFee: 7500,
        sportsFee: 3500,
        libraryFee: 2500,
        transportFee: 8000,
        examFee: 2000,
        totalAnnual: 61500,
        installments: [20500, 20500, 20500],
      },
      {
        class: "Grade 10",
        tuitionFee: 40000,
        admissionFee: 7500,
        sportsFee: 3500,
        libraryFee: 3000,
        transportFee: 8000,
        examFee: 3000,
        totalAnnual: 65000,
        installments: [21700, 21650, 21650],
      },
    ],
    higherSecondary: [
      {
        class: "Grade 11",
        tuitionFee: 45000,
        admissionFee: 10000,
        sportsFee: 4000,
        libraryFee: 3500,
        transportFee: 8000,
        examFee: 4000,
        totalAnnual: 74500,
        installments: [24850, 24825, 24825],
      },
      {
        class: "Grade 12",
        tuitionFee: 48000,
        admissionFee: 10000,
        sportsFee: 4000,
        libraryFee: 3500,
        transportFee: 8000,
        examFee: 5000,
        totalAnnual: 78500,
        installments: [26200, 26150, 26150],
      },
    ],
  }

  // Simulate data loading on component mount
  React.useEffect(() => {
    setIsLoading(true)
    // Simulate API call
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1000)
    return () => clearTimeout(timer)
  }, [])

  // Filter and prepare data based on selected tab and search term
  const getData = () => {
    if (!feeData[activeTab]) return []

    let result = [...feeData[activeTab]]

    if (searchTerm) {
      result = result.filter((row) => row.class.toLowerCase().includes(searchTerm.toLowerCase()))
    }

    return result
  }

  const filteredData = getData()

  return (
    <PageTemplate
      title="Fee Structure"
      description="Manage fee structure for different classes and academic years"
      breadcrumbs={[
        { title: "Dashboard", href: "/dashboard" },
        { title: "Fee Management", href: "/dashboard/fees" },
        { title: "Fee Structure", href: "/dashboard/fees/structure", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Add Fee Structure",
        icon: <PlusCircle className="h-4 w-4 mr-2" />,
        onClick: () => setOpenDialog(true),
      }}
    >
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle>Fee Structure (2023-24)</CardTitle>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search..."
                className="w-64 pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={selectedClass} onValueChange={setSelectedClass}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Filter by Academic Year" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Academic Years</SelectItem>
                <SelectItem value="2023-24">2023-24</SelectItem>
                <SelectItem value="2022-23">2022-23</SelectItem>
                <SelectItem value="2021-22">2021-22</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs onValueChange={setActiveTab} value={activeTab}>
            <TabsList>
              <TabsTrigger value="primary">Primary (1-5)</TabsTrigger>
              <TabsTrigger value="middle">Middle (6-8)</TabsTrigger>
              <TabsTrigger value="secondary">Secondary (9-10)</TabsTrigger>
              <TabsTrigger value="higherSecondary">Higher Secondary (11-12)</TabsTrigger>
            </TabsList>
            <TabsContent value={activeTab} className="mt-6">
              {isLoading ? (
                <div className="space-y-4">
                  {Array(5)
                    .fill(null)
                    .map((_, i) => (
                      <div key={i} className="h-12 bg-gray-100 animate-pulse rounded-md" />
                    ))}
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[150px]">Class</TableHead>
                        <TableHead>Tuition Fee</TableHead>
                        <TableHead>Admission Fee</TableHead>
                        <TableHead>Sports Fee</TableHead>
                        <TableHead>Library Fee</TableHead>
                        <TableHead>Transport Fee</TableHead>
                        <TableHead>Exam Fee</TableHead>
                        <TableHead>Total Annual</TableHead>
                        <TableHead>Term 1</TableHead>
                        <TableHead>Term 2</TableHead>
                        <TableHead>Term 3</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredData.length > 0 ? (
                        filteredData.map((row, index) => (
                          <TableRow key={index}>
                            <TableCell className="font-medium">{row.class}</TableCell>
                            <TableCell>₹{row.tuitionFee}</TableCell>
                            <TableCell>₹{row.admissionFee}</TableCell>
                            <TableCell>₹{row.sportsFee}</TableCell>
                            <TableCell>₹{row.libraryFee}</TableCell>
                            <TableCell>₹{row.transportFee}</TableCell>
                            <TableCell>₹{row.examFee}</TableCell>
                            <TableCell className="font-medium">₹{row.totalAnnual}</TableCell>
                            <TableCell>₹{row.installments[0]}</TableCell>
                            <TableCell>₹{row.installments[1]}</TableCell>
                            <TableCell>₹{row.installments[2]}</TableCell>
                            <TableCell className="text-right">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" className="h-8 w-8 p-0">
                                    <span className="sr-only">Open menu</span>
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                  <DropdownMenuItem>
                                    <Edit className="h-4 w-4 mr-2" />
                                    Edit
                                  </DropdownMenuItem>
                                  <DropdownMenuItem>
                                    <Download className="h-4 w-4 mr-2" />
                                    Export
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem className="text-red-600">
                                    <Trash2 className="h-4 w-4 mr-2" />
                                    Delete
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={12} className="text-center py-6 text-muted-foreground">
                            No fee structure data found for the selected criteria
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Add/Edit Fee Structure Dialog */}
      <Dialog open={openDialog} onOpenChange={setOpenDialog}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Add New Fee Structure</DialogTitle>
            <DialogDescription>Define fee structure for a class. Click save when you're done.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="class">Class</Label>
                <Select defaultValue="grade1">
                  <SelectTrigger>
                    <SelectValue placeholder="Select class" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="grade1">Grade 1</SelectItem>
                    <SelectItem value="grade2">Grade 2</SelectItem>
                    <SelectItem value="grade3">Grade 3</SelectItem>
                    <SelectItem value="grade4">Grade 4</SelectItem>
                    <SelectItem value="grade5">Grade 5</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="academic-year">Academic Year</Label>
                <Select defaultValue="2023-24">
                  <SelectTrigger>
                    <SelectValue placeholder="Select academic year" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="2023-24">2023-24</SelectItem>
                    <SelectItem value="2024-25">2024-25</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="tuition-fee">Tuition Fee (₹)</Label>
              <Input id="tuition-fee" type="number" placeholder="Enter amount" defaultValue="25000" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="admission-fee">Admission Fee (₹)</Label>
                <Input id="admission-fee" type="number" placeholder="Enter amount" defaultValue="5000" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="sports-fee">Sports Fee (₹)</Label>
                <Input id="sports-fee" type="number" placeholder="Enter amount" defaultValue="2000" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="library-fee">Library Fee (₹)</Label>
                <Input id="library-fee" type="number" placeholder="Enter amount" defaultValue="1500" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="exam-fee">Examination Fee (₹)</Label>
                <Input id="exam-fee" type="number" placeholder="Enter amount" defaultValue="1200" />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="transport-fee">Transport Fee (₹)</Label>
              <Input id="transport-fee" type="number" placeholder="Enter amount" defaultValue="8000" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpenDialog(false)}>
              Cancel
            </Button>
            <Button type="submit" onClick={() => setOpenDialog(false)}>
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageTemplate>
  )
}
