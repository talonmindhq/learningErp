import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"

export default function FeeStructureLoading() {
  return (
    <PageTemplate
      title="Fee Structure"
      description="Manage fee structure for different classes and academic years"
      breadcrumbs={[
        { title: "Dashboard", href: "/dashboard" },
        { title: "Fee Management", href: "/dashboard/fees" },
        { title: "Fee Structure", href: "/dashboard/fees/structure", isCurrentPage: true },
      ]}
    >
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <Skeleton className="h-6 w-48" />
          <div className="flex items-center gap-2">
            <Skeleton className="h-10 w-64" />
            <Skeleton className="h-10 w-[200px]" />
            <Skeleton className="h-10 w-[120px]" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <Skeleton className="h-10 w-96" />

            <div className="space-y-1">
              <div className="flex items-center justify-between h-12 px-4 border-b">
                <Skeleton className="h-4 w-[8%]" />
                <Skeleton className="h-4 w-[8%]" />
                <Skeleton className="h-4 w-[8%]" />
                <Skeleton className="h-4 w-[8%]" />
                <Skeleton className="h-4 w-[8%]" />
                <Skeleton className="h-4 w-[8%]" />
                <Skeleton className="h-4 w-[8%]" />
                <Skeleton className="h-4 w-[8%]" />
                <Skeleton className="h-4 w-[8%]" />
                <Skeleton className="h-4 w-[8%]" />
                <Skeleton className="h-4 w-[8%]" />
                <Skeleton className="h-4 w-[8%]" />
              </div>

              {Array(5)
                .fill(null)
                .map((_, index) => (
                  <div key={index} className="flex items-center justify-between h-16 px-4 border-b">
                    <Skeleton className="h-4 w-[8%]" />
                    <Skeleton className="h-4 w-[8%]" />
                    <Skeleton className="h-4 w-[8%]" />
                    <Skeleton className="h-4 w-[8%]" />
                    <Skeleton className="h-4 w-[8%]" />
                    <Skeleton className="h-4 w-[8%]" />
                    <Skeleton className="h-4 w-[8%]" />
                    <Skeleton className="h-4 w-[8%]" />
                    <Skeleton className="h-4 w-[8%]" />
                    <Skeleton className="h-4 w-[8%]" />
                    <Skeleton className="h-4 w-[8%]" />
                    <Skeleton className="h-8 w-[8%]" />
                  </div>
                ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </PageTemplate>
  )
}
