"use client"

import { useState } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Search, Download, Mail, Phone, MoreHorizontal, AlertTriangle, Calendar } from "lucide-react"

export default function FeeDefaultersPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedClass, setSelectedClass] = useState("all")
  const [selectedDuration, setSelectedDuration] = useState("all")

  // Sample data for classes
  const classes = ["Grade 1-A", "Grade 1-B", "Grade 2-A", "Grade 8-C", "Grade 10-A", "Grade 12-B"]

  // Sample data for defaulters
  const defaulters = [
    {
      id: 1,
      name: "John Doe",
      rollNo: "G5A001",
      class: "Grade 5-A",
      parent: "Robert Doe",
      contactNo: "+91 98765 43210",
      email: "robert.doe@example.com",
      outstandingAmount: 15000,
      dueDate: "2023-08-15",
      duration: 85,
      feeTypes: ["Tuition Fee", "Transport Fee"],
    },
    {
      id: 2,
      name: "Jane Smith",
      rollNo: "G8B015",
      class: "Grade 8-B",
      parent: "Michael Smith",
      contactNo: "+91 98765 43211",
      email: "michael.smith@example.com",
      outstandingAmount: 18500,
      dueDate: "2023-09-10",
      duration: 60,
      feeTypes: ["Tuition Fee", "Library Fee", "Exam Fee"],
    },
    {
      id: 3,
      name: "Emma Wilson",
      rollNo: "G3C009",
      class: "Grade 3-C",
      parent: "David Wilson",
      contactNo: "+91 98765 43212",
      email: "david.wilson@example.com",
      outstandingAmount: 8200,
      dueDate: "2023-10-05",
      duration: 35,
      feeTypes: ["Tuition Fee"],
    },
    {
      id: 4,
      name: "Michael Johnson",
      rollNo: "G10A022",
      class: "Grade 10-A",
      parent: "Sarah Johnson",
      contactNo: "+91 98765 43213",
      email: "sarah.johnson@example.com",
      outstandingAmount: 22000,
      dueDate: "2023-07-15",
      duration: 115,
      feeTypes: ["Tuition Fee", "Transport Fee", "Hostel Fee"],
    },
    {
      id: 5,
      name: "Olivia Brown",
      rollNo: "G7B018",
      class: "Grade 7-B",
      parent: "James Brown",
      contactNo: "+91 98765 43214",
      email: "james.brown@example.com",
      outstandingAmount: 12500,
      dueDate: "2023-09-20",
      duration: 50,
      feeTypes: ["Tuition Fee", "Computer Lab Fee"],
    },
    {
      id: 6,
      name: "William Davis",
      rollNo: "G12A007",
      class: "Grade 12-A",
      parent: "Mary Davis",
      contactNo: "+91 98765 43215",
      email: "mary.davis@example.com",
      outstandingAmount: 28000,
      dueDate: "2023-08-20",
      duration: 80,
      feeTypes: ["Tuition Fee", "Lab Fee", "Exam Fee", "Transport Fee"],
    },
  ]

  // Filter defaulters based on search query, class, and duration
  const filteredDefaulters = defaulters.filter((defaulter) => {
    const matchesSearch =
      defaulter.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      defaulter.rollNo.toLowerCase().includes(searchQuery.toLowerCase()) ||
      defaulter.parent.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesClass = selectedClass === "all" || defaulter.class === selectedClass

    const matchesDuration =
      selectedDuration === "all" ||
      (selectedDuration === "30" && defaulter.duration <= 30) ||
      (selectedDuration === "60" && defaulter.duration <= 60 && defaulter.duration > 30) ||
      (selectedDuration === "90" && defaulter.duration <= 90 && defaulter.duration > 60) ||
      (selectedDuration === "90+" && defaulter.duration > 90)

    return matchesSearch && matchesClass && matchesDuration
  })

  return (
    <PageTemplate
      title="Fee Defaulters"
      description="Manage students with outstanding fee payments"
      breadcrumbs={[
        { title: "Dashboard", href: "/dashboard" },
        { title: "Fee Management", href: "/dashboard/fees" },
        { title: "Fee Defaulters", href: "/dashboard/fees/defaulters", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Send Reminders",
        icon: <Mail className="h-4 w-4 mr-2" />,
        onClick: () => alert("This would send reminders to all selected defaulters"),
      }}
    >
      <div className="space-y-4">
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle>Fee Defaulters List</CardTitle>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Search by name, ID or parent..."
                    className="w-64 pl-8"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <Select value={selectedClass} onValueChange={setSelectedClass}>
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Select class" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Classes</SelectItem>
                    {classes.map((cls) => (
                      <SelectItem key={cls} value={cls}>
                        {cls}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={selectedDuration} onValueChange={setSelectedDuration}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Outstanding duration" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Durations</SelectItem>
                    <SelectItem value="30">Less than 30 days</SelectItem>
                    <SelectItem value="60">30-60 days</SelectItem>
                    <SelectItem value="90">60-90 days</SelectItem>
                    <SelectItem value="90+">More than 90 days</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[100px]">Roll No</TableHead>
                  <TableHead>Student Name</TableHead>
                  <TableHead>Class</TableHead>
                  <TableHead>Outstanding Amount</TableHead>
                  <TableHead>Due Since</TableHead>
                  <TableHead>Fee Types</TableHead>
                  <TableHead>Parent Contact</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredDefaulters.map((defaulter) => (
                  <TableRow key={defaulter.id}>
                    <TableCell className="font-medium">{defaulter.rollNo}</TableCell>
                    <TableCell>{defaulter.name}</TableCell>
                    <TableCell>{defaulter.class}</TableCell>
                    <TableCell>₹{defaulter.outstandingAmount}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
                        <span>{new Date(defaulter.dueDate).toLocaleDateString()}</span>
                        <Badge
                          variant="outline"
                          className={
                            defaulter.duration > 90
                              ? "ml-2 bg-red-50 text-red-700 hover:bg-red-50"
                              : defaulter.duration > 60
                                ? "ml-2 bg-amber-50 text-amber-700 hover:bg-amber-50"
                                : "ml-2 bg-yellow-50 text-yellow-700 hover:bg-yellow-50"
                          }
                        >
                          {defaulter.duration} days
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {defaulter.feeTypes.map((type, i) => (
                          <Badge key={i} variant="outline" className="bg-blue-50 text-blue-700 hover:bg-blue-50">
                            {type}
                          </Badge>
                        ))}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="text-sm">{defaulter.parent}</div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Phone className="h-3 w-3" />
                          {defaulter.contactNo}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <span className="sr-only">Open menu</span>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <DropdownMenuItem>
                            <Mail className="mr-2 h-4 w-4" />
                            <span>Send Email</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Phone className="mr-2 h-4 w-4" />
                            <span>SMS Reminder</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <AlertTriangle className="mr-2 h-4 w-4" />
                            <span>Mark as Critical</span>
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>
                            <span>View Fee History</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <span>Collect Payment</span>
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
                {filteredDefaulters.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-6 text-muted-foreground">
                      No defaulters found matching your filters
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Total Outstanding Amount</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                ₹{filteredDefaulters.reduce((sum, defaulter) => sum + defaulter.outstandingAmount, 0).toLocaleString()}
              </div>
              <p className="text-xs text-muted-foreground mt-1">From {filteredDefaulters.length} students</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Critical Defaulters (90+ days)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">
                {filteredDefaulters.filter((d) => d.duration > 90).length}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Outstanding: ₹
                {filteredDefaulters
                  .filter((d) => d.duration > 90)
                  .reduce((sum, d) => sum + d.outstandingAmount, 0)
                  .toLocaleString()}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Recovery Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">78%</div>
              <p className="text-xs text-muted-foreground mt-1">+2.5% from last month</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageTemplate>
  )
}
