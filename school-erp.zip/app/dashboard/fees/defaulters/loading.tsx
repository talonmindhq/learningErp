import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"

export default function FeeDefaultersLoading() {
  return (
    <PageTemplate
      title="Fee Defaulters"
      description="Manage students with outstanding fee payments"
      breadcrumbs={[
        { title: "Dashboard", href: "/dashboard" },
        { title: "Fee Management", href: "/dashboard/fees" },
        { title: "Fee Defaulters", href: "/dashboard/fees/defaulters", isCurrentPage: true },
      ]}
    >
      <div className="space-y-4">
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <Skeleton className="h-6 w-40" />
              <div className="flex items-center gap-2">
                <Skeleton className="h-10 w-64" />
                <Skeleton className="h-10 w-[150px]" />
                <Skeleton className="h-10 w-[180px]" />
                <Skeleton className="h-10 w-[120px]" />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-1">
              <div className="flex items-center justify-between h-12 px-4 border-b">
                <Skeleton className="h-4 w-[10%]" />
                <Skeleton className="h-4 w-[15%]" />
                <Skeleton className="h-4 w-[10%]" />
                <Skeleton className="h-4 w-[15%]" />
                <Skeleton className="h-4 w-[10%]" />
                <Skeleton className="h-4 w-[15%]" />
                <Skeleton className="h-4 w-[15%]" />
                <Skeleton className="h-4 w-[10%]" />
              </div>

              {Array(6)
                .fill(null)
                .map((_, index) => (
                  <div key={index} className="flex items-center justify-between h-20 px-4 border-b">
                    <Skeleton className="h-4 w-[10%]" />
                    <Skeleton className="h-4 w-[15%]" />
                    <Skeleton className="h-4 w-[10%]" />
                    <Skeleton className="h-4 w-[15%]" />
                    <Skeleton className="h-4 w-[10%]" />
                    <Skeleton className="h-16 w-[15%]" />
                    <Skeleton className="h-16 w-[15%]" />
                    <Skeleton className="h-8 w-[10%]" />
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {Array(3)
            .fill(null)
            .map((_, index) => (
              <Card key={index}>
                <CardHeader className="pb-2">
                  <Skeleton className="h-5 w-40" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-8 w-24 mb-1" />
                  <Skeleton className="h-4 w-32" />
                </CardContent>
              </Card>
            ))}
        </div>
      </div>
    </PageTemplate>
  )
}
