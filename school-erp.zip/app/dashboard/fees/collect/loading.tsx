import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"

export default function FeeCollectionLoading() {
  return (
    <PageTemplate
      title="Fee Collection"
      description="Collect fees from students and generate receipts"
      breadcrumbs={[
        { title: "Dashboard", href: "/dashboard" },
        { title: "Fee Management", href: "/dashboard/fees" },
        { title: "Fee Collection", href: "/dashboard/fees/collect", isCurrentPage: true },
      ]}
    >
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-40" />
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex space-x-2">
                <Skeleton className="h-10 flex-1" />
                <Skeleton className="h-10 w-24" />
              </div>

              <div className="text-center">
                <Skeleton className="h-4 w-48 mx-auto" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-36" />
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Skeleton className="h-5 w-36 mb-2" />
              {Array(4)
                .fill(null)
                .map((_, index) => (
                  <Skeleton key={index} className="h-16 w-full mb-2" />
                ))}
            </div>

            <Skeleton className="h-1 w-full" />

            <div>
              <Skeleton className="h-5 w-36 mb-2" />
              <div className="space-y-3">
                {Array(4)
                  .fill(null)
                  .map((_, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <Skeleton className="h-4 w-4" />
                      <Skeleton className="h-4 w-24" />
                    </div>
                  ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </PageTemplate>
  )
}
