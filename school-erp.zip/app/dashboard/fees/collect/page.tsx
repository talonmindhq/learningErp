"use client"

import { useState } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Separator } from "@/components/ui/separator"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { DollarSign, Search, CheckCircle, Printer } from "lucide-react"

export default function FeeCollectionPage() {
  const [student, setStudent] = useState(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [showSearchResults, setShowSearchResults] = useState(false)
  const [paymentMethod, setPaymentMethod] = useState("online")
  const [selectedFees, setSelectedFees] = useState([])
  const [showReceipt, setShowReceipt] = useState(false)
  const [receiptData, setReceiptData] = useState(null)

  // Sample student data
  const students = [
    {
      id: 1,
      name: "John Doe",
      class: "Grade 5-A",
      section: "A",
      rollNo: "G5A001",
      feeDetails: [
        { type: "Tuition Fee (Term 2)", amount: 10000, dueDate: "2023-10-15", status: "due" },
        { type: "Sports Fee (Annual)", amount: 2500, dueDate: "2023-07-15", status: "paid" },
        { type: "Library Fee (Annual)", amount: 2000, dueDate: "2023-07-15", status: "paid" },
        { type: "Transport Fee (Term 2)", amount: 2700, dueDate: "2023-10-15", status: "due" },
        { type: "Examination Fee (Term 2)", amount: 500, dueDate: "2023-11-30", status: "due" },
      ],
      totalDue: 13200,
      previousBalance: 0,
    },
    {
      id: 2,
      name: "Jane Smith",
      class: "Grade 8-B",
      section: "B",
      rollNo: "G8B015",
      feeDetails: [
        { type: "Tuition Fee (Term 2)", amount: 12000, dueDate: "2023-10-15", status: "due" },
        { type: "Sports Fee (Annual)", amount: 3000, dueDate: "2023-07-15", status: "paid" },
        { type: "Library Fee (Annual)", amount: 2500, dueDate: "2023-07-15", status: "paid" },
        { type: "Transport Fee (Term 2)", amount: 2700, dueDate: "2023-10-15", status: "due" },
        { type: "Examination Fee (Term 2)", amount: 600, dueDate: "2023-11-30", status: "due" },
      ],
      totalDue: 15300,
      previousBalance: 5000,
    },
  ]

  // Search for students
  const handleSearch = () => {
    if (searchTerm.length >= 3) {
      setShowSearchResults(true)
    }
  }

  // Select a student
  const selectStudent = (student) => {
    setStudent(student)
    // Initially select all due fees
    setSelectedFees(student.feeDetails.filter((fee) => fee.status === "due").map((fee) => fee.type))
    setShowSearchResults(false)
  }

  // Toggle selection of fees
  const toggleFeeSelection = (feeType) => {
    if (selectedFees.includes(feeType)) {
      setSelectedFees(selectedFees.filter((type) => type !== feeType))
    } else {
      setSelectedFees([...selectedFees, feeType])
    }
  }

  // Calculate total amount to pay
  const calculateTotal = () => {
    if (!student) return 0

    return student.feeDetails
      .filter((fee) => fee.status === "due" && selectedFees.includes(fee.type))
      .reduce((sum, fee) => sum + fee.amount, 0)
  }

  // Process payment
  const processPayment = () => {
    // Create receipt data
    const selectedFeeItems = student.feeDetails.filter((fee) => fee.status === "due" && selectedFees.includes(fee.type))

    const receipt = {
      receiptNo: `RCPT-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
      date: new Date().toLocaleDateString(),
      student: student,
      paidItems: selectedFeeItems,
      totalPaid: calculateTotal(),
      paymentMethod: paymentMethod,
      transactionId: `TXN${Math.floor(100000 + Math.random() * 900000)}`,
    }

    setReceiptData(receipt)
    setShowReceipt(true)
  }

  return (
    <PageTemplate
      title="Fee Collection"
      description="Collect fees from students and generate receipts"
      breadcrumbs={[
        { title: "Dashboard", href: "/dashboard" },
        { title: "Fee Management", href: "/dashboard/fees" },
        { title: "Fee Collection", href: "/dashboard/fees/collect", isCurrentPage: true },
      ]}
    >
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Student Information</CardTitle>
          </CardHeader>
          <CardContent>
            {!student ? (
              <div className="space-y-4">
                <div className="flex space-x-2">
                  <div className="flex-1 relative">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search by name, ID, or roll number"
                      className="pl-8"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                  <Button onClick={handleSearch}>Search</Button>
                </div>

                {showSearchResults && (
                  <div className="border rounded-md divide-y">
                    {students
                      .filter(
                        (s) =>
                          s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          s.rollNo.toLowerCase().includes(searchTerm.toLowerCase()),
                      )
                      .map((s) => (
                        <div
                          key={s.id}
                          className="p-3 flex justify-between items-center hover:bg-gray-50 cursor-pointer"
                          onClick={() => selectStudent(s)}
                        >
                          <div>
                            <div className="font-medium">{s.name}</div>
                            <div className="text-sm text-muted-foreground">
                              {s.class} • Roll No: {s.rollNo}
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-medium">₹{s.totalDue}</div>
                            <div className="text-sm text-muted-foreground">Total Due</div>
                          </div>
                        </div>
                      ))}
                    {students.filter(
                      (s) =>
                        s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        s.rollNo.toLowerCase().includes(searchTerm.toLowerCase()),
                    ).length === 0 && (
                      <div className="p-4 text-center text-muted-foreground">
                        No students found matching "{searchTerm}"
                      </div>
                    )}
                  </div>
                )}

                <div className="text-center text-muted-foreground text-sm">Search for a student to collect fees</div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex justify-between">
                  <div>
                    <h3 className="font-medium text-lg">{student.name}</h3>
                    <p className="text-muted-foreground">
                      {student.class} • Roll No: {student.rollNo}
                    </p>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => setStudent(null)}>
                    Change
                  </Button>
                </div>

                <div className="grid grid-cols-2 gap-4 mt-4">
                  <div className="bg-blue-50 rounded-md p-4">
                    <div className="text-sm text-blue-700">Total Due</div>
                    <div className="text-2xl font-bold text-blue-700">₹{student.totalDue}</div>
                  </div>
                  {student.previousBalance > 0 && (
                    <div className="bg-amber-50 rounded-md p-4">
                      <div className="text-sm text-amber-700">Previous Balance</div>
                      <div className="text-2xl font-bold text-amber-700">₹{student.previousBalance}</div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {student && (
          <Card>
            <CardHeader>
              <CardTitle>Fee Payment</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-medium mb-2">Select Fees to Pay</h3>
                {student.feeDetails.map((fee, index) => (
                  <div
                    key={index}
                    className={`flex items-center justify-between p-3 rounded-md mb-2 ${
                      fee.status === "paid" ? "bg-green-50 text-green-700" : "border"
                    }`}
                  >
                    <div className="flex items-center">
                      {fee.status === "due" ? (
                        <Checkbox
                          id={`fee-${index}`}
                          checked={selectedFees.includes(fee.type)}
                          onCheckedChange={() => toggleFeeSelection(fee.type)}
                        />
                      ) : (
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                      )}
                      <Label htmlFor={`fee-${index}`} className="ml-2 cursor-pointer">
                        <span className={fee.status === "paid" ? "opacity-75" : ""}>{fee.type}</span>
                      </Label>
                    </div>
                    <div className="flex items-center">
                      <span className="mr-3">₹{fee.amount}</span>
                      <Badge
                        variant="outline"
                        className={
                          fee.status === "paid"
                            ? "bg-green-50 border-green-200 text-green-700"
                            : "bg-amber-50 border-amber-200 text-amber-700"
                        }
                      >
                        {fee.status === "paid" ? "Paid" : "Due"}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>

              <Separator />

              <div>
                <h3 className="font-medium mb-2">Payment Method</h3>
                <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="cash" id="payment-cash" />
                    <Label htmlFor="payment-cash">Cash</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="online" id="payment-online" />
                    <Label htmlFor="payment-online">Online Banking</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="upi" id="payment-upi" />
                    <Label htmlFor="payment-upi">UPI</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="cheque" id="payment-cheque" />
                    <Label htmlFor="payment-cheque">Cheque</Label>
                  </div>
                </RadioGroup>
              </div>

              {paymentMethod === "online" && (
                <div className="space-y-2">
                  <Label htmlFor="transaction-id">Transaction ID</Label>
                  <Input id="transaction-id" placeholder="Enter transaction ID" />
                </div>
              )}

              {paymentMethod === "cheque" && (
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="cheque-no">Cheque No.</Label>
                    <Input id="cheque-no" placeholder="Enter cheque number" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bank-name">Bank</Label>
                    <Input id="bank-name" placeholder="Enter bank name" />
                  </div>
                </div>
              )}

              {paymentMethod === "upi" && (
                <div className="space-y-2">
                  <Label htmlFor="upi-id">UPI Transaction ID</Label>
                  <Input id="upi-id" placeholder="Enter UPI transaction ID" />
                </div>
              )}
            </CardContent>
            <CardFooter className="flex justify-between border-t pt-6">
              <div>
                <div className="text-sm text-muted-foreground">Total Amount</div>
                <div className="text-2xl font-bold">₹{calculateTotal()}</div>
              </div>
              <Button onClick={processPayment} disabled={selectedFees.length === 0 || calculateTotal() === 0}>
                <DollarSign className="h-4 w-4 mr-2" />
                Pay & Generate Receipt
              </Button>
            </CardFooter>
          </Card>
        )}
      </div>

      {/* Receipt Dialog */}
      <Dialog open={showReceipt} onOpenChange={setShowReceipt}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Payment Receipt</DialogTitle>
            <DialogDescription>The payment has been processed successfully.</DialogDescription>
          </DialogHeader>

          {receiptData && (
            <div className="space-y-6 py-4">
              <div className="border rounded-lg p-6 space-y-6">
                <div className="text-center space-y-2">
                  <h3 className="text-xl font-bold">NetKampus School</h3>
                  <p className="text-muted-foreground">Fee Receipt</p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <p className="text-sm font-medium text-muted-foreground">Receipt No</p>
                    <p>{receiptData.receiptNo}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-medium text-muted-foreground">Date</p>
                    <p>{receiptData.date}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-medium text-muted-foreground">Student Name</p>
                    <p>{receiptData.student.name}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-medium text-muted-foreground">Class & Roll No</p>
                    <p>
                      {receiptData.student.class} • {receiptData.student.rollNo}
                    </p>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <table className="w-full">
                    <thead>
                      <tr className="text-left text-muted-foreground text-sm">
                        <th className="pb-2">Description</th>
                        <th className="text-right pb-2">Amount</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {receiptData.paidItems.map((item, i) => (
                        <tr key={i}>
                          <td className="py-2">{item.type}</td>
                          <td className="text-right py-2">₹{item.amount}</td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr className="font-medium">
                        <td className="pt-4">Total</td>
                        <td className="text-right pt-4">₹{receiptData.totalPaid}</td>
                      </tr>
                    </tfoot>
                  </table>
                </div>

                <div className="border-t pt-4 space-y-2">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-muted-foreground">Payment Method</p>
                      <p className="capitalize">{receiptData.paymentMethod}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-muted-foreground">Transaction ID</p>
                      <p>{receiptData.transactionId}</p>
                    </div>
                  </div>
                </div>

                <div className="border-t pt-4 text-center">
                  <p className="text-sm text-muted-foreground">Thank you for your payment</p>
                </div>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setShowReceipt(false)}>
                  Close
                </Button>
                <Button className="ml-2">
                  <Printer className="h-4 w-4 mr-2" />
                  Print Receipt
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </PageTemplate>
  )
}
