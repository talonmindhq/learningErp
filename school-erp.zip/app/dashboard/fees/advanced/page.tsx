"use client"

import { useState } from "react"
import { PageTemplate } from "@/components/page-template"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Plus, Download, Upload, FileText, Trash2, Edit, Calendar } from "lucide-react"
import { DiscountStatistics } from "@/components/discount-statistics"

export default function AdvancedFeeSettingsPage() {
  const [activeTab, setActiveTab] = useState("discounts")

  // Sample discount types data
  const discountTypes = [
    { id: 1, name: "Merit Scholarship", category: "Academic", amount: "10%", active: true },
    { id: 2, name: "Sports Scholarship", category: "Sports", amount: "15%", active: true },
    { id: 3, name: "Sibling Discount", category: "Family", amount: "5%", active: true },
    { id: 4, name: "Staff Ward Discount", category: "Staff", amount: "25%", active: true },
    { id: 5, name: "Financial Aid", category: "Need-based", amount: "Variable", active: true },
    { id: 6, name: "Early Payment Discount", category: "Payment", amount: "3%", active: true },
    { id: 7, name: "Full Payment Discount", category: "Payment", amount: "5%", active: true },
    { id: 8, name: "Cultural Scholarship", category: "Cultural", amount: "10%", active: false },
  ]

  // Sample payment schedules data
  const paymentSchedules = [
    { id: 1, name: "Monthly Plan", installments: 12, dueDay: 5, lateFeeDays: 5, lateFeeAmount: "₹200", active: true },
    { id: 2, name: "Quarterly Plan", installments: 4, dueDay: 10, lateFeeDays: 7, lateFeeAmount: "₹500", active: true },
    {
      id: 3,
      name: "Half-Yearly Plan",
      installments: 2,
      dueDay: 15,
      lateFeeDays: 10,
      lateFeeAmount: "₹1000",
      active: true,
    },
    { id: 4, name: "Annual Plan", installments: 1, dueDay: 20, lateFeeDays: 15, lateFeeAmount: "₹2000", active: true },
  ]

  // Sample receipt templates data
  const receiptTemplates = [
    {
      id: 1,
      name: "Standard Receipt",
      description: "Default receipt template",
      isDefault: true,
      lastUpdated: "15 Apr 2023",
    },
    {
      id: 2,
      name: "Detailed Receipt",
      description: "Includes breakdown of all fee components",
      isDefault: false,
      lastUpdated: "10 Jun 2023",
    },
    {
      id: 3,
      name: "Compact Receipt",
      description: "Minimalist design for quick printing",
      isDefault: false,
      lastUpdated: "22 Feb 2023",
    },
    {
      id: 4,
      name: "Digital Receipt",
      description: "Optimized for email and digital sharing",
      isDefault: false,
      lastUpdated: "05 Aug 2023",
    },
  ]

  return (
    <PageTemplate
      title="Advanced Fee Settings"
      description="Configure discounts, payment schedules, and receipt templates"
      breadcrumbs={[
        { title: "Dashboard", href: "/dashboard" },
        { title: "Fees", href: "/dashboard/fees" },
        { title: "Advanced Settings", href: "/dashboard/fees/advanced", isCurrentPage: true },
      ]}
      actionButton={{
        label: "Save Changes",
        onClick: () => alert("Changes saved successfully!"),
      }}
    >
      <Tabs defaultValue="discounts" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="discounts">Discounts</TabsTrigger>
          <TabsTrigger value="payment-schedules">Payment Schedules</TabsTrigger>
          <TabsTrigger value="receipt-templates">Receipt Templates</TabsTrigger>
        </TabsList>

        {/* Discounts Tab */}
        <TabsContent value="discounts" className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-medium">Fee Discounts & Scholarships</h3>
              <p className="text-sm text-muted-foreground">Manage all types of fee discounts and scholarships</p>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <Upload className="mr-2 h-4 w-4" />
                Import
              </Button>
              <Button variant="outline" size="sm">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
              <Button size="sm">
                <Plus className="mr-2 h-4 w-4" />
                Add Discount
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Discounts</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">₹12,45,000</div>
                <p className="text-xs text-muted-foreground">Across all categories</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Students Benefited</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">342</div>
                <p className="text-xs text-muted-foreground">27% of total students</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Average Discount</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">₹3,640</div>
                <p className="text-xs text-muted-foreground">Per student</p>
              </CardContent>
            </Card>
          </div>

          <DiscountStatistics />

          <Card>
            <CardHeader>
              <CardTitle>Discount Types</CardTitle>
              <CardDescription>Configure and manage different types of discounts and scholarships</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {discountTypes.map((discount) => (
                      <TableRow key={discount.id}>
                        <TableCell className="font-medium">{discount.name}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{discount.category}</Badge>
                        </TableCell>
                        <TableCell>{discount.amount}</TableCell>
                        <TableCell>
                          {discount.active ? (
                            <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Active</Badge>
                          ) : (
                            <Badge variant="outline" className="text-muted-foreground">
                              Inactive
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button variant="ghost" size="icon">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Create New Discount</CardTitle>
              <CardDescription>Add a new discount or scholarship type</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="discount-name">Discount Name</Label>
                    <Input id="discount-name" placeholder="e.g., Merit Scholarship" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="discount-category">Category</Label>
                    <Select>
                      <SelectTrigger id="discount-category">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="academic">Academic</SelectItem>
                        <SelectItem value="sports">Sports</SelectItem>
                        <SelectItem value="cultural">Cultural</SelectItem>
                        <SelectItem value="family">Family</SelectItem>
                        <SelectItem value="staff">Staff</SelectItem>
                        <SelectItem value="need-based">Need-based</SelectItem>
                        <SelectItem value="payment">Payment</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="discount-type">Discount Type</Label>
                    <Select>
                      <SelectTrigger id="discount-type">
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="percentage">Percentage</SelectItem>
                        <SelectItem value="fixed">Fixed Amount</SelectItem>
                        <SelectItem value="variable">Variable</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="discount-amount">Amount/Percentage</Label>
                    <Input id="discount-amount" placeholder="e.g., 10 or 5000" />
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="applicable-to">Applicable To</Label>
                    <Select>
                      <SelectTrigger id="applicable-to">
                        <SelectValue placeholder="Select applicability" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Students</SelectItem>
                        <SelectItem value="new">New Admissions Only</SelectItem>
                        <SelectItem value="existing">Existing Students Only</SelectItem>
                        <SelectItem value="specific-classes">Specific Classes</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Validity Period</Label>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="flex items-center space-x-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <Input type="date" placeholder="Start Date" />
                      </div>
                      <div className="flex items-center space-x-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <Input type="date" placeholder="End Date" />
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="discount-description">Description</Label>
                    <Input id="discount-description" placeholder="Brief description of the discount" />
                  </div>
                  <div className="flex items-center space-x-2 pt-4">
                    <Checkbox id="notify-parents" />
                    <Label htmlFor="notify-parents" className="text-sm font-normal">
                      Notify parents when this discount is applied
                    </Label>
                  </div>
                </div>
              </div>
              <div className="flex justify-end mt-6">
                <Button variant="outline" className="mr-2">
                  Cancel
                </Button>
                <Button>Create Discount</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Payment Schedules Tab */}
        <TabsContent value="payment-schedules" className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-medium">Payment Schedules</h3>
              <p className="text-sm text-muted-foreground">Configure payment plans and installment schedules</p>
            </div>
            <Button size="sm">
              <Plus className="mr-2 h-4 w-4" />
              Add Schedule
            </Button>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Payment Plans</CardTitle>
              <CardDescription>Configure different payment plans for fee collection</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Plan Name</TableHead>
                      <TableHead>Installments</TableHead>
                      <TableHead>Due Day</TableHead>
                      <TableHead>Late Fee</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paymentSchedules.map((schedule) => (
                      <TableRow key={schedule.id}>
                        <TableCell className="font-medium">{schedule.name}</TableCell>
                        <TableCell>{schedule.installments}</TableCell>
                        <TableCell>{schedule.dueDay}th of month</TableCell>
                        <TableCell>
                          {schedule.lateFeeAmount} after {schedule.lateFeeDays} days
                        </TableCell>
                        <TableCell>
                          {schedule.active ? (
                            <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Active</Badge>
                          ) : (
                            <Badge variant="outline" className="text-muted-foreground">
                              Inactive
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button variant="ghost" size="icon">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Create Payment Schedule</CardTitle>
              <CardDescription>Define a new payment plan</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="plan-name">Plan Name</Label>
                    <Input id="plan-name" placeholder="e.g., Quarterly Plan" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="installments">Number of Installments</Label>
                    <Input id="installments" type="number" min="1" placeholder="e.g., 4" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="due-day">Due Day of Month</Label>
                    <Input id="due-day" type="number" min="1" max="31" placeholder="e.g., 10" />
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="late-fee-days">Grace Period (Days)</Label>
                    <Input id="late-fee-days" type="number" min="0" placeholder="e.g., 5" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="late-fee-amount">Late Fee Amount</Label>
                    <Input id="late-fee-amount" placeholder="e.g., 500" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="applicable-classes">Applicable Classes</Label>
                    <Select>
                      <SelectTrigger id="applicable-classes">
                        <SelectValue placeholder="Select classes" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Classes</SelectItem>
                        <SelectItem value="primary">Primary (1-5)</SelectItem>
                        <SelectItem value="middle">Middle (6-8)</SelectItem>
                        <SelectItem value="secondary">Secondary (9-10)</SelectItem>
                        <SelectItem value="higher">Higher Secondary (11-12)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2 mt-4">
                <Checkbox id="notify-schedule" />
                <Label htmlFor="notify-schedule" className="text-sm font-normal">
                  Send reminders to parents before due date
                </Label>
              </div>
              <div className="flex justify-end mt-6">
                <Button variant="outline" className="mr-2">
                  Cancel
                </Button>
                <Button>Create Schedule</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Receipt Templates Tab */}
        <TabsContent value="receipt-templates" className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-medium">Receipt Templates</h3>
              <p className="text-sm text-muted-foreground">Manage and customize fee receipt templates</p>
            </div>
            <Button size="sm">
              <Plus className="mr-2 h-4 w-4" />
              New Template
            </Button>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Available Templates</CardTitle>
              <CardDescription>Select and manage receipt templates</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Template Name</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Last Updated</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {receiptTemplates.map((template) => (
                      <TableRow key={template.id}>
                        <TableCell className="font-medium">{template.name}</TableCell>
                        <TableCell>{template.description}</TableCell>
                        <TableCell>{template.lastUpdated}</TableCell>
                        <TableCell>
                          {template.isDefault ? (
                            <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Default</Badge>
                          ) : (
                            <Badge variant="outline">Available</Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button variant="ghost" size="sm">
                              <FileText className="mr-2 h-4 w-4" />
                              Preview
                            </Button>
                            <Button variant="ghost" size="icon">
                              <Edit className="h-4 w-4" />
                            </Button>
                            {!template.isDefault && (
                              <Button variant="ghost" size="icon">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Receipt Settings</CardTitle>
              <CardDescription>Configure global settings for all receipts</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="receipt-prefix">Receipt Number Prefix</Label>
                    <Input id="receipt-prefix" placeholder="e.g., FEE-" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="receipt-digits">Receipt Number Digits</Label>
                    <Select defaultValue="6">
                      <SelectTrigger id="receipt-digits">
                        <SelectValue placeholder="Select number of digits" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="4">4 digits</SelectItem>
                        <SelectItem value="5">5 digits</SelectItem>
                        <SelectItem value="6">6 digits</SelectItem>
                        <SelectItem value="7">7 digits</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="receipt-footer">Receipt Footer Text</Label>
                    <Input id="receipt-footer" placeholder="e.g., Thank you for your payment" />
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="receipt-logo">School Logo on Receipt</Label>
                    <Select defaultValue="yes">
                      <SelectTrigger id="receipt-logo">
                        <SelectValue placeholder="Include logo?" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="yes">Yes</SelectItem>
                        <SelectItem value="no">No</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="receipt-signature">Digital Signature</Label>
                    <Select defaultValue="yes">
                      <SelectTrigger id="receipt-signature">
                        <SelectValue placeholder="Include signature?" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="yes">Yes</SelectItem>
                        <SelectItem value="no">No</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="receipt-copies">Default Copies</Label>
                    <Select defaultValue="2">
                      <SelectTrigger id="receipt-copies">
                        <SelectValue placeholder="Number of copies" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 copy</SelectItem>
                        <SelectItem value="2">2 copies</SelectItem>
                        <SelectItem value="3">3 copies</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2 mt-4">
                <Checkbox id="auto-email" />
                <Label htmlFor="auto-email" className="text-sm font-normal">
                  Automatically email receipt to parent
                </Label>
              </div>
              <div className="flex items-center space-x-2 mt-2">
                <Checkbox id="sms-notification" />
                <Label htmlFor="sms-notification" className="text-sm font-normal">
                  Send SMS notification with payment confirmation
                </Label>
              </div>
              <div className="flex justify-end mt-6">
                <Button>Save Settings</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </PageTemplate>
  )
}
