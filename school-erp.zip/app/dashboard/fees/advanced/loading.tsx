import { Skeleton } from "@/components/ui/skeleton"
import { PageTemplate } from "@/components/page-template"

export default function Loading() {
  return (
    <PageTemplate
      title="Advanced Fee Settings"
      subtitle="Configure discounts, payment schedules, and receipt templates"
      isLoading={true}
    >
      <div className="space-y-4">
        <div className="flex space-x-4 overflow-auto pb-2">
          {Array(3)
            .fill(null)
            .map((_, i) => (
              <Skeleton key={i} className="h-10 w-32 rounded-md" />
            ))}
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Skeleton className="h-8 w-40" />
            <Skeleton className="h-10 w-32" />
          </div>

          <Skeleton className="h-[400px] w-full rounded-md" />

          <div className="grid gap-4 md:grid-cols-2">
            <Skeleton className="h-[300px] rounded-md" />
            <Skeleton className="h-[300px] rounded-md" />
          </div>
        </div>
      </div>
    </PageTemplate>
  )
}
