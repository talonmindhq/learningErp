import { Skeleton } from "@/components/ui/skeleton"
import { PageTemplate } from "@/components/page-template"

export default function Loading() {
  return (
    <PageTemplate title="Fee Management" subtitle="Manage fee structure, collection, and reports" isLoading={true}>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {Array(4)
          .fill(null)
          .map((_, i) => (
            <div key={i} className="rounded-lg border bg-card p-6">
              <Skeleton className="h-6 w-1/2 mb-4" />
              <Skeleton className="h-4 w-3/4 mb-2" />
              <Skeleton className="h-4 w-full mb-4" />
              <Skeleton className="h-8 w-24" />
            </div>
          ))}
      </div>
    </PageTemplate>
  )
}
