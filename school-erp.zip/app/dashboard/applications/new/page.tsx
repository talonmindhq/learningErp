"use client"

import type React from "react"

import { useState } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { CalendarIcon, Save, ArrowLeft, Check, Upload } from "lucide-react"
import { Calendar } from "@/components/ui/calendar"
import { format } from "date-fns"
import Link from "next/link"
import { useToast } from "@/components/ui/use-toast"
import { useRouter } from "next/navigation"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

export default function NewApplicationPage() {
  const [date, setDate] = useState<Date>(new Date())
  const [activeTab, setActiveTab] = useState("personal")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const { toast } = useToast()
  const router = useRouter()

  const [formData, setFormData] = useState({
    // Personal Details
    firstName: "",
    lastName: "",
    gender: "",
    dob: new Date(),
    bloodGroup: "",
    nationality: "Indian",
    religion: "",
    category: "",

    // Parent Details
    fatherName: "",
    fatherOccupation: "",
    fatherPhone: "",
    fatherEmail: "",
    motherName: "",
    motherOccupation: "",
    motherPhone: "",
    motherEmail: "",

    // Contact Details
    address: "",
    city: "",
    state: "",
    pincode: "",
    phone: "",
    email: "",

    // Academic Details
    applyingForClass: "",
    previousSchool: "",
    previousClass: "",
    previousPercentage: "",
    reasonForLeaving: "",

    // Documents
    birthCertificate: null,
    transferCertificate: null,
    reportCard: null,
    addressProof: null,
    photographs: null,

    // Additional Information
    healthIssues: "",
    specialNeeds: "",
    hobbies: "",
    remarks: "",
  })

  const [errors, setErrors] = useState<Record<string, string>>({})

  const handleChange = (field: string, value: any) => {
    setFormData({
      ...formData,
      [field]: value,
    })
    // Clear error for this field if it exists
    if (errors[field]) {
      setErrors({
        ...errors,
        [field]: "",
      })
    }
  }

  const validateTab = (tab: string) => {
    const newErrors: Record<string, string> = {}

    if (tab === "personal") {
      if (!formData.firstName.trim()) newErrors.firstName = "First name is required"
      if (!formData.lastName.trim()) newErrors.lastName = "Last name is required"
      if (!formData.gender) newErrors.gender = "Gender is required"
      if (!formData.dob) newErrors.dob = "Date of birth is required"
    } else if (tab === "parent") {
      if (!formData.fatherName.trim()) newErrors.fatherName = "Father's name is required"
      if (!formData.fatherPhone.trim()) newErrors.fatherPhone = "Father's phone is required"
      if (!formData.motherName.trim()) newErrors.motherName = "Mother's name is required"
    } else if (tab === "contact") {
      if (!formData.address.trim()) newErrors.address = "Address is required"
      if (!formData.city.trim()) newErrors.city = "City is required"
      if (!formData.state.trim()) newErrors.state = "State is required"
      if (!formData.pincode.trim()) newErrors.pincode = "PIN code is required"
      if (!formData.phone.trim()) newErrors.phone = "Phone number is required"
    } else if (tab === "academic") {
      if (!formData.applyingForClass) newErrors.applyingForClass = "Class is required"
      if (!formData.previousSchool.trim()) newErrors.previousSchool = "Previous school is required"
      if (!formData.previousClass.trim()) newErrors.previousClass = "Previous class is required"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleTabChange = (tab: string) => {
    if (validateTab(activeTab)) {
      setActiveTab(tab)
    } else {
      toast({
        title: "Validation Error",
        description: "Please fill all required fields before proceeding",
        variant: "destructive",
      })
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateTab(activeTab)) {
      toast({
        title: "Validation Error",
        description: "Please check the form for errors",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Show success message
      setIsSuccess(true)
      toast({
        title: "Application Submitted",
        description: "The application has been submitted successfully",
      })

      // Reset form after 2 seconds and redirect
      setTimeout(() => {
        router.push("/dashboard/applications")
      }, 2000)
    } catch (error) {
      toast({
        title: "Error",
        description: "There was an error submitting the application. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <PageTemplate
      title="New Application"
      description="Create a new student admission application"
      breadcrumbs={[
        { title: "Enquiry & Admission", href: "/dashboard/applications" },
        { title: "Applications", href: "/dashboard/applications" },
        { title: "New Application", href: "/dashboard/applications/new", isCurrentPage: true },
      ]}
    >
      <Card>
        <CardHeader>
          <CardTitle>Application Form</CardTitle>
          <CardDescription>Fill in the details for the new admission application</CardDescription>
        </CardHeader>
        <CardContent>
          {isSuccess ? (
            <Alert className="bg-green-50 border-green-200">
              <Check className="h-4 w-4 text-green-600" />
              <AlertTitle>Success!</AlertTitle>
              <AlertDescription>
                Application has been submitted successfully. Redirecting to applications list...
              </AlertDescription>
            </Alert>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-5">
                  <TabsTrigger value="personal">Personal</TabsTrigger>
                  <TabsTrigger value="parent">Parent</TabsTrigger>
                  <TabsTrigger value="contact">Contact</TabsTrigger>
                  <TabsTrigger value="academic">Academic</TabsTrigger>
                  <TabsTrigger value="documents">Documents</TabsTrigger>
                </TabsList>

                {/* Personal Details Tab */}
                <TabsContent value="personal" className="space-y-4 pt-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="firstName">
                        First Name <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="firstName"
                        placeholder="Enter first name"
                        value={formData.firstName}
                        onChange={(e) => handleChange("firstName", e.target.value)}
                        className={errors.firstName ? "border-red-500" : ""}
                      />
                      {errors.firstName && <p className="text-red-500 text-xs mt-1">{errors.firstName}</p>}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastName">
                        Last Name <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="lastName"
                        placeholder="Enter last name"
                        value={formData.lastName}
                        onChange={(e) => handleChange("lastName", e.target.value)}
                        className={errors.lastName ? "border-red-500" : ""}
                      />
                      {errors.lastName && <p className="text-red-500 text-xs mt-1">{errors.lastName}</p>}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="gender">
                      Gender <span className="text-red-500">*</span>
                    </Label>
                    <RadioGroup
                      value={formData.gender}
                      onValueChange={(value) => handleChange("gender", value)}
                      className="flex space-x-4"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="male" id="male" />
                        <Label htmlFor="male">Male</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="female" id="female" />
                        <Label htmlFor="female">Female</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="other" id="other" />
                        <Label htmlFor="other">Other</Label>
                      </div>
                    </RadioGroup>
                    {errors.gender && <p className="text-red-500 text-xs mt-1">{errors.gender}</p>}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>
                        Date of Birth <span className="text-red-500">*</span>
                      </Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant={"outline"}
                            className={`w-full justify-start text-left font-normal ${errors.dob ? "border-red-500" : ""}`}
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {formData.dob ? format(formData.dob, "PPP") : "Select date"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={formData.dob}
                            onSelect={(date) => date && handleChange("dob", date)}
                            initialFocus
                            disabled={(date) => date > new Date()}
                          />
                        </PopoverContent>
                      </Popover>
                      {errors.dob && <p className="text-red-500 text-xs mt-1">{errors.dob}</p>}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="bloodGroup">Blood Group</Label>
                      <Select value={formData.bloodGroup} onValueChange={(value) => handleChange("bloodGroup", value)}>
                        <SelectTrigger id="bloodGroup">
                          <SelectValue placeholder="Select blood group" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="A+">A+</SelectItem>
                          <SelectItem value="A-">A-</SelectItem>
                          <SelectItem value="B+">B+</SelectItem>
                          <SelectItem value="B-">B-</SelectItem>
                          <SelectItem value="AB+">AB+</SelectItem>
                          <SelectItem value="AB-">AB-</SelectItem>
                          <SelectItem value="O+">O+</SelectItem>
                          <SelectItem value="O-">O-</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="nationality">Nationality</Label>
                      <Input
                        id="nationality"
                        value={formData.nationality}
                        onChange={(e) => handleChange("nationality", e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="religion">Religion</Label>
                      <Input
                        id="religion"
                        value={formData.religion}
                        onChange={(e) => handleChange("religion", e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="category">Category</Label>
                      <Select value={formData.category} onValueChange={(value) => handleChange("category", value)}>
                        <SelectTrigger id="category">
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="General">General</SelectItem>
                          <SelectItem value="OBC">OBC</SelectItem>
                          <SelectItem value="SC">SC</SelectItem>
                          <SelectItem value="ST">ST</SelectItem>
                          <SelectItem value="EWS">EWS</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <Button
                      type="button"
                      onClick={() => handleTabChange("parent")}
                      className="bg-theme-500 hover:bg-theme-600"
                    >
                      Next: Parent Details
                    </Button>
                  </div>
                </TabsContent>

                {/* Parent Details Tab */}
                <TabsContent value="parent" className="space-y-4 pt-4">
                  <h3 className="text-lg font-medium">Father's Details</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="fatherName">
                        Father's Name <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="fatherName"
                        placeholder="Enter father's name"
                        value={formData.fatherName}
                        onChange={(e) => handleChange("fatherName", e.target.value)}
                        className={errors.fatherName ? "border-red-500" : ""}
                      />
                      {errors.fatherName && <p className="text-red-500 text-xs mt-1">{errors.fatherName}</p>}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="fatherOccupation">Occupation</Label>
                      <Input
                        id="fatherOccupation"
                        placeholder="Enter father's occupation"
                        value={formData.fatherOccupation}
                        onChange={(e) => handleChange("fatherOccupation", e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="fatherPhone">
                        Phone Number <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="fatherPhone"
                        placeholder="Enter father's phone number"
                        value={formData.fatherPhone}
                        onChange={(e) => handleChange("fatherPhone", e.target.value)}
                        className={errors.fatherPhone ? "border-red-500" : ""}
                      />
                      {errors.fatherPhone && <p className="text-red-500 text-xs mt-1">{errors.fatherPhone}</p>}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="fatherEmail">Email Address</Label>
                      <Input
                        id="fatherEmail"
                        type="email"
                        placeholder="Enter father's email"
                        value={formData.fatherEmail}
                        onChange={(e) => handleChange("fatherEmail", e.target.value)}
                      />
                    </div>
                  </div>

                  <h3 className="text-lg font-medium mt-6">Mother's Details</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="motherName">
                        Mother's Name <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="motherName"
                        placeholder="Enter mother's name"
                        value={formData.motherName}
                        onChange={(e) => handleChange("motherName", e.target.value)}
                        className={errors.motherName ? "border-red-500" : ""}
                      />
                      {errors.motherName && <p className="text-red-500 text-xs mt-1">{errors.motherName}</p>}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="motherOccupation">Occupation</Label>
                      <Input
                        id="motherOccupation"
                        placeholder="Enter mother's occupation"
                        value={formData.motherOccupation}
                        onChange={(e) => handleChange("motherOccupation", e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="motherPhone">Phone Number</Label>
                      <Input
                        id="motherPhone"
                        placeholder="Enter mother's phone number"
                        value={formData.motherPhone}
                        onChange={(e) => handleChange("motherPhone", e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="motherEmail">Email Address</Label>
                      <Input
                        id="motherEmail"
                        type="email"
                        placeholder="Enter mother's email"
                        value={formData.motherEmail}
                        onChange={(e) => handleChange("motherEmail", e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="flex justify-between">
                    <Button type="button" variant="outline" onClick={() => handleTabChange("personal")}>
                      Previous: Personal Details
                    </Button>
                    <Button
                      type="button"
                      onClick={() => handleTabChange("contact")}
                      className="bg-theme-500 hover:bg-theme-600"
                    >
                      Next: Contact Details
                    </Button>
                  </div>
                </TabsContent>

                {/* Contact Details Tab */}
                <TabsContent value="contact" className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <Label htmlFor="address">
                      Address <span className="text-red-500">*</span>
                    </Label>
                    <Textarea
                      id="address"
                      placeholder="Enter complete address"
                      value={formData.address}
                      onChange={(e) => handleChange("address", e.target.value)}
                      className={errors.address ? "border-red-500" : ""}
                    />
                    {errors.address && <p className="text-red-500 text-xs mt-1">{errors.address}</p>}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="city">
                        City <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="city"
                        placeholder="Enter city"
                        value={formData.city}
                        onChange={(e) => handleChange("city", e.target.value)}
                        className={errors.city ? "border-red-500" : ""}
                      />
                      {errors.city && <p className="text-red-500 text-xs mt-1">{errors.city}</p>}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="state">
                        State <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="state"
                        placeholder="Enter state"
                        value={formData.state}
                        onChange={(e) => handleChange("state", e.target.value)}
                        className={errors.state ? "border-red-500" : ""}
                      />
                      {errors.state && <p className="text-red-500 text-xs mt-1">{errors.state}</p>}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="pincode">
                        PIN Code <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="pincode"
                        placeholder="Enter PIN code"
                        value={formData.pincode}
                        onChange={(e) => handleChange("pincode", e.target.value)}
                        className={errors.pincode ? "border-red-500" : ""}
                      />
                      {errors.pincode && <p className="text-red-500 text-xs mt-1">{errors.pincode}</p>}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="phone">
                        Contact Phone <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="phone"
                        placeholder="Enter contact phone number"
                        value={formData.phone}
                        onChange={(e) => handleChange("phone", e.target.value)}
                        className={errors.phone ? "border-red-500" : ""}
                      />
                      {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone}</p>}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Contact Email</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="Enter contact email"
                        value={formData.email}
                        onChange={(e) => handleChange("email", e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="flex justify-between">
                    <Button type="button" variant="outline" onClick={() => handleTabChange("parent")}>
                      Previous: Parent Details
                    </Button>
                    <Button
                      type="button"
                      onClick={() => handleTabChange("academic")}
                      className="bg-theme-500 hover:bg-theme-600"
                    >
                      Next: Academic Details
                    </Button>
                  </div>
                </TabsContent>

                {/* Academic Details Tab */}
                <TabsContent value="academic" className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <Label htmlFor="applyingForClass">
                      Applying for Class <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={formData.applyingForClass}
                      onValueChange={(value) => handleChange("applyingForClass", value)}
                    >
                      <SelectTrigger id="applyingForClass" className={errors.applyingForClass ? "border-red-500" : ""}>
                        <SelectValue placeholder="Select class" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Class I">Class I</SelectItem>
                        <SelectItem value="Class II">Class II</SelectItem>
                        <SelectItem value="Class III">Class III</SelectItem>
                        <SelectItem value="Class IV">Class IV</SelectItem>
                        <SelectItem value="Class V">Class V</SelectItem>
                        <SelectItem value="Class VI">Class VI</SelectItem>
                        <SelectItem value="Class VII">Class VII</SelectItem>
                        <SelectItem value="Class VIII">Class VIII</SelectItem>
                        <SelectItem value="Class IX">Class IX</SelectItem>
                        <SelectItem value="Class X">Class X</SelectItem>
                        <SelectItem value="Class XI">Class XI</SelectItem>
                        <SelectItem value="Class XII">Class XII</SelectItem>
                      </SelectContent>
                    </Select>
                    {errors.applyingForClass && <p className="text-red-500 text-xs mt-1">{errors.applyingForClass}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="previousSchool">
                      Previous School <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="previousSchool"
                      placeholder="Enter previous school name"
                      value={formData.previousSchool}
                      onChange={(e) => handleChange("previousSchool", e.target.value)}
                      className={errors.previousSchool ? "border-red-500" : ""}
                    />
                    {errors.previousSchool && <p className="text-red-500 text-xs mt-1">{errors.previousSchool}</p>}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="previousClass">
                        Previous Class <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="previousClass"
                        placeholder="Enter previous class"
                        value={formData.previousClass}
                        onChange={(e) => handleChange("previousClass", e.target.value)}
                        className={errors.previousClass ? "border-red-500" : ""}
                      />
                      {errors.previousClass && <p className="text-red-500 text-xs mt-1">{errors.previousClass}</p>}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="previousPercentage">Previous Percentage/Grade</Label>
                      <Input
                        id="previousPercentage"
                        placeholder="Enter percentage or grade"
                        value={formData.previousPercentage}
                        onChange={(e) => handleChange("previousPercentage", e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="reasonForLeaving">Reason for Leaving Previous School</Label>
                    <Textarea
                      id="reasonForLeaving"
                      placeholder="Enter reason for leaving previous school"
                      value={formData.reasonForLeaving}
                      onChange={(e) => handleChange("reasonForLeaving", e.target.value)}
                    />
                  </div>

                  <div className="flex justify-between">
                    <Button type="button" variant="outline" onClick={() => handleTabChange("contact")}>
                      Previous: Contact Details
                    </Button>
                    <Button
                      type="button"
                      onClick={() => handleTabChange("documents")}
                      className="bg-theme-500 hover:bg-theme-600"
                    >
                      Next: Documents
                    </Button>
                  </div>
                </TabsContent>

                {/* Documents Tab */}
                <TabsContent value="documents" className="space-y-4 pt-4">
                  <div className="space-y-4">
                    <div className="border rounded-md p-4">
                      <Label htmlFor="birthCertificate" className="block mb-2">
                        Birth Certificate
                      </Label>
                      <div className="flex items-center gap-2">
                        <Button type="button" variant="outline" className="w-full">
                          <Upload className="mr-2 h-4 w-4" />
                          Upload Birth Certificate
                        </Button>
                        <span className="text-sm text-muted-foreground">No file chosen</span>
                      </div>
                    </div>

                    <div className="border rounded-md p-4">
                      <Label htmlFor="transferCertificate" className="block mb-2">
                        Transfer Certificate
                      </Label>
                      <div className="flex items-center gap-2">
                        <Button type="button" variant="outline" className="w-full">
                          <Upload className="mr-2 h-4 w-4" />
                          Upload Transfer Certificate
                        </Button>
                        <span className="text-sm text-muted-foreground">No file chosen</span>
                      </div>
                    </div>

                    <div className="border rounded-md p-4">
                      <Label htmlFor="reportCard" className="block mb-2">
                        Report Card
                      </Label>
                      <div className="flex items-center gap-2">
                        <Button type="button" variant="outline" className="w-full">
                          <Upload className="mr-2 h-4 w-4" />
                          Upload Report Card
                        </Button>
                        <span className="text-sm text-muted-foreground">No file chosen</span>
                      </div>
                    </div>

                    <div className="border rounded-md p-4">
                      <Label htmlFor="addressProof" className="block mb-2">
                        Address Proof
                      </Label>
                      <div className="flex items-center gap-2">
                        <Button type="button" variant="outline" className="w-full">
                          <Upload className="mr-2 h-4 w-4" />
                          Upload Address Proof
                        </Button>
                        <span className="text-sm text-muted-foreground">No file chosen</span>
                      </div>
                    </div>

                    <div className="border rounded-md p-4">
                      <Label htmlFor="photographs" className="block mb-2">
                        Passport Size Photographs
                      </Label>
                      <div className="flex items-center gap-2">
                        <Button type="button" variant="outline" className="w-full">
                          <Upload className="mr-2 h-4 w-4" />
                          Upload Photographs
                        </Button>
                        <span className="text-sm text-muted-foreground">No file chosen</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="remarks">Additional Remarks</Label>
                    <Textarea
                      id="remarks"
                      placeholder="Any additional information or special requests"
                      value={formData.remarks}
                      onChange={(e) => handleChange("remarks", e.target.value)}
                    />
                  </div>

                  <div className="flex justify-between">
                    <Button type="button" variant="outline" onClick={() => handleTabChange("academic")}>
                      Previous: Academic Details
                    </Button>
                    <Button type="submit" className="bg-theme-500 hover:bg-theme-600" disabled={isSubmitting}>
                      {isSubmitting ? (
                        <>
                          <svg
                            className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 24 24"
                          >
                            <circle
                              className="opacity-25"
                              cx="12"
                              cy="12"
                              r="10"
                              stroke="currentColor"
                              strokeWidth="4"
                            ></circle>
                            <path
                              className="opacity-75"
                              fill="currentColor"
                              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                            ></path>
                          </svg>
                          Submitting...
                        </>
                      ) : (
                        <>
                          <Save className="mr-2 h-4 w-4" />
                          Submit Application
                        </>
                      )}
                    </Button>
                  </div>
                </TabsContent>
              </Tabs>
            </form>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" asChild>
            <Link href="/dashboard/applications">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Applications
            </Link>
          </Button>
        </CardFooter>
      </Card>
    </PageTemplate>
  )
}
