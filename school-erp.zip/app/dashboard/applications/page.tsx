"use client"

import { useState } from "react"
import { PageTemplate } from "@/components/page-template"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Plus, Eye, Download, MoreHorizontal, FileText, CheckCircle, XCircle } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useToast } from "@/components/ui/use-toast"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"

export default function ApplicationsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [selectedApplication, setSelectedApplication] = useState<any>(null)
  const [isPreviewDialogOpen, setIsPreviewDialogOpen] = useState(false)
  const [isApproveDialogOpen, setIsApproveDialogOpen] = useState(false)
  const [isRejectDialogOpen, setIsRejectDialogOpen] = useState(false)
  const [approvalNotes, setApprovalNotes] = useState("")
  const [rejectionReason, setRejectionReason] = useState("")
  const { toast } = useToast()

  // Sample data
  const [applications, setApplications] = useState([
    {
      id: "APP001",
      name: "Rahul Sharma",
      class: "Class X",
      appliedDate: "2023-05-15",
      status: "pending",
      documents: 5,
      parentName: "Rajesh Sharma",
      parentPhone: "+91 9876543211",
      parentEmail: "rajesh.s@example.com",
      address: "123, Green Park, New Delhi",
      previousSchool: "Delhi Public School",
      academicRecords: [
        { subject: "Mathematics", marks: "92%", grade: "A" },
        { subject: "Science", marks: "88%", grade: "A" },
        { subject: "English", marks: "85%", grade: "B+" },
        { subject: "Social Studies", marks: "90%", grade: "A" },
      ],
      documents: [
        { name: "Birth Certificate", status: "verified" },
        { name: "Previous School TC", status: "verified" },
        { name: "Report Card", status: "verified" },
        { name: "Address Proof", status: "verified" },
        { name: "Passport Photos", status: "verified" },
      ],
    },
    {
      id: "APP002",
      name: "Priya Patel",
      class: "Class VIII",
      appliedDate: "2023-05-14",
      status: "under_review",
      documents: 4,
      parentName: "Suresh Patel",
      parentPhone: "+91 8765432109",
      parentEmail: "suresh.p@example.com",
      address: "45, Patel Nagar, Mumbai",
      previousSchool: "St. Mary's School",
      academicRecords: [
        { subject: "Mathematics", marks: "85%", grade: "B+" },
        { subject: "Science", marks: "90%", grade: "A" },
        { subject: "English", marks: "88%", grade: "A" },
        { subject: "Social Studies", marks: "82%", grade: "B" },
      ],
      documents: [
        { name: "Birth Certificate", status: "verified" },
        { name: "Previous School TC", status: "pending" },
        { name: "Report Card", status: "verified" },
        { name: "Address Proof", status: "verified" },
        { name: "Passport Photos", status: "verified" },
      ],
    },
    {
      id: "APP003",
      name: "Amit Kumar",
      class: "Class VI",
      appliedDate: "2023-05-12",
      status: "approved",
      documents: 5,
      parentName: "Vijay Kumar",
      parentPhone: "+91 7654321098",
      parentEmail: "vijay.k@example.com",
      address: "78, Model Town, Delhi",
      previousSchool: "Ryan International School",
      academicRecords: [
        { subject: "Mathematics", marks: "95%", grade: "A+" },
        { subject: "Science", marks: "92%", grade: "A" },
        { subject: "English", marks: "88%", grade: "A" },
        { subject: "Social Studies", marks: "90%", grade: "A" },
      ],
      documents: [
        { name: "Birth Certificate", status: "verified" },
        { name: "Previous School TC", status: "verified" },
        { name: "Report Card", status: "verified" },
        { name: "Address Proof", status: "verified" },
        { name: "Passport Photos", status: "verified" },
      ],
      approvalNotes: "Excellent academic record. Approved for immediate admission.",
    },
    {
      id: "APP004",
      name: "Sneha Gupta",
      class: "Class XI",
      appliedDate: "2023-05-10",
      status: "rejected",
      documents: 3,
      parentName: "Rakesh Gupta",
      parentPhone: "+91 6543210987",
      parentEmail: "rakesh.g@example.com",
      address: "34, Civil Lines, Jaipur",
      previousSchool: "Kendriya Vidyalaya",
      academicRecords: [
        { subject: "Mathematics", marks: "75%", grade: "B" },
        { subject: "Science", marks: "70%", grade: "B" },
        { subject: "English", marks: "65%", grade: "C+" },
        { subject: "Social Studies", marks: "72%", grade: "B" },
      ],
      documents: [
        { name: "Birth Certificate", status: "verified" },
        { name: "Previous School TC", status: "missing" },
        { name: "Report Card", status: "verified" },
        { name: "Address Proof", status: "missing" },
        { name: "Passport Photos", status: "verified" },
      ],
      rejectionReason: "Missing required documents and below minimum academic requirements.",
    },
    {
      id: "APP005",
      name: "Vikram Singh",
      class: "Class IX",
      appliedDate: "2023-05-08",
      status: "waitlisted",
      documents: 5,
      parentName: "Harpreet Singh",
      parentPhone: "+91 5432109876",
      parentEmail: "harpreet.s@example.com",
      address: "56, Sector 18, Chandigarh",
      previousSchool: "DAV Public School",
      academicRecords: [
        { subject: "Mathematics", marks: "88%", grade: "A" },
        { subject: "Science", marks: "85%", grade: "B+" },
        { subject: "English", marks: "90%", grade: "A" },
        { subject: "Social Studies", marks: "86%", grade: "B+" },
      ],
      documents: [
        { name: "Birth Certificate", status: "verified" },
        { name: "Previous School TC", status: "verified" },
        { name: "Report Card", status: "verified" },
        { name: "Address Proof", status: "verified" },
        { name: "Passport Photos", status: "verified" },
      ],
    },
  ])

  const filteredApplications = applications.filter((application) => {
    const matchesSearch =
      application.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      application.id.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesStatus = statusFilter === "all" || application.status === statusFilter

    return matchesSearch && matchesStatus
  })

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge className="bg-amber-500">Pending</Badge>
      case "under_review":
        return <Badge className="bg-blue-500">Under Review</Badge>
      case "approved":
        return <Badge className="bg-green-500">Approved</Badge>
      case "rejected":
        return <Badge className="bg-red-500">Rejected</Badge>
      case "waitlisted":
        return <Badge className="bg-purple-500">Waitlisted</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  const getDocumentStatusIcon = (status: string) => {
    switch (status) {
      case "verified":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "pending":
        return <Badge className="bg-amber-500 text-xs">Pending</Badge>
      case "missing":
        return <XCircle className="h-4 w-4 text-red-500" />
      default:
        return null
    }
  }

  const handlePreviewApplication = (application: any) => {
    setSelectedApplication(application)
    setIsPreviewDialogOpen(true)
  }

  const handleApproveApplication = (application: any) => {
    setSelectedApplication(application)
    setApprovalNotes("")
    setIsApproveDialogOpen(true)
  }

  const handleRejectApplication = (application: any) => {
    setSelectedApplication(application)
    setRejectionReason("")
    setIsRejectDialogOpen(true)
  }

  const confirmApproval = () => {
    if (selectedApplication) {
      const updatedApplications = applications.map((app) => {
        if (app.id === selectedApplication.id) {
          return {
            ...app,
            status: "approved",
            approvalNotes: approvalNotes,
          }
        }
        return app
      })
      setApplications(updatedApplications)
      setIsApproveDialogOpen(false)
      toast({
        title: "Application Approved",
        description: `${selectedApplication.name}'s application has been approved.`,
      })
    }
  }

  const confirmRejection = () => {
    if (selectedApplication) {
      const updatedApplications = applications.map((app) => {
        if (app.id === selectedApplication.id) {
          return {
            ...app,
            status: "rejected",
            rejectionReason: rejectionReason,
          }
        }
        return app
      })
      setApplications(updatedApplications)
      setIsRejectDialogOpen(false)
      toast({
        title: "Application Rejected",
        description: `${selectedApplication.name}'s application has been rejected.`,
      })
    }
  }

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
  }

  return (
    <PageTemplate
      title="Applications"
      description="Manage student admission applications"
      breadcrumbs={[
        { title: "Enquiry & Admission", href: "/dashboard/applications" },
        { title: "Applications", href: "/dashboard/applications", isCurrentPage: true },
      ]}
      actionButton={{
        label: "New Application",
        icon: <Plus className="mr-2 h-4 w-4" />,
        href: "/dashboard/applications/new",
      }}
    >
      <Card>
        <CardHeader className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
          <CardTitle>All Applications</CardTitle>
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search applications..."
                className="pl-8 w-full sm:w-[250px]"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-[150px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="under_review">Under Review</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
                <SelectItem value="waitlisted">Waitlisted</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Class</TableHead>
                  <TableHead className="hidden md:table-cell">Applied Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="hidden md:table-cell">Documents</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredApplications.map((application) => (
                  <TableRow key={application.id}>
                    <TableCell className="font-medium">{application.id}</TableCell>
                    <TableCell>{application.name}</TableCell>
                    <TableCell>{application.class}</TableCell>
                    <TableCell className="hidden md:table-cell">
                      {new Date(application.appliedDate).toLocaleDateString()}
                    </TableCell>
                    <TableCell>{getStatusBadge(application.status)}</TableCell>
                    <TableCell className="hidden md:table-cell">{application.documents.length}/5</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <DropdownMenuItem onClick={() => handlePreviewApplication(application)}>
                            <Eye className="mr-2 h-4 w-4" />
                            Preview Application
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <FileText className="mr-2 h-4 w-4" />
                            View Documents
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>
                            <Download className="mr-2 h-4 w-4" />
                            Download
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          {application.status !== "approved" && application.status !== "rejected" && (
                            <>
                              <DropdownMenuItem onClick={() => handleApproveApplication(application)}>
                                <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                                Approve
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleRejectApplication(application)}>
                                <XCircle className="mr-2 h-4 w-4 text-red-500" />
                                Reject
                              </DropdownMenuItem>
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Application Preview Dialog */}
      <Dialog open={isPreviewDialogOpen} onOpenChange={setIsPreviewDialogOpen}>
        <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Application Preview</DialogTitle>
            <DialogDescription>Review complete application details</DialogDescription>
          </DialogHeader>
          {selectedApplication && (
            <Tabs defaultValue="personal" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="personal">Personal Details</TabsTrigger>
                <TabsTrigger value="academic">Academic Records</TabsTrigger>
                <TabsTrigger value="documents">Documents</TabsTrigger>
              </TabsList>
              <TabsContent value="personal" className="space-y-4">
                <div className="flex items-center space-x-4 mb-4">
                  <Avatar className="h-16 w-16">
                    <AvatarImage
                      src={`/abstract-geometric-shapes.png?height=64&width=64&query=${selectedApplication.name}`}
                      alt={selectedApplication.name}
                    />
                    <AvatarFallback>{getInitials(selectedApplication.name)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="text-lg font-bold">{selectedApplication.name}</h3>
                    <p className="text-sm text-muted-foreground">Application ID: {selectedApplication.id}</p>
                    <div className="mt-1">{getStatusBadge(selectedApplication.status)}</div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Applied For</h3>
                    <p>{selectedApplication.class}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Application Date</h3>
                    <p>{new Date(selectedApplication.appliedDate).toLocaleDateString()}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Parent/Guardian Name</h3>
                    <p>{selectedApplication.parentName}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Contact Number</h3>
                    <p>{selectedApplication.parentPhone}</p>
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Email Address</h3>
                  <p>{selectedApplication.parentEmail}</p>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Address</h3>
                  <p>{selectedApplication.address}</p>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Previous School</h3>
                  <p>{selectedApplication.previousSchool}</p>
                </div>

                {selectedApplication.status === "approved" && selectedApplication.approvalNotes && (
                  <div className="p-3 bg-green-50 border border-green-200 rounded-md">
                    <h3 className="text-sm font-medium text-green-800">Approval Notes</h3>
                    <p className="text-sm text-green-700">{selectedApplication.approvalNotes}</p>
                  </div>
                )}

                {selectedApplication.status === "rejected" && selectedApplication.rejectionReason && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-md">
                    <h3 className="text-sm font-medium text-red-800">Rejection Reason</h3>
                    <p className="text-sm text-red-700">{selectedApplication.rejectionReason}</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="academic">
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Subject</TableHead>
                        <TableHead>Marks</TableHead>
                        <TableHead>Grade</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {selectedApplication.academicRecords.map((record, index) => (
                        <TableRow key={index}>
                          <TableCell>{record.subject}</TableCell>
                          <TableCell>{record.marks}</TableCell>
                          <TableCell>{record.grade}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>

              <TabsContent value="documents">
                <div className="space-y-4">
                  {selectedApplication.documents.map((doc, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-md">
                      <div className="flex items-center">
                        <FileText className="h-5 w-5 mr-2 text-theme-500" />
                        <span>{doc.name}</span>
                      </div>
                      <div className="flex items-center">
                        {getDocumentStatusIcon(doc.status)}
                        <Button variant="ghost" size="sm" className="ml-2">
                          <Eye className="h-4 w-4 mr-1" />
                          View
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          )}
          <DialogFooter className="flex justify-between">
            <DialogClose asChild>
              <Button variant="outline">Close</Button>
            </DialogClose>
            <div className="flex gap-2">
              <Button variant="outline">
                <Download className="mr-2 h-4 w-4" />
                Download
              </Button>
              {selectedApplication &&
                selectedApplication.status !== "approved" &&
                selectedApplication.status !== "rejected" && (
                  <Button
                    className="bg-theme-500 hover:bg-theme-600"
                    onClick={() => {
                      setIsPreviewDialogOpen(false)
                      handleApproveApplication(selectedApplication)
                    }}
                  >
                    <CheckCircle className="mr-2 h-4 w-4" />
                    Process Application
                  </Button>
                )}
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Approve Application Dialog */}
      <Dialog open={isApproveDialogOpen} onOpenChange={setIsApproveDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Approve Application</DialogTitle>
            <DialogDescription>
              You are about to approve {selectedApplication?.name}'s application for {selectedApplication?.class}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="approval-notes">Approval Notes (Optional)</Label>
              <Textarea
                id="approval-notes"
                placeholder="Add any notes or comments regarding this approval"
                value={approvalNotes}
                onChange={(e) => setApprovalNotes(e.target.value)}
                className="min-h-[100px]"
              />
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">Cancel</Button>
            </DialogClose>
            <Button className="bg-green-600 hover:bg-green-700" onClick={confirmApproval}>
              <CheckCircle className="mr-2 h-4 w-4" />
              Confirm Approval
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reject Application Dialog */}
      <Dialog open={isRejectDialogOpen} onOpenChange={setIsRejectDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Reject Application</DialogTitle>
            <DialogDescription>
              You are about to reject {selectedApplication?.name}'s application for {selectedApplication?.class}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="rejection-reason">
                Rejection Reason <span className="text-red-500">*</span>
              </Label>
              <Textarea
                id="rejection-reason"
                placeholder="Provide a reason for rejecting this application"
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                className="min-h-[100px]"
                required
              />
              {rejectionReason.length === 0 && (
                <p className="text-sm text-red-500">Please provide a reason for rejection</p>
              )}
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">Cancel</Button>
            </DialogClose>
            <Button
              className="bg-red-600 hover:bg-red-700"
              onClick={confirmRejection}
              disabled={rejectionReason.length === 0}
            >
              <XCircle className="mr-2 h-4 w-4" />
              Confirm Rejection
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageTemplate>
  )
}
