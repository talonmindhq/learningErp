import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { z } from "zod"

// Validation schema
const inventoryItemSchema = z.object({
  name: z.string().min(1, "Name is required"),
  description: z.string().optional(),
  quantity: z.number().min(0, "Quantity cannot be negative"),
  category: z.string().optional(),
  location: z.string().optional(),
})

// GET /api/inventory/:id - get a single item
export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = Number.parseInt(params.id, 10)

    if (isNaN(id)) {
      return NextResponse.json({ success: false, error: "Invalid ID" }, { status: 400 })
    }

    const result = await sql.query(
      `
      SELECT * FROM inventory_items 
      WHERE id = $1
    `,
      [id],
    )

    if (result.rows.length === 0) {
      return NextResponse.json({ success: false, error: "Inventory item not found" }, { status: 404 })
    }

    return NextResponse.json({ success: true, data: result.rows[0] })
  } catch (error) {
    console.error("Error fetching inventory item:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch inventory item" }, { status: 500 })
  }
}

// PUT /api/inventory/:id - update an item
export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = Number.parseInt(params.id, 10)

    if (isNaN(id)) {
      return NextResponse.json({ success: false, error: "Invalid ID" }, { status: 400 })
    }

    const body = await request.json()

    // Validate data
    const validatedData = inventoryItemSchema.parse(body)

    // Update in database
    const result = await sql.query(
      `
      UPDATE inventory_items
      SET name = $1, description = $2, quantity = $3, category = $4, location = $5, updated_at = CURRENT_TIMESTAMP
      WHERE id = $6
      RETURNING *
    `,
      [
        validatedData.name,
        validatedData.description || null,
        validatedData.quantity,
        validatedData.category || null,
        validatedData.location || null,
        id,
      ],
    )

    if (result.rows.length === 0) {
      return NextResponse.json({ success: false, error: "Inventory item not found" }, { status: 404 })
    }

    return NextResponse.json({ success: true, data: result.rows[0] })
  } catch (error) {
    console.error("Error updating inventory item:", error)
    if (error instanceof z.ZodError) {
      return NextResponse.json({ success: false, error: error.errors[0].message }, { status: 400 })
    }
    return NextResponse.json({ success: false, error: "Failed to update inventory item" }, { status: 500 })
  }
}

// DELETE /api/inventory/:id - delete an item
export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = Number.parseInt(params.id, 10)

    if (isNaN(id)) {
      return NextResponse.json({ success: false, error: "Invalid ID" }, { status: 400 })
    }

    const result = await sql.query(
      `
      DELETE FROM inventory_items
      WHERE id = $1
      RETURNING id
    `,
      [id],
    )

    if (result.rows.length === 0) {
      return NextResponse.json({ success: false, error: "Inventory item not found" }, { status: 404 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error deleting inventory item:", error)
    return NextResponse.json({ success: false, error: "Failed to delete inventory item" }, { status: 500 })
  }
}
