import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { z } from "zod"

// Validation schema
const inventoryItemSchema = z.object({
  name: z.string().min(1, "Name is required"),
  description: z.string().optional(),
  quantity: z.number().min(0, "Quantity cannot be negative"),
  category: z.string().optional(),
  location: z.string().optional(),
})

// GET /api/inventory - list all items
export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const category = url.searchParams.get("category")
    const location = url.searchParams.get("location")

    let query = `SELECT * FROM inventory_items`
    const params: any[] = []

    if (category || location) {
      query += ` WHERE`

      if (category) {
        query += ` category = $1`
        params.push(category)
      }

      if (location) {
        if (category) {
          query += ` AND`
        }
        query += ` location = $${params.length + 1}`
        params.push(location)
      }
    }

    query += ` ORDER BY name ASC`

    const result = await sql.query(query, params)
    return NextResponse.json({ success: true, data: result.rows })
  } catch (error) {
    console.error("Error fetching inventory items:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch inventory items" }, { status: 500 })
  }
}

// POST /api/inventory - create a new item
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // Validate data
    const validatedData = inventoryItemSchema.parse(body)

    // Insert into database
    const result = await sql.query(
      `
      INSERT INTO inventory_items (name, description, quantity, category, location, updated_at)
      VALUES ($1, $2, $3, $4, $5, CURRENT_TIMESTAMP)
      RETURNING *
    `,
      [
        validatedData.name,
        validatedData.description || null,
        validatedData.quantity,
        validatedData.category || null,
        validatedData.location || null,
      ],
    )

    return NextResponse.json({ success: true, data: result.rows[0] }, { status: 201 })
  } catch (error) {
    console.error("Error creating inventory item:", error)
    if (error instanceof z.ZodError) {
      return NextResponse.json({ success: false, error: error.errors[0].message }, { status: 400 })
    }
    return NextResponse.json({ success: false, error: "Failed to create inventory item" }, { status: 500 })
  }
}
