import { type NextRequest, NextResponse } from "next/server"
import { generateFeeInvoice } from "@/lib/pdf-generator"
import { getSession } from "@/app/actions/auth-actions"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    // Check authentication
    const session = await getSession()
    if (!session) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 })
    }

    const feeId = Number.parseInt(params.id)
    if (isNaN(feeId)) {
      return NextResponse.json({ error: "Invalid fee ID" }, { status: 400 })
    }

    // Generate the PDF
    const pdfBuffer = await generateFeeInvoice(feeId)

    // Return the PDF as a response
    return new NextResponse(pdfBuffer, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="fee-invoice-${feeId}.pdf"`,
      },
    })
  } catch (error) {
    console.error("Error generating fee invoice:", error)
    return NextResponse.json({ error: "Failed to generate fee invoice" }, { status: 500 })
  }
}
