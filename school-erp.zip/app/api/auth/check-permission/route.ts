import { type NextRequest, NextResponse } from "next/server"
import { hasPermission } from "@/app/actions/auth-actions"

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const permission = searchParams.get("permission")

  if (!permission) {
    return NextResponse.json({ hasPermission: false }, { status: 400 })
  }

  const result = await hasPermission(permission)

  return NextResponse.json({ hasPermission: result })
}
