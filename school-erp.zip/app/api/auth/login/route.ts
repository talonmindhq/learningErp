import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"
import { SignJWT } from "jose"
import bcrypt from "bcryptjs"

// Initialize database connection
const sql = neon(process.env.DATABASE_URL!)

// JWT secret
const JWT_SECRET = new TextEncoder().encode(process.env.JWT_SECRET || "default_secret_key_change_in_production")

export async function POST(request: NextRequest) {
  try {
    console.log("🔐 Login API called")

    // Parse FormData from the request
    const formData = await request.formData()
    const email = formData.get("email") as string
    const password = formData.get("password") as string
    const role = formData.get("role") as string

    console.log("📝 Login attempt:", { email, role })

    // Validate required fields
    if (!email || !password || !role) {
      console.log("❌ Missing required fields")
      return NextResponse.json({ success: false, message: "Email, password, and role are required" }, { status: 400 })
    }

    // Query the database for the user
    let user
    try {
      const users = await sql`
        SELECT id, email, password, role, first_name, last_name
        FROM users 
        WHERE email = ${email} AND role = ${role}
        LIMIT 1
      `
      user = users[0]
      console.log("👤 User found:", user ? "Yes" : "No")
    } catch (dbError) {
      console.error("💾 Database error:", dbError)
      return NextResponse.json({ success: false, message: "Database connection error" }, { status: 500 })
    }

    if (!user) {
      console.log("❌ User not found")
      return NextResponse.json({ success: false, message: "Invalid email or role" }, { status: 401 })
    }

    // Check password using bcrypt
    let isValidPassword = false
    try {
      isValidPassword = await bcrypt.compare(password, user.password)
      console.log("🔑 Password check:", isValidPassword ? "Valid" : "Invalid")
    } catch (bcryptError) {
      console.error("🔑 Bcrypt error:", bcryptError)
      return NextResponse.json({ success: false, message: "Password verification error" }, { status: 500 })
    }

    if (!isValidPassword) {
      console.log("❌ Invalid password")
      return NextResponse.json({ success: false, message: "Invalid password" }, { status: 401 })
    }

    console.log("✅ Login successful")

    // Update last login time
    try {
      await sql`UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ${user.id}`
    } catch (updateError) {
      console.warn("⚠️ Could not update last login time:", updateError)
    }

    // Create JWT token
    const token = await new SignJWT({
      userId: user.id,
      email: user.email,
      role: user.role,
    })
      .setProtectedHeader({ alg: "HS256" })
      .setIssuedAt()
      .setExpirationTime("24h")
      .sign(JWT_SECRET)

    // Create response with user data
    const response = NextResponse.json({
      success: true,
      message: "Login successful",
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        firstName: user.first_name,
        lastName: user.last_name,
      },
    })

    // Set HTTP-only cookie with the token
    response.cookies.set("auth_token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 60 * 24, // 24 hours
      path: "/",
    })

    return response
  } catch (error) {
    console.error("🔥 Login API error:", error)
    return NextResponse.json({ success: false, message: "Internal server error" }, { status: 500 })
  }
}
