import * as XLSX from "xlsx"
import { NextResponse } from "next/server"

export async function GET() {
  try {
    // Create a new workbook
    const workbook = XLSX.utils.book_new()

    // Define the headers
    const headers = [
      "first_name",
      "last_name",
      "email",
      "grade",
      "admission_number",
      "date_of_birth",
      "gender",
      "address",
      "phone",
      "parent_name",
      "parent_phone",
      "parent_email",
      "status",
    ]

    // Add sample data
    const data = [
      headers,
      [
        "John",
        "Doe",
        "john.doe@example.com",
        "10",
        "ADM001",
        "2005-05-15",
        "Male",
        "123 Main St",
        "1234567890",
        "Jane Doe",
        "9876543210",
        "jane.doe@example.com",
        "Active",
      ],
      [
        "Alice",
        "Smith",
        "alice.smith@example.com",
        "9",
        "ADM002",
        "2006-08-20",
        "Female",
        "456 Oak Ave",
        "2345678901",
        "Bob Smith",
        "8765432109",
        "bob.smith@example.com",
        "Active",
      ],
    ]

    // Create a worksheet
    const worksheet = XLSX.utils.aoa_to_sheet(data)

    // Add the worksheet to the workbook
    XLSX.utils.book_append_sheet(workbook, worksheet, "Students")

    // Generate the Excel file
    const excelBuffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" })

    // Return the Excel file
    return new NextResponse(excelBuffer, {
      headers: {
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": "attachment; filename=student_import_template.xlsx",
      },
    })
  } catch (error) {
    console.error("Error generating Excel template:", error)
    return NextResponse.json({ error: "Failed to generate Excel template" }, { status: 500 })
  }
}
