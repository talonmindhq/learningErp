import { type NextRequest, NextResponse } from "next/server"
import { generateStudentReport } from "@/lib/pdf-generator"
import { getSession } from "@/app/actions/auth-actions"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    // Check authentication
    const session = await getSession()
    if (!session) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 })
    }

    const studentId = Number.parseInt(params.id)
    if (isNaN(studentId)) {
      return NextResponse.json({ error: "Invalid student ID" }, { status: 400 })
    }

    // Generate the PDF
    const pdfBuffer = await generateStudentReport(studentId)

    // Return the PDF as a response
    return new NextResponse(pdfBuffer, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="student-report-${studentId}.pdf"`,
      },
    })
  } catch (error) {
    console.error("Error generating student report:", error)
    return NextResponse.json({ error: "Failed to generate student report" }, { status: 500 })
  }
}
