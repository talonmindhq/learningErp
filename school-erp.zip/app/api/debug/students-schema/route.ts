import { sql } from "@/lib/db"
import { NextResponse } from "next/server"

export async function GET() {
  try {
    // Get the schema of the students table
    const result = await sql.query(`
      SELECT column_name, data_type, is_nullable
      FROM information_schema.columns
      WHERE table_name = 'students'
      ORDER BY ordinal_position
    `)

    return NextResponse.json({
      success: true,
      schema: result.rows,
      message: "Students table schema retrieved successfully",
    })
  } catch (error) {
    console.error("Error fetching students table schema:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch students table schema",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}
