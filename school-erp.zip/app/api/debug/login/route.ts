import { NextResponse } from "next/server"
import { sql } from "@/lib/db"

export async function GET(request: Request) {
  try {
    // Get the test user from the database
    const result = await sql`SELECT * FROM users WHERE email = 'test@example.com'`
    const users = result.rows || []

    if (users.length === 0) {
      return NextResponse.json(
        {
          error: "Test user not found",
          message: "The test user does not exist in the database",
        },
        { status: 404 },
      )
    }

    // Return user info (excluding password)
    const user = users[0]
    const safeUser = {
      id: user.id,
      email: user.email,
      role: user.role,
      first_name: user.first_name,
      last_name: user.last_name,
      created_at: user.created_at,
      last_login: user.last_login,
    }

    return NextResponse.json({
      message: "Test user found",
      user: safeUser,
      dbConnectionWorking: true,
    })
  } catch (error) {
    console.error("Debug endpoint error:", error)
    return NextResponse.json(
      {
        error: "Database error",
        message: "Error connecting to the database",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}
