import { BulkStudentImport } from "@/components/bulk-student-import"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function ImportStudentsPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Import Students</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Bulk Student Import</CardTitle>
          <CardDescription>Upload an Excel file with student data to import multiple students at once.</CardDescription>
        </CardHeader>
        <CardContent>
          <BulkStudentImport />
        </CardContent>
      </Card>
    </div>
  )
}
