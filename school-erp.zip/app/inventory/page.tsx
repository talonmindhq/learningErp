import { Suspense } from "react"
import { getInventoryItems, getInventoryCategories, getInventoryLocations } from "@/app/actions/inventory-actions"
import InventoryTable from "@/components/inventory/inventory-table"
import AddInventoryItemForm from "@/components/inventory/add-inventory-item-form"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PlusCircle, Package } from "lucide-react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Inventory Management | School ERP",
  description: "Manage school inventory items",
}

// Add export const dynamic = "force-dynamic" to prevent static prerendering
export const dynamic = "force-dynamic"

export default async function InventoryPage() {
  // Add try/catch blocks to handle potential errors
  let inventoryItems = []
  let categories = []
  let locations = []

  try {
    const inventoryResponse = await getInventoryItems()
    if (inventoryResponse.success && Array.isArray(inventoryResponse.data)) {
      inventoryItems = inventoryResponse.data
    }
  } catch (error) {
    console.error("Error fetching inventory items:", error)
  }

  try {
    const categoriesResponse = await getInventoryCategories()
    if (categoriesResponse.success && Array.isArray(categoriesResponse.data)) {
      categories = categoriesResponse.data
    }
  } catch (error) {
    console.error("Error fetching categories:", error)
  }

  try {
    const locationsResponse = await getInventoryLocations()
    if (locationsResponse.success && Array.isArray(locationsResponse.data)) {
      locations = locationsResponse.data
    }
  } catch (error) {
    console.error("Error fetching locations:", error)
  }

  return (
    <div className="container mx-auto py-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Inventory Management</h1>
          <p className="text-muted-foreground">Manage and track school inventory items</p>
        </div>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <div className="flex justify-between items-center">
          <TabsList>
            <TabsTrigger value="all">All Items</TabsTrigger>
            <TabsTrigger value="add">Add New Item</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="all" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Package className="mr-2 h-5 w-5" />
                Inventory Items
              </CardTitle>
              <CardDescription>
                View and manage all inventory items. Use the filters to narrow down your search.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Suspense fallback={<div>Loading inventory items...</div>}>
                <InventoryTable initialItems={inventoryItems} categories={categories} locations={locations} />
              </Suspense>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="add">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <PlusCircle className="mr-2 h-5 w-5" />
                Add New Inventory Item
              </CardTitle>
              <CardDescription>Fill out the form below to add a new item to the inventory.</CardDescription>
            </CardHeader>
            <CardContent>
              <AddInventoryItemForm categories={categories} locations={locations} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
