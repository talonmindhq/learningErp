import Link from "next/link"
import { PlusCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { HelpdeskTable } from "@/components/helpdesk-table"

export default function HelpdeskPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Helpdesk</h1>
        <Button asChild>
          <Link href="/helpdesk/new">
            <PlusCircle className="mr-2 h-4 w-4" />
            Create Ticket
          </Link>
        </Button>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Support Tickets</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <Input placeholder="Search tickets..." className="max-w-sm" />
              <Button variant="outline">Search</Button>
            </div>
            <HelpdeskTable />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
