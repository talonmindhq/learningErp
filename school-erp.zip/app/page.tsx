"use client"

import type React from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { GraduationCap } from "lucide-react"
import Link from "next/link"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { toast } from "@/components/ui/use-toast"
import { ToastAction } from "@/components/ui/toast"
import { Eye, EyeOff } from "lucide-react"

// Sample credentials
const VALID_CREDENTIALS = [
  { username: "admin", password: "digiservices@2023", role: "admin" },
  { username: "teacher", password: "Teacher@123", role: "teacher" },
  { username: "student", password: "Student@123", role: "student" },
  { username: "parent", password: "Parent@123", role: "parent" },
]

export default function LoginPage() {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [rememberMe, setRememberMe] = useState(false)
  const router = useRouter()

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      const user = VALID_CREDENTIALS.find((cred) => cred.username === username && cred.password === password)

      if (user) {
        // In a real app, you would set cookies/session/localStorage here
        localStorage.setItem("user", JSON.stringify({ username, role: user.role }))
        router.push("/dashboard")
      } else {
        toast({
          variant: "destructive",
          title: "Login Failed",
          description: "Invalid username or password. Please try again.",
          action: <ToastAction altText="Try Again">Try Again</ToastAction>,
        })
      }
      setIsLoading(false)
    }, 1000)
  }

  return (
    <div className="flex min-h-screen bg-white">
      {/* Left sidebar */}
      <div className="w-[450px] bg-[#6d28d9] relative overflow-hidden flex flex-col justify-center items-center">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-0 left-0 w-full h-full">
            <svg viewBox="0 0 450 900" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M120,600 Q150,550 180,600 T240,600 T300,600 T360,600"
                fill="none"
                stroke="#0066cc"
                strokeWidth="30"
                opacity="0.3"
              />
              <circle cx="100" cy="200" r="50" fill="#0066cc" opacity="0.2" />
              <circle cx="150" cy="250" r="30" fill="#0066cc" opacity="0.2" />
              <circle cx="200" cy="300" r="40" fill="#0066cc" opacity="0.2" />
              <path d="M50,700 Q100,650 150,700 T250,700" fill="none" stroke="#0066cc" strokeWidth="20" opacity="0.3" />
            </svg>
          </div>
        </div>
        <div className="relative z-10 text-white">
          <h1 className="text-5xl font-bold mb-4 tracking-tight">Login</h1>
        </div>
      </div>

      {/* Right content */}
      <div className="flex-1 relative flex items-center justify-center px-8">
        <div className="absolute inset-0 overflow-hidden">
          <svg className="w-full h-full opacity-20" viewBox="0 0 1000 800" xmlns="http://www.w3.org/2000/svg">
            <path d="M0,100 Q250,50 500,100 T1000,100 V0 H0 Z" fill="#e6f0fa" />
            <path d="M0,800 Q250,750 500,800 T1000,800 V900 H0 Z" fill="#e6f0fa" />
            <circle cx="900" cy="150" r="100" fill="#e6f0fa" />
            <circle cx="100" cy="650" r="80" fill="#e6f0fa" />
          </svg>
        </div>

        <div className="max-w-md w-full z-10">
          <div className="flex flex-col items-center mb-8">
            <GraduationCap className="h-16 w-16 text-netkampus-500 mb-4" />
            <h2 className="text-2xl font-semibold text-gray-800 tracking-tight">DigiServices-TESTING</h2>
          </div>

          <div className="bg-white rounded-lg p-8 shadow-lg">
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <div className="relative">
                  <Input
                    type="text"
                    placeholder="Username"
                    className="pl-10 py-6 bg-gray-50 border-gray-200"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                  />
                  <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="18"
                      height="18"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path>
                      <circle cx="12" cy="7" r="4"></circle>
                    </svg>
                  </div>
                </div>
              </div>

              <div>
                <div className="relative">
                  <Input
                    type={showPassword ? "text" : "password"}
                    placeholder="Password"
                    className="pl-10 py-6 bg-gray-50 border-gray-200"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                  <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="18"
                      height="18"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect>
                      <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                    </svg>
                  </div>
                  <div
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 cursor-pointer"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="remember"
                    checked={rememberMe}
                    onCheckedChange={(checked) => setRememberMe(checked as boolean)}
                  />
                  <label htmlFor="remember" className="text-sm text-gray-600">
                    Remember
                  </label>
                </div>
                <Link href="/forgot-password" className="text-sm text-violet-600 hover:text-violet-700">
                  Forgot Password?
                </Link>
              </div>

              <Button type="submit" className="w-full py-6 bg-violet-600 hover:bg-violet-700" disabled={isLoading}>
                {isLoading ? "Logging in..." : "Login"}
              </Button>
            </form>

            <div className="mt-6 text-center text-sm text-gray-500">
              Powered By <span className="font-semibold text-violet-600">DigiServices</span>
              <svg
                className="inline-block ml-1 w-4 h-4"
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M5 12h14"></path>
                <path d="m12 5 7 7-7 7"></path>
              </svg>
            </div>

            {/* Sample credentials hint */}
            <div className="mt-4 p-3 bg-gray-50 rounded-md border border-gray-200">
              <p className="text-xs font-medium text-gray-700 mb-1">Sample Credentials:</p>
              <p className="text-xs text-gray-600">Username: admin</p>
              <p className="text-xs text-gray-600">Password: digiservices@2023</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
