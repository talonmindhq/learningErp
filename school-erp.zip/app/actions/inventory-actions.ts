"use server"

import { sql } from "@/lib/db"
import { revalidatePath } from "next/cache"
import { z } from "zod"

// Validation schema
const inventoryItemSchema = z.object({
  name: z.string().min(1, "Name is required"),
  description: z.string().optional(),
  quantity: z.number().min(0, "Quantity cannot be negative"),
  category: z.string().optional(),
  location: z.string().optional(),
})

// Get all inventory items
export async function getInventoryItems() {
  try {
    const result = await sql.query(`
      SELECT * FROM inventory_items 
      ORDER BY name ASC
    `)
    return { success: true, data: result.rows || [] }
  } catch (error) {
    console.error("Error fetching inventory items:", error)
    return { success: false, error: "Failed to fetch inventory items", data: [] }
  }
}

// Get inventory items by category
export async function getInventoryItemsByCategory(category: string) {
  try {
    const result = await sql.query(
      `
      SELECT * FROM inventory_items 
      WHERE category = $1
      ORDER BY name ASC
    `,
      [category],
    )
    return { success: true, data: result.rows || [] }
  } catch (error) {
    console.error("Error fetching inventory items by category:", error)
    return { success: false, error: "Failed to fetch inventory items", data: [] }
  }
}

// Get inventory items by location
export async function getInventoryItemsByLocation(location: string) {
  try {
    const result = await sql.query(
      `
      SELECT * FROM inventory_items 
      WHERE location = $1
      ORDER BY name ASC
    `,
      [location],
    )
    return { success: true, data: result.rows || [] }
  } catch (error) {
    console.error("Error fetching inventory items by location:", error)
    return { success: false, error: "Failed to fetch inventory items", data: [] }
  }
}

// Get a single inventory item by ID
export async function getInventoryItemById(id: number) {
  try {
    const result = await sql.query(
      `
      SELECT * FROM inventory_items 
      WHERE id = $1
    `,
      [id],
    )

    if (!result.rows || result.rows.length === 0) {
      return { success: false, error: "Inventory item not found", data: null }
    }

    return { success: true, data: result.rows[0] }
  } catch (error) {
    console.error("Error fetching inventory item:", error)
    return { success: false, error: "Failed to fetch inventory item", data: null }
  }
}

// Create a new inventory item
export async function createInventoryItem(formData: FormData) {
  try {
    // Extract and validate form data
    const name = formData.get("name") as string
    const description = formData.get("description") as string
    const quantityStr = formData.get("quantity") as string
    const quantity = Number.parseInt(quantityStr, 10)
    const category = formData.get("category") as string
    const location = formData.get("location") as string

    // Validate data
    const validatedData = inventoryItemSchema.parse({
      name,
      description: description || undefined,
      quantity,
      category: category || undefined,
      location: location || undefined,
    })

    // Insert into database
    const result = await sql.query(
      `
      INSERT INTO inventory_items (name, description, quantity, category, location, updated_at)
      VALUES ($1, $2, $3, $4, $5, CURRENT_TIMESTAMP)
      RETURNING *
    `,
      [
        validatedData.name,
        validatedData.description || null,
        validatedData.quantity,
        validatedData.category || null,
        validatedData.location || null,
      ],
    )

    revalidatePath("/inventory")
    return { success: true, data: result.rows?.[0] || null }
  } catch (error) {
    console.error("Error creating inventory item:", error)
    if (error instanceof z.ZodError) {
      return { success: false, error: error.errors[0].message, data: null }
    }
    return { success: false, error: "Failed to create inventory item", data: null }
  }
}

// Update an inventory item
export async function updateInventoryItem(id: number, formData: FormData) {
  try {
    // Extract and validate form data
    const name = formData.get("name") as string
    const description = formData.get("description") as string
    const quantityStr = formData.get("quantity") as string
    const quantity = Number.parseInt(quantityStr, 10)
    const category = formData.get("category") as string
    const location = formData.get("location") as string

    // Validate data
    const validatedData = inventoryItemSchema.parse({
      name,
      description: description || undefined,
      quantity,
      category: category || undefined,
      location: location || undefined,
    })

    // Update in database
    const result = await sql.query(
      `
      UPDATE inventory_items
      SET name = $1, description = $2, quantity = $3, category = $4, location = $5, updated_at = CURRENT_TIMESTAMP
      WHERE id = $6
      RETURNING *
    `,
      [
        validatedData.name,
        validatedData.description || null,
        validatedData.quantity,
        validatedData.category || null,
        validatedData.location || null,
        id,
      ],
    )

    if (!result.rows || result.rows.length === 0) {
      return { success: false, error: "Inventory item not found", data: null }
    }

    revalidatePath("/inventory")
    return { success: true, data: result.rows[0] }
  } catch (error) {
    console.error("Error updating inventory item:", error)
    if (error instanceof z.ZodError) {
      return { success: false, error: error.errors[0].message, data: null }
    }
    return { success: false, error: "Failed to update inventory item", data: null }
  }
}

// Delete an inventory item
export async function deleteInventoryItem(id: number) {
  try {
    const result = await sql.query(
      `
      DELETE FROM inventory_items
      WHERE id = $1
      RETURNING id
    `,
      [id],
    )

    if (!result.rows || result.rows.length === 0) {
      return { success: false, error: "Inventory item not found" }
    }

    revalidatePath("/inventory")
    return { success: true }
  } catch (error) {
    console.error("Error deleting inventory item:", error)
    return { success: false, error: "Failed to delete inventory item" }
  }
}

// Get unique categories
export async function getInventoryCategories() {
  try {
    const result = await sql.query(`
      SELECT DISTINCT category 
      FROM inventory_items 
      WHERE category IS NOT NULL
      ORDER BY category ASC
    `)
    return { success: true, data: result.rows?.map((row) => row.category) || [] }
  } catch (error) {
    console.error("Error fetching inventory categories:", error)
    return { success: false, error: "Failed to fetch categories", data: [] }
  }
}

// Get unique locations
export async function getInventoryLocations() {
  try {
    const result = await sql.query(`
      SELECT DISTINCT location 
      FROM inventory_items 
      WHERE location IS NOT NULL
      ORDER BY location ASC
    `)
    return { success: true, data: result.rows?.map((row) => row.location) || [] }
  } catch (error) {
    console.error("Error fetching inventory locations:", error)
    return { success: false, error: "Failed to fetch locations", data: [] }
  }
}
