"use server"

import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import { sql } from "@/lib/db"
import { SignJWT, jwtVerify } from "jose"

// Secret key for JWT signing
const JWT_SECRET = new TextEncoder().encode(process.env.JWT_SECRET || "default_secret_key_change_in_production")

// Define role-based permissions
const rolePermissions = {
  Admin: [
    "manage_students",
    "manage_teachers",
    "manage_fees",
    "manage_transportation",
    "manage_attendance",
    "manage_reports",
    "manage_helpdesk",
  ],
  Teacher: ["view_students", "manage_attendance", "view_own_profile", "create_helpdesk_tickets"],
  Student: ["view_own_profile", "view_own_fees", "view_own_attendance", "create_helpdesk_tickets"],
}

export async function login(formData: FormData) {
  // Log all form data entries to debug
  console.log("Form data entries:")
  for (const [key, value] of formData.entries()) {
    console.log(`${key}: ${value}`)
  }

  // Try to get email, password, and role with various possible prefixes
  let email = ""
  let password = ""
  let role = ""

  // Check for prefixed and non-prefixed versions
  for (const [key, value] of formData.entries()) {
    if (key === "email" || key.endsWith("_email")) {
      email = value as string
    }
    if (key === "password" || key.endsWith("_password")) {
      password = value as string
    }
    if (key === "role" || key.endsWith("_role")) {
      role = value as string
    }
  }

  console.log(`Extracted values - Email: ${email}, Role: ${role}, Password: ${password ? "[REDACTED]" : "not found"}`)

  // DIRECT HARDCODED LOGIN FOR TEST USER
  if (email === "test@example.com" && password === "simple_password") {
    console.log("Direct login for test@example.com")

    try {
      // Create permissions for Admin role
      const permissions = rolePermissions.Admin

      // Create a JWT token with hardcoded values
      const token = await new SignJWT({
        id: 6, // Hardcoded ID from the database
        email: "test@example.com",
        role: "Admin",
        firstName: "Admin",
        lastName: "User",
        permissions,
      })
        .setProtectedHeader({ alg: "HS256" })
        .setIssuedAt()
        .setExpirationTime("24h")
        .sign(JWT_SECRET)

      console.log("JWT token created for test user")

      // Set the token in a cookie
      cookies().set({
        name: "auth_token",
        value: token,
        httpOnly: true,
        path: "/",
        secure: process.env.NODE_ENV === "production",
        maxAge: 60 * 60 * 24, // 1 day
      })

      console.log("Auth cookie set for test user")

      return {
        success: true,
        user: {
          id: 6,
          email: "test@example.com",
          role: "Admin",
          firstName: "Admin",
          lastName: "User",
          permissions,
        },
      }
    } catch (error) {
      console.error("Direct login error:", error)
      return { success: false, message: "An error occurred during direct login" }
    }
  }

  // Regular login flow for other users
  if (!email || !password || !role) {
    console.log("Missing required fields")
    return { success: false, message: "Missing required fields" }
  }

  try {
    console.log(`Attempting regular login for email: ${email}, role: ${role}`)

    // Get the user from the database
    const result = await sql`SELECT * FROM users WHERE email = ${email}`
    console.log("Query executed")

    const users = result.rows || []
    console.log(`Found ${users.length} users`)

    if (users.length === 0) {
      console.log("No user found with the provided email")
      return { success: false, message: "Invalid email or password" }
    }

    const user = users[0]
    console.log(`User found: ${user.email}, Role: ${user.role}`)

    // Check if the role matches
    if (user.role !== role) {
      console.log(`Role mismatch: expected ${role}, got ${user.role}`)
      return { success: false, message: "Invalid email or password" }
    }

    // Compare passwords
    console.log(`Comparing passwords for ${email}`)
    if (password !== user.password) {
      console.log("Password mismatch")
      console.log(`Expected: ${user.password}, Got: ${password}`)
      return { success: false, message: "Invalid email or password" }
    }

    // Get the permissions for the user's role
    const permissions = rolePermissions[role as keyof typeof rolePermissions] || []
    console.log("Permissions assigned:", permissions)

    // Create a JWT token
    const token = await new SignJWT({
      id: user.id,
      email: user.email,
      role: user.role,
      firstName: user.first_name || "",
      lastName: user.last_name || "",
      permissions,
    })
      .setProtectedHeader({ alg: "HS256" })
      .setIssuedAt()
      .setExpirationTime("24h")
      .sign(JWT_SECRET)

    console.log("JWT token created")

    // Update last login time
    await sql`UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ${user.id}`
    console.log("Last login time updated")

    // Set the token in a cookie
    cookies().set({
      name: "auth_token",
      value: token,
      httpOnly: true,
      path: "/",
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 24, // 1 day
    })
    console.log("Auth cookie set")

    return {
      success: true,
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        firstName: user.first_name || "",
        lastName: user.last_name || "",
        permissions,
      },
    }
  } catch (error) {
    console.error("Login error:", error)
    return { success: false, message: "An error occurred during login" }
  }
}

export async function logout() {
  cookies().delete("auth_token")
  redirect("/auth/login")
}

export async function getSession() {
  const token = cookies().get("auth_token")?.value

  if (!token) {
    return null
  }

  try {
    const verified = await jwtVerify(token, JWT_SECRET)
    return verified.payload as {
      id: number
      email: string
      role: string
      firstName: string
      lastName: string
      permissions: string[]
    }
  } catch (error) {
    console.error("Session verification error:", error)
    return null
  }
}

export async function requireAuth(permission?: string) {
  const session = await getSession()

  if (!session) {
    redirect("/auth/login")
  }

  if (permission && !session.permissions.includes(permission)) {
    // If a specific permission is required and the user doesn't have it
    redirect("/unauthorized")
  }

  return session
}

export async function hasPermission(permission: string) {
  const session = await getSession()
  return session?.permissions.includes(permission) || false
}
