"use server"

import { executeQuery } from "@/lib/db"
import { revalidatePath } from "next/cache"

export async function getTransportRoutes() {
  try {
    const routes = await executeQuery(`
      SELECT tr.*, 
             (SELECT COUNT(*) FROM students WHERE transport_route_id = tr.id) as students_count
      FROM transport_routes tr
      ORDER BY tr.name
    `)
    return { success: true, data: routes }
  } catch (error) {
    console.error("Error fetching transport routes:", error)
    return { success: false, message: "Failed to fetch transport routes" }
  }
}

export async function getTransportRouteById(id: number) {
  try {
    const routes = await executeQuery("SELECT * FROM transport_routes WHERE id = $1", [id])

    if (routes.length === 0) {
      return { success: false, message: "Transport route not found" }
    }

    return { success: true, data: routes[0] }
  } catch (error) {
    console.error(`Error fetching transport route with ID ${id}:`, error)
    return { success: false, message: "Failed to fetch transport route details" }
  }
}

export async function createTransportRoute(formData: FormData) {
  try {
    const name = formData.get("name") as string
    const driver = formData.get("driver") as string
    const vehicle = formData.get("vehicle") as string
    const capacity = Number.parseInt(formData.get("capacity") as string)

    // Validate required fields
    if (!name || !driver || !vehicle || !capacity) {
      return { success: false, message: "Required fields are missing" }
    }

    // Insert new transport route
    const result = await executeQuery(
      `INSERT INTO transport_routes 
       (name, driver, vehicle, capacity) 
       VALUES ($1, $2, $3, $4) 
       RETURNING id`,
      [name, driver, vehicle, capacity],
    )

    revalidatePath("/transportation")
    return { success: true, data: result[0] }
  } catch (error) {
    console.error("Error creating transport route:", error)
    return { success: false, message: "Failed to create transport route" }
  }
}

export async function updateTransportRoute(id: number, formData: FormData) {
  try {
    const name = formData.get("name") as string
    const driver = formData.get("driver") as string
    const vehicle = formData.get("vehicle") as string
    const capacity = Number.parseInt(formData.get("capacity") as string)
    const status = formData.get("status") as string

    // Validate required fields
    if (!name || !driver || !vehicle || !capacity) {
      return { success: false, message: "Required fields are missing" }
    }

    // Update transport route
    await executeQuery(
      `UPDATE transport_routes 
       SET name = $1, driver = $2, vehicle = $3, capacity = $4, status = $5
       WHERE id = $6`,
      [name, driver, vehicle, capacity, status, id],
    )

    revalidatePath("/transportation")
    revalidatePath(`/transportation/${id}`)
    return { success: true }
  } catch (error) {
    console.error(`Error updating transport route with ID ${id}:`, error)
    return { success: false, message: "Failed to update transport route" }
  }
}

export async function getStudentsByRouteId(routeId: number) {
  try {
    const students = await executeQuery(
      `
      SELECT id, first_name, last_name, grade, email
      FROM students
      WHERE transport_route_id = $1 AND status = 'Active'
      ORDER BY grade, first_name, last_name
    `,
      [routeId],
    )

    return { success: true, data: students }
  } catch (error) {
    console.error(`Error fetching students for route ID ${routeId}:`, error)
    return { success: false, message: "Failed to fetch students" }
  }
}

export async function deleteTransportRoute(id: number) {
  try {
    // Check if there are students using this route
    const students = await executeQuery("SELECT COUNT(*) as count FROM students WHERE transport_route_id = $1", [id])

    if (students[0].count > 0) {
      return {
        success: false,
        message: "Cannot delete route because it is assigned to students. Please reassign students first.",
      }
    }

    // Delete transport route
    await executeQuery("DELETE FROM transport_routes WHERE id = $1", [id])

    revalidatePath("/transportation")
    return { success: true }
  } catch (error) {
    console.error(`Error deleting transport route with ID ${id}:`, error)
    return { success: false, message: "Failed to delete transport route" }
  }
}
