"use server"

import { executeQuery } from "@/lib/db"
import { sql } from "@/lib/db"
import { revalidatePath } from "next/cache"
import { requireAuth } from "./auth-actions"
import { calculateFinalGrade } from "@/lib/validators/grade-calculator"

// Get all assessments
export async function getAllAssessments() {
  try {
    // Check if user has permission to view assessments
    const session = await requireAuth()

    let assessments

    if (session.role === "Admin") {
      // Admin can see all assessments
      assessments = await executeQuery(`
        SELECT a.*, 
               at.name as assessment_type,
               at.weight as type_weight,
               s.name as subject_name,
               t.name as term_name
        FROM assessments a
        JOIN assessment_types at ON a.assessment_type_id = at.id
        JOIN subjects s ON a.subject_id = s.id
        JOIN academic_terms t ON a.academic_term_id = t.id
        ORDER BY a.date DESC
      `)
    } else if (session.role === "Teacher") {
      // Teachers can see assessments for their subjects
      // In a real app, we would filter by teacher's assigned subjects
      assessments = await executeQuery(`
        SELECT a.*, 
               at.name as assessment_type,
               at.weight as type_weight,
               s.name as subject_name,
               t.name as term_name
        FROM assessments a
        JOIN assessment_types at ON a.assessment_type_id = at.id
        JOIN subjects s ON a.subject_id = s.id
        JOIN academic_terms t ON a.academic_term_id = t.id
        ORDER BY a.date DESC
      `)
    } else {
      // Students can only see assessments for their grade
      assessments = await executeQuery(
        `
        SELECT a.*, 
               at.name as assessment_type,
               at.weight as type_weight,
               s.name as subject_name,
               t.name as term_name
        FROM assessments a
        JOIN assessment_types at ON a.assessment_type_id = at.id
        JOIN subjects s ON a.subject_id = s.id
        JOIN academic_terms t ON a.academic_term_id = t.id
        JOIN students st ON a.grade = st.grade
        WHERE st.email = $1
        ORDER BY a.date DESC
      `,
        [session.email],
      )
    }

    return { success: true, data: assessments }
  } catch (error) {
    console.error("Error fetching assessments:", error)
    return { success: false, message: "Failed to fetch assessments" }
  }
}

// Get assessment by ID
export async function getAssessmentById(id: number) {
  try {
    // Check if user has permission to view assessment
    const session = await requireAuth()

    const assessments = await executeQuery(
      `
      SELECT a.*, 
             at.name as assessment_type,
             at.weight as type_weight,
             s.name as subject_name,
             t.name as term_name
      FROM assessments a
      JOIN assessment_types at ON a.assessment_type_id = at.id
      JOIN subjects s ON a.subject_id = s.id
      JOIN academic_terms t ON a.academic_term_id = t.id
      WHERE a.id = $1
    `,
      [id],
    )

    if (assessments.length === 0) {
      return { success: false, message: "Assessment not found" }
    }

    const assessment = assessments[0]

    // Check if student is allowed to view this assessment
    if (session.role === "Student") {
      const students = await executeQuery(`SELECT * FROM students WHERE email = $1 AND grade = $2`, [
        session.email,
        assessment.grade,
      ])

      if (students.length === 0) {
        return { success: false, message: "You do not have permission to view this assessment" }
      }
    }

    return { success: true, data: assessment }
  } catch (error) {
    console.error(`Error fetching assessment with ID ${id}:`, error)
    return { success: false, message: "Failed to fetch assessment details" }
  }
}

// Create a new assessment
export async function createAssessment(formData: FormData) {
  const title = formData.get("title") as string
  const description = formData.get("description") as string
  const classId = Number.parseInt(formData.get("classId") as string)
  const subjectId = Number.parseInt(formData.get("subjectId") as string)
  const assessmentTypeId = Number.parseInt(formData.get("assessmentTypeId") as string)
  const maxMarks = Number.parseInt(formData.get("maxMarks") as string)
  const date = formData.get("date") as string

  try {
    // Update this query to use sql.query
    const result = await sql.query(
      `INSERT INTO assessments (title, description, class_id, subject_id, assessment_type_id, max_marks, date)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING id`,
      [title, description, classId, subjectId, assessmentTypeId, maxMarks, date],
    )

    const assessmentId = result[0].id

    return {
      success: true,
      message: "Assessment created successfully",
      assessmentId,
    }
  } catch (error) {
    console.error("Error creating assessment:", error)
    return { success: false, message: "Failed to create assessment" }
  }
}

// Update an assessment
export async function updateAssessment(id: number, formData: FormData) {
  try {
    // Check if user has permission to update assessments
    await requireAuth("manage_grades")

    const name = formData.get("name") as string
    const description = formData.get("description") as string
    const assessmentTypeId = Number.parseInt(formData.get("assessmentTypeId") as string)
    const subjectId = Number.parseInt(formData.get("subjectId") as string)
    const maxScore = Number.parseInt(formData.get("maxScore") as string)
    const weight = Number.parseFloat(formData.get("weight") as string)
    const academicTermId = Number.parseInt(formData.get("academicTermId") as string)
    const grade = formData.get("grade") as string
    const date = formData.get("date") as string

    // Validate required fields
    if (!name || !assessmentTypeId || !subjectId || !maxScore || !weight || !academicTermId || !grade || !date) {
      return { success: false, message: "Required fields are missing" }
    }

    // Validate weight
    if (weight <= 0 || weight > 100) {
      return { success: false, message: "Weight must be between 0 and 100" }
    }

    // Get the current assessment
    const currentAssessments = await executeQuery("SELECT * FROM assessments WHERE id = $1", [id])

    if (currentAssessments.length === 0) {
      return { success: false, message: "Assessment not found" }
    }

    const currentAssessment = currentAssessments[0]

    // Check if assessment with same name already exists for this subject and term (excluding this one)
    const existingAssessments = await executeQuery(
      `SELECT * FROM assessments 
       WHERE name = $1 AND subject_id = $2 AND academic_term_id = $3 AND grade = $4 AND id != $5`,
      [name, subjectId, academicTermId, grade, id],
    )

    if (existingAssessments.length > 0) {
      return { success: false, message: "Another assessment with this name already exists for this subject and term" }
    }

    // Get all assessments for this subject, term, and grade to validate total weight
    const assessments = await executeQuery(
      `SELECT * FROM assessments 
       WHERE subject_id = $1 AND academic_term_id = $2 AND grade = $3 AND id != $4`,
      [subjectId, academicTermId, grade, id],
    )

    // Validate that total weight doesn't exceed 100%
    const totalExistingWeight = assessments.reduce((sum, a) => sum + Number.parseFloat(a.weight), 0)
    const newTotalWeight = totalExistingWeight + weight

    if (newTotalWeight > 100) {
      return {
        success: false,
        message: `Total assessment weight would exceed 100%. Current total (excluding this assessment): ${totalExistingWeight}%, This assessment: ${weight}%`,
      }
    }

    // Update assessment
    await executeQuery(
      `UPDATE assessments 
       SET name = $1, description = $2, assessment_type_id = $3, subject_id = $4, 
           max_score = $5, weight = $6, academic_term_id = $7, grade = $8, date = $9
       WHERE id = $10`,
      [name, description, assessmentTypeId, subjectId, maxScore, weight, academicTermId, grade, date, id],
    )

    revalidatePath("/grades")
    revalidatePath(`/grades/${id}`)
    return { success: true }
  } catch (error) {
    console.error(`Error updating assessment with ID ${id}:`, error)
    return { success: false, message: "Failed to update assessment" }
  }
}

// Delete an assessment
export async function deleteAssessment(id: number) {
  try {
    // Check if user has permission to delete assessments
    await requireAuth("manage_grades")

    // Check if assessment exists
    const assessments = await executeQuery("SELECT id FROM assessments WHERE id = $1", [id])

    if (assessments.length === 0) {
      return { success: false, message: "Assessment not found" }
    }

    // Check if there are grades associated with this assessment
    const grades = await executeQuery("SELECT COUNT(*) as count FROM grades WHERE assessment_id = $1", [id])

    if (grades[0].count > 0) {
      return {
        success: false,
        message: "Cannot delete assessment because it has grades associated with it. Please delete the grades first.",
      }
    }

    // Delete assessment
    await executeQuery("DELETE FROM assessments WHERE id = $1", [id])

    revalidatePath("/grades")
    return { success: true }
  } catch (error) {
    console.error(`Error deleting assessment with ID ${id}:`, error)
    return { success: false, message: "Failed to delete assessment" }
  }
}

// Get students for an assessment
export async function getStudentsForAssessment(assessmentId: number) {
  try {
    // Check if user has permission to view students
    await requireAuth()

    // Get the assessment
    const assessments = await executeQuery("SELECT * FROM assessments WHERE id = $1", [assessmentId])

    if (assessments.length === 0) {
      return { success: false, message: "Assessment not found" }
    }

    const assessment = assessments[0]

    // Get students in this grade
    const students = await executeQuery(
      `SELECT s.id, s.first_name, s.last_name, s.email, s.grade,
              g.id as grade_id, g.score, g.remarks
       FROM students s
       LEFT JOIN grades g ON s.id = g.student_id AND g.assessment_id = $1
       WHERE s.grade = $2 AND s.status = 'Active'
       ORDER BY s.first_name, s.last_name`,
      [assessmentId, assessment.grade],
    )

    return { success: true, data: { assessment, students } }
  } catch (error) {
    console.error(`Error fetching students for assessment ID ${assessmentId}:`, error)
    return { success: false, message: "Failed to fetch students" }
  }
}

// Record grades for an assessment
export async function recordGrades(assessmentId: number, formData: FormData) {
  try {
    // Begin transaction
    await sql.query("BEGIN")

    // Delete existing grades for this assessment
    await sql.query(
      `
      DELETE FROM grades
      WHERE assessment_id = $1
    `,
      [assessmentId],
    )

    // Get assessment details to validate marks
    const assessmentResult = await getAssessmentById(assessmentId)
    if (!assessmentResult.success) {
      await sql.query("ROLLBACK")
      return assessmentResult
    }

    const maxMarks = assessmentResult.assessment.max_marks

    // Get the form data
    const entries = Array.from(formData.entries())

    // Insert new grades
    for (const [key, value] of entries) {
      if (key.startsWith("marks-")) {
        const studentId = Number.parseInt(key.replace("marks-", ""))
        const marks = Number.parseFloat(value as string)

        // Validate marks
        if (isNaN(marks) || marks < 0 || marks > maxMarks) {
          await sql.query("ROLLBACK")
          return {
            success: false,
            message: `Invalid marks for student ID ${studentId}. Marks must be between 0 and ${maxMarks}.`,
          }
        }

        const remarks = (formData.get(`remarks-${studentId}`) as string) || null

        await sql.query("INSERT INTO grades (student_id, assessment_id, marks, remarks) VALUES ($1, $2, $3, $4)", [
          studentId,
          assessmentId,
          marks,
          remarks,
        ])
      }
    }

    // Commit transaction
    await sql.query("COMMIT")

    return { success: true, message: "Grades recorded successfully" }
  } catch (error) {
    // Rollback transaction on error
    await sql.query("ROLLBACK")
    console.error("Error recording grades:", error)
    return { success: false, message: "Failed to record grades" }
  }
}

// Get student grades
export async function getStudentGradesReport(studentId: number) {
  try {
    // Check if user has permission to view grades
    const session = await requireAuth()

    // If student, check if they're viewing their own grades
    if (session.role === "Student") {
      const students = await executeQuery("SELECT id FROM students WHERE email = $1", [session.email])

      if (students.length === 0 || students[0].id !== studentId) {
        return { success: false, message: "You do not have permission to view these grades" }
      }
    }

    // Get student details
    const students = await executeQuery("SELECT * FROM students WHERE id = $1", [studentId])

    if (students.length === 0) {
      return { success: false, message: "Student not found" }
    }

    const student = students[0]

    // Get student's grades
    const grades = await executeQuery(
      `
      SELECT g.*, 
             a.name as assessment_name, 
             a.weight as assessment_weight,
             a.max_score,
             a.date as assessment_date,
             s.name as subject_name,
             t.name as term_name
      FROM grades g
      JOIN assessments a ON g.assessment_id = a.id
      JOIN subjects s ON a.subject_id = s.id
      JOIN academic_terms t ON a.academic_term_id = t.id
      WHERE g.student_id = $1
      ORDER BY a.date DESC
    `,
      [studentId],
    )

    return { success: true, data: { student, grades } }
  } catch (error) {
    console.error(`Error fetching grades for student ID ${studentId}:`, error)
    return { success: false, message: "Failed to fetch student grades" }
  }
}

// Get assessment types
export async function getAssessmentTypes() {
  try {
    // Update this query to use sql.query
    const types = await sql.query(`
      SELECT * FROM assessment_types
      ORDER BY name
    `)
    return { success: true, types }
  } catch (error) {
    console.error("Error fetching assessment types:", error)
    return { success: false, message: "Failed to fetch assessment types" }
  }
}

// Get subjects
export async function getSubjects() {
  try {
    // Update this query to use sql.query
    const subjects = await sql.query(`
      SELECT * FROM subjects
      ORDER BY name
    `)
    return { success: true, subjects }
  } catch (error) {
    console.error("Error fetching subjects:", error)
    return { success: false, message: "Failed to fetch subjects" }
  }
}

// Get academic terms
export async function getAcademicTerms() {
  try {
    const terms = await executeQuery("SELECT * FROM academic_terms ORDER BY start_date DESC")
    return { success: true, data: terms }
  } catch (error) {
    console.error("Error fetching academic terms:", error)
    return { success: false, message: "Failed to fetch academic terms" }
  }
}

// Get grade report data
export async function getGradeReportData(filters: {
  grade?: string
  subjectId?: number
  termId?: number
}) {
  try {
    // Check if user has permission to view grade reports
    const session = await requireAuth()

    let whereClause = ""
    const params: any[] = []
    let paramIndex = 1

    if (filters.grade) {
      whereClause += ` AND a.grade = $${paramIndex}`
      params.push(filters.grade)
      paramIndex++
    }

    if (filters.subjectId) {
      whereClause += ` AND a.subject_id = $${paramIndex}`
      params.push(filters.subjectId)
      paramIndex++
    }

    if (filters.termId) {
      whereClause += ` AND a.academic_term_id = $${paramIndex}`
      params.push(filters.termId)
      paramIndex++
    }

    // If student, only show their own grades
    if (session.role === "Student") {
      const students = await executeQuery("SELECT id FROM students WHERE email = $1", [session.email])

      if (students.length > 0) {
        whereClause += ` AND g.student_id = $${paramIndex}`
        params.push(students[0].id)
        paramIndex++
      }
    }

    // Get grade report data
    const reportData = await executeQuery(
      `
      SELECT g.student_id,
             s.first_name || ' ' || s.last_name as student_name,
             s.grade as student_grade,
             sub.id as subject_id,
             sub.name as subject_name,
             t.id as term_id,
             t.name as term_name,
             a.id as assessment_id,
             a.name as assessment_name,
             a.weight as assessment_weight,
             g.score,
             g.remarks
      FROM grades g
      JOIN assessments a ON g.assessment_id = a.id
      JOIN students s ON g.student_id = s.id
      JOIN subjects sub ON a.subject_id = sub.id
      JOIN academic_terms t ON a.academic_term_id = t.id
      WHERE 1=1 ${whereClause}
      ORDER BY s.grade, s.first_name, s.last_name, sub.name, a.date
    `,
      params,
    )

    // Get available filters
    const grades = await executeQuery("SELECT DISTINCT grade FROM students ORDER BY grade")
    const subjects = await executeQuery("SELECT id, name FROM subjects ORDER BY name")
    const terms = await executeQuery("SELECT id, name FROM academic_terms ORDER BY start_date DESC")

    return {
      success: true,
      data: {
        reportData,
        filters: {
          grades,
          subjects,
          terms,
        },
      },
    }
  } catch (error) {
    console.error("Error fetching grade report data:", error)
    return { success: false, message: "Failed to fetch grade report data" }
  }
}

export async function getClasses() {
  try {
    // Update this query to use sql.query
    const classes = await sql.query(`
      SELECT * FROM classes
      ORDER BY name
    `)
    return { success: true, classes }
  } catch (error) {
    console.error("Error fetching classes:", error)
    return { success: false, message: "Failed to fetch classes" }
  }
}

export async function getStudentsByClassId(classId: number) {
  try {
    // Update this query to use sql.query
    const students = await sql.query(
      `
      SELECT id, first_name, last_name
      FROM students
      WHERE class_id = $1
      ORDER BY last_name, first_name
    `,
      [classId],
    )

    return { success: true, students }
  } catch (error) {
    console.error(`Error fetching students for class ${classId}:`, error)
    return { success: false, message: "Failed to fetch students" }
  }
}

export async function getAssessmentsByClassAndSubject(classId?: number, subjectId?: number) {
  try {
    let query = `
      SELECT a.*, c.name as class_name, s.name as subject_name, t.name as assessment_type
      FROM assessments a
      JOIN classes c ON a.class_id = c.id
      JOIN subjects s ON a.subject_id = s.id
      JOIN assessment_types t ON a.assessment_type_id = t.id
    `

    const params = []
    let paramIndex = 1

    if (classId) {
      query += ` WHERE a.class_id = $${paramIndex}`
      params.push(classId)
      paramIndex++
    }

    if (subjectId) {
      query += classId ? ` AND a.subject_id = $${paramIndex}` : ` WHERE a.subject_id = $${paramIndex}`
      params.push(subjectId)
    }

    query += " ORDER BY a.date DESC"

    // Update this query to use sql.query
    const assessments = await sql.query(query, params)
    return { success: true, assessments }
  } catch (error) {
    console.error("Error fetching assessments:", error)
    return { success: false, message: "Failed to fetch assessments" }
  }
}

export async function getGradesByAssessmentId(assessmentId: number) {
  try {
    // Update this query to use sql.query
    const grades = await sql.query(
      `
      SELECT g.*, s.first_name, s.last_name
      FROM grades g
      JOIN students s ON g.student_id = s.id
      WHERE g.assessment_id = $1
      ORDER BY s.last_name, s.first_name
    `,
      [assessmentId],
    )

    return { success: true, grades }
  } catch (error) {
    console.error(`Error fetching grades for assessment ${assessmentId}:`, error)
    return { success: false, message: "Failed to fetch grades" }
  }
}

export async function getStudentGradesByClassAndSubject(studentId: number, classId?: number, subjectId?: number) {
  try {
    let query = `
      SELECT g.*, a.title, a.date, a.max_marks, s.name as subject_name, t.name as assessment_type, t.weight
      FROM grades g
      JOIN assessments a ON g.assessment_id = a.id
      JOIN subjects s ON a.subject_id = s.id
      JOIN assessment_types t ON a.assessment_type_id = t.id
      WHERE g.student_id = $1
    `

    const params = [studentId]
    let paramIndex = 2

    if (classId) {
      query += ` AND a.class_id = $${paramIndex}`
      params.push(classId)
      paramIndex++
    }

    if (subjectId) {
      query += ` AND a.subject_id = $${paramIndex}`
      params.push(subjectId)
    }

    query += " ORDER BY a.date DESC"

    // Update this query to use sql.query
    const grades = await sql.query(query, params)
    return { success: true, grades }
  } catch (error) {
    console.error(`Error fetching grades for student ${studentId}:`, error)
    return { success: false, message: "Failed to fetch grades" }
  }
}

export async function getClassGrades(classId: number, subjectId?: number) {
  try {
    // First get all students in the class
    const studentsResult = await getStudentsByClassId(classId)

    if (!studentsResult.success) {
      return studentsResult
    }

    const students = studentsResult.students
    const studentGrades = []

    // For each student, get their grades
    for (const student of students) {
      const gradesResult = await getStudentGradesByClassAndSubject(student.id, classId, subjectId)

      if (!gradesResult.success) {
        return gradesResult
      }

      // Calculate final grade if there are grades
      let finalGrade = null
      if (gradesResult.grades.length > 0) {
        finalGrade = calculateFinalGrade(gradesResult.grades)
      }

      studentGrades.push({
        student,
        grades: gradesResult.grades,
        finalGrade,
      })
    }

    return { success: true, studentGrades }
  } catch (error) {
    console.error(`Error fetching class grades for class ${classId}:`, error)
    return { success: false, message: "Failed to fetch class grades" }
  }
}

export async function getGradeReport(classId?: number, subjectId?: number, studentId?: number) {
  try {
    // If studentId is provided, get grades for that student
    if (studentId) {
      const gradesResult = await getStudentGradesByClassAndSubject(studentId, classId, subjectId)

      if (!gradesResult.success) {
        return gradesResult
      }

      // Get student details
      const studentResult = await sql.query(
        `
        SELECT s.*, c.name as class_name
        FROM students s
        JOIN classes c ON s.class_id = c.id
        WHERE s.id = $1
      `,
        [studentId],
      )

      if (studentResult.length === 0) {
        return { success: false, message: "Student not found" }
      }

      // Calculate final grade if there are grades
      let finalGrade = null
      if (gradesResult.grades.length > 0) {
        finalGrade = calculateFinalGrade(gradesResult.grades)
      }

      return {
        success: true,
        report: {
          student: studentResult[0],
          grades: gradesResult.grades,
          finalGrade,
        },
      }
    }

    // If classId is provided, get grades for the whole class
    if (classId) {
      return await getClassGrades(classId, subjectId)
    }

    // If neither studentId nor classId is provided, return an error
    return { success: false, message: "Either studentId or classId must be provided" }
  } catch (error) {
    console.error("Error generating grade report:", error)
    return { success: false, message: "Failed to generate grade report" }
  }
}
