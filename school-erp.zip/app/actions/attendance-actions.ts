"use server"

import { sql } from "@/lib/db"
import { revalidatePath } from "next/cache"

// Get attendance records by date and grade
export async function getAttendanceByDate(date: string, grade: string) {
  try {
    const result = await sql`
      SELECT a.*, s.first_name, s.last_name
      FROM attendance a
      JOIN students s ON a.student_id = s.id
      WHERE a.date = ${date} AND s.grade = ${grade}
      ORDER BY s.first_name, s.last_name
    `

    return { success: true, data: result.rows }
  } catch (error) {
    console.error(`Error fetching attendance for date ${date} and grade ${grade}:`, error)
    return { success: false, message: "Failed to fetch attendance records" }
  }
}

// Get students by grade
export async function getStudentsByGrade(grade: string) {
  try {
    const result = await sql`
      SELECT id, first_name, last_name
      FROM students
      WHERE grade = ${grade} AND status = 'Active'
      ORDER BY first_name, last_name
    `

    return { success: true, data: result.rows }
  } catch (error) {
    console.error(`Error fetching students for grade ${grade}:`, error)
    return { success: false, message: "Failed to fetch students" }
  }
}

// Record attendance for multiple students
export async function recordAttendance(formData: FormData) {
  try {
    const date = formData.get("date") as string
    const grade = formData.get("grade") as string
    const teacherId = Number(formData.get("teacherId"))

    // Begin transaction
    await sql`BEGIN`

    try {
      // Delete existing attendance records for this date and grade
      await sql`
        DELETE FROM attendance
        WHERE date = ${date} AND student_id IN (
          SELECT id FROM students WHERE grade = ${grade}
        )
      `

      // Process each student's attendance
      for (const [key, value] of formData.entries()) {
        if (key.startsWith("student_")) {
          const studentId = Number(key.replace("student_", ""))
          const status = value as string
          const remarks = (formData.get(`remarks_${studentId}`) as string) || null

          await sql`
            INSERT INTO attendance (student_id, date, status, remarks, recorded_by, recorded_at)
            VALUES (${studentId}, ${date}, ${status}, ${remarks}, ${teacherId}, CURRENT_TIMESTAMP)
          `
        }
      }

      // Commit transaction
      await sql`COMMIT`

      revalidatePath("/attendance")
      return { success: true }
    } catch (error) {
      // Rollback transaction on error
      await sql`ROLLBACK`
      throw error
    }
  } catch (error) {
    console.error("Error recording attendance:", error)
    return { success: false, message: "Failed to record attendance" }
  }
}

// Get student attendance history
export async function getStudentAttendance(studentId: number) {
  try {
    const result = await sql`
      SELECT a.*, u.email as recorded_by_email
      FROM attendance a
      LEFT JOIN users u ON a.recorded_by = u.id
      WHERE a.student_id = ${studentId}
      ORDER BY a.date DESC
    `

    return { success: true, data: result.rows }
  } catch (error) {
    console.error(`Error fetching attendance for student ID ${studentId}:`, error)
    return { success: false, message: "Failed to fetch student attendance records" }
  }
}
