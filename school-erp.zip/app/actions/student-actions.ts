"use server"

import { sql } from "@/lib/db"
import { revalidatePath } from "next/cache"
import { z } from "zod"
import type { Student, StudentFormData } from "@/lib/types/student"

// Schema for validating student data
const studentSchema = z.object({
  first_name: z.string().min(2, "First name must be at least 2 characters"),
  last_name: z.string().min(2, "Last name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  phone: z.string().optional(),
  grade: z.string().min(1, "Grade is required"),
  address: z.string().optional(),
  admission_date: z.string().optional(),
  status: z.string().optional().default("Active"),
  admission_number: z.string().min(1, "Admission number is required"),
  date_of_birth: z.string().optional(),
  gender: z.string().optional(),
  parent_name: z.string().optional(),
  parent_phone: z.string().optional(),
  parent_email: z.string().email("Invalid parent email").optional().or(z.literal("")),
})

// Get all students
export async function getStudents() {
  try {
    const result = await sql`
      SELECT 
        id, first_name, last_name, email, phone, grade, address, 
        admission_date, transport_route_id, status, admission_number,
        date_of_birth, gender, parent_name, parent_phone, parent_email
      FROM students 
      ORDER BY admission_number ASC
    `

    return { success: true, data: result }
  } catch (error) {
    console.error("Error fetching students:", error)
    return { success: false, error: "Failed to fetch students" }
  }
}

// Get students by grade
export async function getStudentsByGrade(grade: string) {
  try {
    const result = await sql`
      SELECT 
        id, first_name, last_name, email, phone, grade, address, 
        admission_date, transport_route_id, status, admission_number,
        date_of_birth, gender, parent_name, parent_phone, parent_email
      FROM students 
      WHERE grade = ${grade}
      ORDER BY last_name, first_name
    `

    return { success: true, data: result }
  } catch (error) {
    console.error(`Error fetching students for grade ${grade}:`, error)
    return { success: false, error: `Failed to fetch students for grade ${grade}` }
  }
}

// Get a single student by ID
export async function getStudentById(id: number) {
  try {
    const result = await sql`
      SELECT 
        id, first_name, last_name, email, phone, grade, address, 
        admission_date, transport_route_id, status, admission_number,
        date_of_birth, gender, parent_name, parent_phone, parent_email
      FROM students 
      WHERE id = ${id}
    `

    if (result.length === 0) {
      return { success: false, error: "Student not found" }
    }

    return { success: true, data: result[0] as Student }
  } catch (error) {
    console.error(`Error fetching student with ID ${id}:`, error)
    return { success: false, error: "Failed to fetch student details" }
  }
}

// Create a new student
export async function createStudent(formData: StudentFormData) {
  try {
    console.log("Creating student with data:", formData)

    // Validate form data
    const validatedData = studentSchema.parse(formData)
    console.log("Validation passed, validated data:", validatedData)

    // Check if email is already in use
    const existingStudent = await sql`SELECT id FROM students WHERE email = ${validatedData.email}`

    if (existingStudent.length > 0) {
      return { success: false, error: "Email is already in use" }
    }

    // Check if admission number is already in use
    const existingAdmission =
      await sql`SELECT id FROM students WHERE admission_number = ${validatedData.admission_number}`

    if (existingAdmission.length > 0) {
      return { success: false, error: "Admission number is already in use" }
    }

    // Insert new student
    const result = await sql`
      INSERT INTO students (
        first_name, last_name, email, phone, grade, address, 
        admission_date, status, admission_number, date_of_birth, 
        gender, parent_name, parent_phone, parent_email
      ) VALUES (
        ${validatedData.first_name}, ${validatedData.last_name}, ${validatedData.email}, 
        ${validatedData.phone || null}, ${validatedData.grade}, ${validatedData.address || null}, 
        ${validatedData.admission_date || null}, ${validatedData.status || "Active"}, 
        ${validatedData.admission_number}, ${validatedData.date_of_birth || null}, 
        ${validatedData.gender || null}, ${validatedData.parent_name || null}, 
        ${validatedData.parent_phone || null}, ${validatedData.parent_email || null}
      ) RETURNING id
    `

    revalidatePath("/students")
    return { success: true, data: { id: result[0].id } }
  } catch (error) {
    console.error("Error creating student:", error)
    if (error instanceof z.ZodError) {
      return { success: false, error: error.errors[0].message }
    }
    if (error instanceof Error) {
      return { success: false, error: `Database error: ${error.message}` }
    }
    return { success: false, error: "Failed to create student" }
  }
}

// Update an existing student
export async function updateStudent(id: number, formData: StudentFormData) {
  try {
    // Validate form data
    const validatedData = studentSchema.parse(formData)

    // Check if email is already in use by another student
    const existingStudent = await sql`SELECT id FROM students WHERE email = ${validatedData.email} AND id != ${id}`

    if (existingStudent.length > 0) {
      return { success: false, error: "Email is already in use by another student" }
    }

    // Check if admission number is already in use by another student
    const existingAdmission =
      await sql`SELECT id FROM students WHERE admission_number = ${validatedData.admission_number} AND id != ${id}`

    if (existingAdmission.length > 0) {
      return { success: false, error: "Admission number is already in use by another student" }
    }

    // Update student
    await sql`
      UPDATE students SET
        first_name = ${validatedData.first_name},
        last_name = ${validatedData.last_name},
        email = ${validatedData.email},
        phone = ${validatedData.phone || null},
        grade = ${validatedData.grade},
        address = ${validatedData.address || null},
        admission_date = ${validatedData.admission_date || null},
        status = ${validatedData.status || "Active"},
        admission_number = ${validatedData.admission_number},
        date_of_birth = ${validatedData.date_of_birth || null},
        gender = ${validatedData.gender || null},
        parent_name = ${validatedData.parent_name || null},
        parent_phone = ${validatedData.parent_phone || null},
        parent_email = ${validatedData.parent_email || null}
      WHERE id = ${id}
    `

    revalidatePath("/students")
    revalidatePath(`/students/${id}`)
    return { success: true }
  } catch (error) {
    console.error(`Error updating student with ID ${id}:`, error)
    if (error instanceof z.ZodError) {
      return { success: false, error: error.errors[0].message }
    }
    return { success: false, error: "Failed to update student" }
  }
}

// Delete a student
export async function deleteStudent(id: number) {
  try {
    // Check if student exists
    const student = await sql`SELECT id FROM students WHERE id = ${id}`

    if (student.length === 0) {
      return { success: false, error: "Student not found" }
    }

    // Delete student
    await sql`DELETE FROM students WHERE id = ${id}`

    revalidatePath("/students")
    return { success: true }
  } catch (error) {
    console.error(`Error deleting student with ID ${id}:`, error)
    return { success: false, error: "Failed to delete student" }
  }
}
