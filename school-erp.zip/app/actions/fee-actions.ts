"use server"
import { sql } from "@/lib/db"

export async function getFees() {
  try {
    // Update this query to use sql.query
    const fees = await sql.query(`
      SELECT f.*, s.first_name, s.last_name 
      FROM fees f
      JOIN students s ON f.student_id = s.id
      ORDER BY f.due_date DESC
    `)
    return { success: true, fees }
  } catch (error) {
    console.error("Error fetching fees:", error)
    return { success: false, message: "Failed to fetch fees" }
  }
}

export async function getFeeById(id: number) {
  try {
    // Update this query to use sql.query
    const fees = await sql.query(
      `
      SELECT f.*, s.first_name, s.last_name 
      FROM fees f
      JOIN students s ON f.student_id = s.id
      WHERE f.id = $1
    `,
      [id],
    )

    if (fees.length === 0) {
      return { success: false, message: "Fee not found" }
    }

    return { success: true, fee: fees[0] }
  } catch (error) {
    console.error(`Error fetching fee ${id}:`, error)
    return { success: false, message: "Failed to fetch fee" }
  }
}

export async function addFee(formData: FormData) {
  const studentId = Number.parseInt(formData.get("studentId") as string)
  const feeType = formData.get("feeType") as string
  const amount = Number.parseFloat(formData.get("amount") as string)
  const dueDate = formData.get("dueDate") as string
  const status = formData.get("status") as string

  try {
    // Update this query to use sql.query
    await sql.query("INSERT INTO fees (student_id, fee_type, amount, due_date, status) VALUES ($1, $2, $3, $4, $5)", [
      studentId,
      feeType,
      amount,
      dueDate,
      status,
    ])
    return { success: true, message: "Fee added successfully" }
  } catch (error) {
    console.error("Error adding fee:", error)
    return { success: false, message: "Failed to add fee" }
  }
}

export async function updateFee(id: number, formData: FormData) {
  const studentId = Number.parseInt(formData.get("studentId") as string)
  const feeType = formData.get("feeType") as string
  const amount = Number.parseFloat(formData.get("amount") as string)
  const dueDate = formData.get("dueDate") as string
  const status = formData.get("status") as string

  try {
    // Update this query to use sql.query
    await sql.query(
      "UPDATE fees SET student_id = $1, fee_type = $2, amount = $3, due_date = $4, status = $5 WHERE id = $6",
      [studentId, feeType, amount, dueDate, status, id],
    )
    return { success: true, message: "Fee updated successfully" }
  } catch (error) {
    console.error(`Error updating fee ${id}:`, error)
    return { success: false, message: "Failed to update fee" }
  }
}

export async function deleteFee(id: number) {
  try {
    // Update this query to use sql.query
    await sql.query("DELETE FROM fees WHERE id = $1", [id])
    return { success: true, message: "Fee deleted successfully" }
  } catch (error) {
    console.error(`Error deleting fee ${id}:`, error)
    return { success: false, message: "Failed to delete fee" }
  }
}

export async function updateFeeStatus(id: number, status: string) {
  try {
    // Update this query to use sql.query
    await sql.query("UPDATE fees SET status = $1 WHERE id = $2", [status, id])
    return { success: true, message: "Fee status updated successfully" }
  } catch (error) {
    console.error(`Error updating fee status ${id}:`, error)
    return { success: false, message: "Failed to update fee status" }
  }
}
