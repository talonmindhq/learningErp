"use server"

import { sql } from "@/lib/db"
import type { AssessmentType } from "@/lib/db-types"
import { revalidatePath } from "next/cache"

// Get all assessment types
export async function getAssessmentTypes() {
  try {
    const result = await sql`
      SELECT * FROM assessment_types
      ORDER BY name
    `
    return { success: true, data: result.rows as AssessmentType[] }
  } catch (error) {
    console.error("Error fetching assessment types:", error)
    return { success: false, message: "Failed to fetch assessment types" }
  }
}

// Get all assessments
export async function getAssessments(grade?: string) {
  try {
    let query = sql`
      SELECT a.*, at.name as assessment_type_name, at.weight as type_weight
      FROM assessments a
      JOIN assessment_types at ON a.assessment_type_id = at.id
    `

    if (grade) {
      query = sql`
        ${query} WHERE a.grade = ${grade}
      `
    }

    query = sql`
      ${query} ORDER BY a.assessment_date DESC
    `

    const result = await query
    return { success: true, data: result.rows }
  } catch (error) {
    console.error("Error fetching assessments:", error)
    return { success: false, message: "Failed to fetch assessments" }
  }
}

// Create a new assessment
export async function createAssessment(formData: FormData) {
  try {
    const title = formData.get("title") as string
    const description = formData.get("description") as string
    const assessmentTypeId = Number(formData.get("assessmentTypeId"))
    const subject = formData.get("subject") as string
    const maxScore = Number(formData.get("maxScore"))
    const teacherId = Number(formData.get("teacherId"))
    const assessmentDate = formData.get("assessmentDate") as string
    const grade = formData.get("grade") as string

    // Validate required fields
    if (!title || !assessmentTypeId || !subject || !maxScore || !assessmentDate || !grade) {
      return { success: false, message: "Required fields are missing" }
    }

    const result = await sql`
      INSERT INTO assessments (
        title, description, assessment_type_id, subject, 
        max_score, teacher_id, assessment_date, grade, created_at
      ) VALUES (
        ${title}, ${description}, ${assessmentTypeId}, ${subject}, 
        ${maxScore}, ${teacherId}, ${assessmentDate}, ${grade}, CURRENT_TIMESTAMP
      )
      RETURNING id
    `

    revalidatePath("/assessments")
    return { success: true, data: result.rows[0] }
  } catch (error) {
    console.error("Error creating assessment:", error)
    return { success: false, message: "Failed to create assessment" }
  }
}

// Get assessment by ID
export async function getAssessmentById(id: number) {
  try {
    const result = await sql`
      SELECT a.*, at.name as assessment_type_name, at.weight as type_weight
      FROM assessments a
      JOIN assessment_types at ON a.assessment_type_id = at.id
      WHERE a.id = ${id}
    `

    if (result.rows.length === 0) {
      return { success: false, message: "Assessment not found" }
    }

    return { success: true, data: result.rows[0] }
  } catch (error) {
    console.error(`Error fetching assessment with ID ${id}:`, error)
    return { success: false, message: "Failed to fetch assessment details" }
  }
}

// Update an assessment
export async function updateAssessment(id: number, formData: FormData) {
  try {
    const title = formData.get("title") as string
    const description = formData.get("description") as string
    const assessmentTypeId = Number(formData.get("assessmentTypeId"))
    const subject = formData.get("subject") as string
    const maxScore = Number(formData.get("maxScore"))
    const assessmentDate = formData.get("assessmentDate") as string
    const grade = formData.get("grade") as string

    // Validate required fields
    if (!title || !assessmentTypeId || !subject || !maxScore || !assessmentDate || !grade) {
      return { success: false, message: "Required fields are missing" }
    }

    await sql`
      UPDATE assessments
      SET title = ${title},
          description = ${description},
          assessment_type_id = ${assessmentTypeId},
          subject = ${subject},
          max_score = ${maxScore},
          assessment_date = ${assessmentDate},
          grade = ${grade}
      WHERE id = ${id}
    `

    revalidatePath("/assessments")
    revalidatePath(`/assessments/${id}`)
    return { success: true }
  } catch (error) {
    console.error(`Error updating assessment with ID ${id}:`, error)
    return { success: false, message: "Failed to update assessment" }
  }
}

// Delete an assessment
export async function deleteAssessment(id: number) {
  try {
    await sql`DELETE FROM assessments WHERE id = ${id}`

    revalidatePath("/assessments")
    return { success: true }
  } catch (error) {
    console.error(`Error deleting assessment with ID ${id}:`, error)
    return { success: false, message: "Failed to delete assessment" }
  }
}
