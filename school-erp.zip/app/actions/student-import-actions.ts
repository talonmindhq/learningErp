"use server"

import { sql } from "@/lib/db"
import * as XLSX from "xlsx"
import { z } from "zod"
import { revalidatePath } from "next/cache"

// Schema for validating student data from Excel
const studentExcelSchema = z.object({
  first_name: z.string().min(2, "First name must be at least 2 characters"),
  last_name: z.string().min(2, "Last name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  grade: z.string().min(1, "Grade is required"),
  admission_number: z.string().min(1, "Admission number is required"),
  date_of_birth: z.string().optional(),
  gender: z.string().optional(),
  address: z.string().optional(),
  phone: z.string().optional(),
  parent_name: z.string().optional(),
  parent_phone: z.string().optional(),
  parent_email: z.string().email("Invalid parent email").optional().or(z.literal("")),
  status: z.string().optional().default("Active"),
})

type StudentExcelData = z.infer<typeof studentExcelSchema>

export async function importStudentsFromExcel(formData: FormData) {
  try {
    console.log("Starting student import from Excel")

    // Get the file from the form data
    const file = formData.get("file") as File
    if (!file) {
      return { success: false, error: "No file provided" }
    }

    // Read the file as an array buffer
    const buffer = await file.arrayBuffer()

    // Parse the Excel file
    const workbook = XLSX.read(buffer, { type: "array" })
    const worksheet = workbook.Sheets[workbook.SheetNames[0]]

    // Convert to JSON
    const jsonData = XLSX.utils.sheet_to_json(worksheet)
    console.log(`Found ${jsonData.length} records in Excel file`)

    // Process each row
    const results = {
      imported: 0,
      failed: 0,
      errors: [] as string[],
    }

    for (let i = 0; i < jsonData.length; i++) {
      const row = jsonData[i] as Record<string, any>

      try {
        // Validate the row data
        const studentData = studentExcelSchema.parse({
          first_name: row.first_name,
          last_name: row.last_name,
          email: row.email,
          grade: row.grade?.toString(),
          admission_number: row.admission_number?.toString(),
          date_of_birth: row.date_of_birth,
          gender: row.gender,
          address: row.address,
          phone: row.phone?.toString(),
          parent_name: row.parent_name,
          parent_phone: row.parent_phone?.toString(),
          parent_email: row.parent_email || "",
          status: row.status || "Active",
        })

        // Check if email already exists
        const existingEmail = await sql.query(`SELECT id FROM students WHERE email = $1`, [studentData.email])

        if (existingEmail.rows.length > 0) {
          results.failed++
          results.errors.push(`Row ${i + 1}: Email ${studentData.email} already exists`)
          continue
        }

        // Check if admission number already exists
        const existingAdmission = await sql.query(`SELECT id FROM students WHERE admission_number = $1`, [
          studentData.admission_number,
        ])

        if (existingAdmission.rows.length > 0) {
          results.failed++
          results.errors.push(`Row ${i + 1}: Admission number ${studentData.admission_number} already exists`)
          continue
        }

        // Insert the student
        await sql.query(
          `INSERT INTO students (
            first_name, last_name, email, grade, admission_number, 
            date_of_birth, gender, address, phone, 
            parent_name, parent_phone, parent_email, status
          ) VALUES (
            $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13
          )`,
          [
            studentData.first_name,
            studentData.last_name,
            studentData.email,
            studentData.grade,
            studentData.admission_number,
            studentData.date_of_birth || null,
            studentData.gender || null,
            studentData.address || null,
            studentData.phone || null,
            studentData.parent_name || null,
            studentData.parent_phone || null,
            studentData.parent_email || null,
            studentData.status || "Active",
          ],
        )

        results.imported++
      } catch (error) {
        results.failed++
        if (error instanceof z.ZodError) {
          const errorMessage = `Row ${i + 1}: ${error.errors[0].message}`
          results.errors.push(errorMessage)
        } else if (error instanceof Error) {
          const errorMessage = `Row ${i + 1}: ${error.message}`
          results.errors.push(errorMessage)
        } else {
          const errorMessage = `Row ${i + 1}: Unknown error`
          results.errors.push(errorMessage)
        }
      }
    }

    console.log(`Import completed: ${results.imported} imported, ${results.failed} failed`)

    // Revalidate the students page
    revalidatePath("/students")

    return {
      success: true,
      ...results,
    }
  } catch (error) {
    console.error("Error importing students from Excel:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Failed to import students",
    }
  }
}
