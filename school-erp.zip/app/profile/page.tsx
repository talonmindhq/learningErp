import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { getSession } from "@/app/actions/auth-actions"
import { executeQuery } from "@/lib/db"
import { redirect } from "next/navigation"

async function getUserProfile(userId: number, role: string) {
  try {
    if (role === "Admin") {
      // For admin, just return basic info
      return {
        id: userId,
        name: "Administrator",
        email: "admin@school.com",
        role: "Admin",
      }
    } else if (role === "Teacher") {
      // Get teacher profile
      const teachers = await executeQuery("SELECT * FROM teachers WHERE id = $1", [userId])
      if (teachers.length === 0) {
        return null
      }
      return {
        ...teachers[0],
        role: "Teacher",
      }
    } else if (role === "Student") {
      // Get student profile
      const students = await executeQuery(
        `
        SELECT s.*, tr.name as transport_route_name 
        FROM students s
        LEFT JOIN transport_routes tr ON s.transport_route_id = tr.id
        WHERE s.id = $1
      `,
        [userId],
      )
      if (students.length === 0) {
        return null
      }
      return {
        ...students[0],
        role: "Student",
      }
    }
    return null
  } catch (error) {
    console.error("Error fetching user profile:", error)
    return null
  }
}

export default async function ProfilePage() {
  const session = await getSession()

  if (!session) {
    redirect("/auth/login")
  }

  const profile = await getUserProfile(session.id, session.role)

  if (!profile) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Profile</h1>
        <Card>
          <CardHeader>
            <CardTitle>User Profile</CardTitle>
            <CardDescription>Your profile information</CardDescription>
          </CardHeader>
          <CardContent>
            <p>Profile not found. Please contact an administrator.</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Profile</h1>
      <Card>
        <CardHeader>
          <CardTitle>User Profile</CardTitle>
          <CardDescription>Your profile information</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {profile.role === "Admin" && (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Name</p>
                    <p>{profile.name}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Email</p>
                    <p>{profile.email}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Role</p>
                    <p>{profile.role}</p>
                  </div>
                </div>
              </>
            )}

            {profile.role === "Teacher" && (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Name</p>
                    <p>{`${profile.first_name} ${profile.last_name}`}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Email</p>
                    <p>{profile.email}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Subject</p>
                    <p>{profile.subject}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Phone</p>
                    <p>{profile.phone}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Join Date</p>
                    <p>{new Date(profile.join_date).toLocaleDateString()}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Status</p>
                    <p>{profile.status}</p>
                  </div>
                </div>
              </>
            )}

            {profile.role === "Student" && (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Name</p>
                    <p>{`${profile.first_name} ${profile.last_name}`}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Email</p>
                    <p>{profile.email}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Grade</p>
                    <p>{profile.grade}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Phone</p>
                    <p>{profile.phone}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Admission Date</p>
                    <p>{new Date(profile.admission_date).toLocaleDateString()}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Status</p>
                    <p>{profile.status}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Address</p>
                    <p>{profile.address}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Transport Route</p>
                    <p>{profile.transport_route_name || "None"}</p>
                  </div>
                </div>
              </>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
